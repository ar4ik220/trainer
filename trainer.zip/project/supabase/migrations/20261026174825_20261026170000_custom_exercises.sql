/*
# Custom exercises with editable icons

1. Overview
This migration lets the admin create NEW exercises (beyond the four built-in
squat / pushup / lunge / plank) and edit the icon (SVG) of every exercise —
built-in or custom.

A custom exercise reuses one of the four existing pose-detection engines
("base kind") but has its own `kind` slug, name, icon, description, goals and
angle thresholds. This keeps the detection logic unchanged (each engine is
hand-tuned) while letting the admin define variations (e.g. "Wide squats",
"Slow pushups", "Split squats") with their own thresholds and presentation.

2. Schema changes
- `exercise_settings`
  - DROP the `exercise_settings_kind_check` CHECK constraint that limited
    `kind` to the four built-in slugs. `kind` is now any non-empty text slug;
    uniqueness still enforced by the PRIMARY KEY.
  - ADD column `base_kind text NOT NULL DEFAULT 'squat'` — which of the four
    detection engines drives this exercise. Constrained by a new CHECK to
    squat / pushup / lunge / plank. Existing rows back-filled to match their
    own `kind` (they ARE the base engines).
  - ADD column `icon text NOT NULL DEFAULT ''` — raw SVG markup used as the
    exercise icon in the UI. Empty string means "use the built-in icon for
    the base kind".
- `sessions`
  - DROP the `sessions_kind_check` CHECK constraint so workouts logged against
    custom exercises are accepted. `kind` is now free text.

3. Functions
- `set_exercise_settings` — add `p_base_kind text` and `p_icon text` params.
  Validates `p_base_kind` against the four engines. Inserts/updates `base_kind`
  and `icon`. The admin check (`is_admin`) is unchanged.
- `record_session` — the `p_kind` validation that rejected anything outside
  the four slugs is removed; any non-null text is accepted (the session is
  simply stored). Rating logic is unchanged.

4. Security
- No grant or policy changes: `exercise_settings` stays SELECT-only for
  anon/authenticated; mutations still go through the SECURITY DEFINER RPC.
  `sessions` INSERT still scoped to the owner via the existing policy.
- The two CHECK constraints dropped are NOT security controls — they were data
  validators for a fixed enum. Removing them is intentional and safe: the RPC
  still validates `base_kind` (the engine must exist), and `kind` slugs are
  author-controlled by the admin.
*/

-- 1. exercise_settings: relax kind CHECK + add base_kind and icon
ALTER TABLE exercise_settings DROP CONSTRAINT IF EXISTS exercise_settings_kind_check;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema='public' AND table_name='exercise_settings' AND column_name='base_kind'
  ) THEN
    ALTER TABLE exercise_settings ADD COLUMN base_kind text NOT NULL DEFAULT 'squat';
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema='public' AND table_name='exercise_settings' AND column_name='icon'
  ) THEN
    ALTER TABLE exercise_settings ADD COLUMN icon text NOT NULL DEFAULT '';
  END IF;
END $$;

-- Back-fill base_kind for the four built-in rows so they reference themselves.
UPDATE exercise_settings SET base_kind = kind WHERE base_kind = 'squat' AND kind IN ('squat','pushup','lunge','plank');

ALTER TABLE exercise_settings DROP CONSTRAINT IF EXISTS exercise_settings_base_kind_check;
ALTER TABLE exercise_settings ADD CONSTRAINT exercise_settings_base_kind_check
  CHECK (base_kind IN ('squat','pushup','lunge','plank'));

-- 2. sessions: relax kind CHECK so custom exercises can be logged
ALTER TABLE sessions DROP CONSTRAINT IF EXISTS sessions_kind_check;

-- 3. Updated set_exercise_settings with base_kind + icon params
CREATE OR REPLACE FUNCTION set_exercise_settings(
  p_kind text,
  p_base_kind text,
  p_name text,
  p_short text,
  p_unit text,
  p_goals int[],
  p_goal int,
  p_lede text,
  p_setup text[],
  p_rules text[],
  p_cfg jsonb,
  p_icon text
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_is_admin boolean;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;
  IF p_kind IS NULL OR btrim(p_kind) = '' THEN
    RAISE EXCEPTION 'kind must not be empty';
  END IF;
  IF p_base_kind NOT IN ('squat','pushup','lunge','plank') THEN
    RAISE EXCEPTION 'Invalid base_kind';
  END IF;
  IF p_unit NOT IN ('reps','sec') THEN
    RAISE EXCEPTION 'Invalid unit';
  END IF;

  SELECT is_admin INTO v_is_admin FROM profiles WHERE id = v_uid;
  IF NOT FOUND OR v_is_admin IS NOT TRUE THEN
    RAISE EXCEPTION 'Forbidden: admin only';
  END IF;

  INSERT INTO exercise_settings
    (kind, base_kind, name, short, unit, goals, goal, lede, setup, rules, cfg, icon, updated_at, updated_by)
  VALUES
    (p_kind, p_base_kind, p_name, p_short, p_unit, p_goals, p_goal, p_lede, p_setup, p_rules, p_cfg, p_icon, now(), v_uid)
  ON CONFLICT (kind) DO UPDATE SET
    base_kind = EXCLUDED.base_kind,
    name = EXCLUDED.name,
    short = EXCLUDED.short,
    unit = EXCLUDED.unit,
    goals = EXCLUDED.goals,
    goal = EXCLUDED.goal,
    lede = EXCLUDED.lede,
    setup = EXCLUDED.setup,
    rules = EXCLUDED.rules,
    cfg = EXCLUDED.cfg,
    icon = EXCLUDED.icon,
    updated_at = now(),
    updated_by = v_uid;
END;
$$;

REVOKE EXECUTE ON FUNCTION set_exercise_settings(text, text, text, text, text, int[], int, text, text[], text[], jsonb, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION set_exercise_settings(text, text, text, text, text, int[], int, text, text[], text[], jsonb, text) TO authenticated;

-- 4. Updated record_session: accept any kind text (custom exercises)
CREATE OR REPLACE FUNCTION record_session(
  p_kind text,
  p_mode text,
  p_good numeric,
  p_bad numeric,
  p_pct int,
  p_placement int DEFAULT NULL,
  p_opponents int DEFAULT 0
) RETURNS TABLE (
  session_id uuid,
  rating_delta int,
  new_solo_rating int,
  new_battle_rating int
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_solo int;
  v_battle int;
  v_delta int := 0;
  v_exp numeric;
  v_score numeric;
  v_avg_opp int;
  v_sid uuid;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;
  IF p_kind IS NULL OR btrim(p_kind) = '' THEN
    RAISE EXCEPTION 'Invalid kind';
  END IF;
  IF p_mode NOT IN ('solo','battle') THEN
    RAISE EXCEPTION 'Invalid mode';
  END IF;
  IF p_pct < 0 OR p_pct > 100 THEN
    RAISE EXCEPTION 'pct out of range';
  END IF;

  SELECT solo_rating, battle_rating INTO v_solo, v_battle
  FROM profiles WHERE id = v_uid;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Profile not found';
  END IF;

  IF p_mode = 'solo' THEN
    v_delta := GREATEST(-60, LEAST(60, ROUND((p_pct - 70) * 4)));
    v_solo := v_solo + v_delta;
  ELSE
    IF p_opponents > 0 AND p_placement IS NOT NULL THEN
      v_score := 1.0 - ((p_placement - 1.0) / GREATEST(1, p_opponents));
      v_avg_opp := v_battle;
      v_exp := 1.0 / (1.0 + POWER(10.0, (v_avg_opp - v_battle) / 400.0));
      v_delta := GREATEST(-80, LEAST(80, ROUND(32.0 * (v_score - v_exp))));
      v_battle := v_battle + v_delta;
    END IF;
  END IF;

  INSERT INTO sessions (user_id, kind, mode, good, bad, pct, placement, opponents, rating_delta)
  VALUES (v_uid, p_kind, p_mode, p_good, p_bad, p_pct, p_placement, p_opponents, v_delta)
  RETURNING id INTO v_sid;

  UPDATE profiles
  SET solo_rating = v_solo,
      battle_rating = v_battle,
      solo_workouts = solo_workouts + CASE WHEN p_mode = 'solo' THEN 1 ELSE 0 END,
      battles_played = battles_played + CASE WHEN p_mode = 'battle' THEN 1 ELSE 0 END
  WHERE id = v_uid;

  RETURN QUERY SELECT v_sid, v_delta, v_solo, v_battle;
END;
$$;

REVOKE EXECUTE ON FUNCTION record_session(text, text, numeric, numeric, int, int, int) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION record_session(text, text, numeric, numeric, int, int, int) TO authenticated;
