/*
# Admin panel: configurable exercise settings + admin role

1. Overview
This migration adds an admin-controlled configuration layer for exercises.
An admin user can override per-exercise angle thresholds, tempo, goal presets,
display name, lede, short description, setup instructions and rules — the same
fields that are currently hard-coded in `src/lib/exercises.ts` and
`src/lib/formaEngine.ts` (`CFG`). Non-admin users only read the active settings;
they cannot mutate them.

2. New / modified tables
- `profiles` — add column `is_admin boolean NOT NULL DEFAULT false`.
  Added via `DO $$ ... END $$` block so it is idempotent. Existing rows get
  `false`. The project owner is promoted to admin manually with
  `UPDATE profiles SET is_admin = true WHERE ...` (one-time, see notes).
- `exercise_settings` (new) — one row per exercise kind (squat / pushup /
  lunge / plank). Columns:
  - `kind text PRIMARY KEY` — constrained to the four known kinds.
  - `name text` — display name.
  - `short text` — one-line subtitle.
  - `unit text` — 'reps' | 'sec'.
  - `goals int[]` — selectable goal presets.
  - `goal int` — default goal.
  - `lede text` — intro paragraph.
  - `setup text[]` — setup instructions (one entry per bullet).
  - `rules text[]` — "what counts as a clean rep" bullets (HTML allowed, as in
    the current static strings).
  - `cfg jsonb` — angle/tempo overrides mirroring `CFG` in formaEngine.ts:
    squat: {depth, leanMax, minMs, attempt, up, start}
    pushup: {depth, bodyMin, minMs, attempt, up, start, horizMax}
    lunge: {front, rear, leanMax, minMs, attempt, up, start}
    plank: {bodyMin, horizMax}
  - `updated_at timestamptz` — last edit time.
  - `updated_by uuid` — admin user who last edited (nullable).
  Rows are seeded with the current hard-coded defaults so the app works
  unchanged out of the box.

3. Security
- RLS enabled on `exercise_settings`.
- `anon, authenticated` get SELECT (everyone reads active settings).
- Only `service_role` (server-side) and a SECURITY DEFINER RPC can mutate.
  No direct INSERT/UPDATE/DELETE grants to `authenticated`/`anon`, so even a
  logged-in non-admin cannot bypass the admin check.
- `set_exercise_settings` is a SECURITY DEFINER function. It checks
  `is_admin` on the caller's profile and rejects non-admins with an exception.
  Only `authenticated` may execute it.
- `profiles.is_admin` is NOT updatable by clients: the existing
  `profiles_update_own` policy only allows updating `display_name`, and there
  is no grant on `is_admin`, so a client cannot promote itself.

4. Notes
- To make a user admin, run once in SQL:
  `UPDATE profiles SET is_admin = true WHERE display_name = '<name>';`
- The frontend reads `exercise_settings` and merges with the static defaults,
  so an empty/missing field falls back to the built-in value.
*/

-- 1. Add is_admin column to profiles (idempotent)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'profiles' AND column_name = 'is_admin'
  ) THEN
    ALTER TABLE profiles ADD COLUMN is_admin boolean NOT NULL DEFAULT false;
  END IF;
END $$;

-- 2. exercise_settings table
CREATE TABLE IF NOT EXISTS exercise_settings (
  kind text PRIMARY KEY CHECK (kind IN ('squat','pushup','lunge','plank')),
  name text NOT NULL,
  short text NOT NULL,
  unit text NOT NULL DEFAULT 'reps',
  goals int[] NOT NULL DEFAULT '{}',
  goal int NOT NULL DEFAULT 10,
  lede text NOT NULL DEFAULT '',
  setup text[] NOT NULL DEFAULT '{}',
  rules text[] NOT NULL DEFAULT '{}',
  cfg jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now(),
  updated_by uuid
);

ALTER TABLE exercise_settings ENABLE ROW LEVEL SECURITY;

-- Everyone can read active settings.
GRANT SELECT ON exercise_settings TO anon, authenticated;
-- No direct write grants to anon/authenticated: mutations go through the RPC.

DROP POLICY IF EXISTS "exercise_settings_select_all" ON exercise_settings;
CREATE POLICY "exercise_settings_select_all"
ON exercise_settings FOR SELECT TO anon, authenticated USING (true);

-- 3. Seed with current defaults (idempotent: only insert when missing)
INSERT INTO exercise_settings (kind, name, short, unit, goals, goal, lede, setup, rules, cfg) VALUES
(
  'squat',
  'Приседания',
  'Колено, глубина и наклон спины',
  'reps',
  ARRAY[5,10,15,20],
  10,
  'Тренер смотрит на сустав колена и линию спины сбоку.',
  ARRAY[
    'Поставь телефон на пол или стол на высоте пояса, в 2–3 метрах от себя.',
    'Встань боком к камере. В кадре всё тело от головы до стоп.',
    'Руки вытяни перед собой или скрести на груди.'
  ],
  ARRAY[
    'Глубина: колено сгибается до <b>105°</b> или глубже',
    'Спина: наклон не больше <b>65°</b> от вертикали',
    'Темп: одно повторение не быстрее <b>0.9 с</b>',
    'Полный выход в стойку наверху'
  ],
  '{"depth":105,"leanMax":65,"minMs":900,"attempt":135,"up":160,"start":150}'::jsonb
) ON CONFLICT (kind) DO NOTHING;

INSERT INTO exercise_settings (kind, name, short, unit, goals, goal, lede, setup, rules, cfg) VALUES
(
  'pushup',
  'Отжимания',
  'Локоть, глубина и прямая линия корпуса',
  'reps',
  ARRAY[5,10,15,20],
  10,
  'Тренер смотрит на сгиб локтя и прямую линию плечо, таз, стопа.',
  ARRAY[
    'Поставь телефон на пол в 2–3 метрах от себя на уровне корпуса.',
    'Прими упор лёжа боком к камере. Видно плечо, локоть, кисть, таз и стопы.',
    'Освободи вокруг место: тело займёт в кадре около двух метров.'
  ],
  ARRAY[
    'Глубина: локоть сгибается до <b>95°</b> или глубже',
    'Корпус: линия плечо-таз-стопа не меньше <b>160°</b>, без провисшего или поднятого таза',
    'Темп: повторение не быстрее <b>0.6 с</b>',
    'Полное выпрямление рук наверху'
  ],
  '{"depth":95,"bodyMin":160,"minMs":600,"attempt":135,"up":155,"start":145,"horizMax":45}'::jsonb
) ON CONFLICT (kind) DO NOTHING;

INSERT INTO exercise_settings (kind, name, short, unit, goals, goal, lede, setup, rules, cfg) VALUES
(
  'lunge',
  'Выпады',
  'Оба колена и прямой корпус',
  'reps',
  ARRAY[6,10,16,20],
  10,
  'Каждый выпад считается отдельно, ногу можно менять.',
  ARRAY[
    'Поставь телефон на пол или стол на высоте пояса, в 2–3 метрах от себя.',
    'Встань боком к камере, обе ноги и плечо в кадре.',
    'Шаг делай вдоль линии, а не на камеру.'
  ],
  ARRAY[
    'Переднее колено сгибается до <b>105°</b> или глубже',
    'Заднее колено опускается до <b>130°</b> или глубже',
    'Корпус: наклон не больше <b>35°</b>',
    'Темп: повторение не быстрее <b>1.0 с</b>'
  ],
  '{"front":105,"rear":130,"leanMax":35,"minMs":1000,"attempt":135,"up":160,"start":145}'::jsonb
) ON CONFLICT (kind) DO NOTHING;

INSERT INTO exercise_settings (kind, name, short, unit, goals, goal, lede, setup, rules, cfg) VALUES
(
  'plank',
  'Планка',
  'Секунды, пока корпус ровный',
  'sec',
  ARRAY[20,30,45,60],
  30,
  'Время идёт только пока тело держит прямую линию. Провис или подъём таза останавливают отсчёт.',
  ARRAY[
    'Поставь телефон на пол в 2 метрах от себя на уровне корпуса.',
    'Прими упор на предплечьях боком к камере.',
    'Плечи над локтями, взгляд в пол.'
  ],
  ARRAY[
    'Линия плечо-таз-стопа не меньше <b>165°</b>',
    'В зачёт идут только секунды с ровным корпусом',
    'Каждые 10 чистых секунд тренер подтверждает голосом'
  ],
  '{"bodyMin":165,"horizMax":40}'::jsonb
) ON CONFLICT (kind) DO NOTHING;

-- 4. Admin-only setter RPC (SECURITY DEFINER, checks is_admin)
CREATE OR REPLACE FUNCTION set_exercise_settings(
  p_kind text,
  p_name text,
  p_short text,
  p_unit text,
  p_goals int[],
  p_goal int,
  p_lede text,
  p_setup text[],
  p_rules text[],
  p_cfg jsonb
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_is_admin boolean;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;
  IF p_kind NOT IN ('squat','pushup','lunge','plank') THEN
    RAISE EXCEPTION 'Invalid kind';
  END IF;
  IF p_unit NOT IN ('reps','sec') THEN
    RAISE EXCEPTION 'Invalid unit';
  END IF;

  SELECT is_admin INTO v_is_admin FROM profiles WHERE id = v_uid;
  IF NOT FOUND OR v_is_admin IS NOT TRUE THEN
    RAISE EXCEPTION 'Forbidden: admin only';
  END IF;

  INSERT INTO exercise_settings
    (kind, name, short, unit, goals, goal, lede, setup, rules, cfg, updated_at, updated_by)
  VALUES
    (p_kind, p_name, p_short, p_unit, p_goals, p_goal, p_lede, p_setup, p_rules, p_cfg, now(), v_uid)
  ON CONFLICT (kind) DO UPDATE SET
    name = EXCLUDED.name,
    short = EXCLUDED.short,
    unit = EXCLUDED.unit,
    goals = EXCLUDED.goals,
    goal = EXCLUDED.goal,
    lede = EXCLUDED.lede,
    setup = EXCLUDED.setup,
    rules = EXCLUDED.rules,
    cfg = EXCLUDED.cfg,
    updated_at = now(),
    updated_by = v_uid;
END;
$$;

REVOKE EXECUTE ON FUNCTION set_exercise_settings(text, text, text, text, int[], int, text, text[], text[], jsonb) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION set_exercise_settings(text, text, text, text, int[], int, text, text[], text[], jsonb) TO authenticated;
