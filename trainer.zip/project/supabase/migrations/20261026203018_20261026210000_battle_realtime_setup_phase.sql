/*
# Add battle tables to realtime publication + setup phase

## 1. Realtime publication
The `supabase_realtime` publication had zero tables, so realtime events
never fired for battle_rooms / battle_players. Players couldn't see each
other join without a page refresh, and host config changes weren't pushed
to guests in real time.

Adds `battle_rooms` and `battle_players` to the `supabase_realtime`
publication so Postgres changes on those tables are streamed to subscribed
clients.

## 2. Add `setup` phase
The original battle flow jumped straight from lobby to countdown, skipping
the camera-positioning step. Adds a `setup` phase to the phase CHECK
constraint so the host can move to `setup` (players see camera, get in
frame, mark themselves ready), then advance to `countdown` once everyone
is ready.

## 3. New function: start_battle_setup
Host-only: lobby -> setup. All players proceed to the camera/training
screen, where they must get in frame and be detected as ready. Once all
active players are ready, the host can advance to countdown.

## 4. New function: start_battle_countdown_from_setup
Host-only: setup -> countdown (requires all active players ready).
*/
ALTER PUBLICATION supabase_realtime ADD TABLE battle_rooms, battle_players;

ALTER TABLE battle_rooms DROP CONSTRAINT IF EXISTS battle_rooms_phase_check;
ALTER TABLE battle_rooms ADD CONSTRAINT battle_rooms_phase_check
  CHECK (phase IN ('lobby','setup','countdown','run','ending','end'));

CREATE OR REPLACE FUNCTION start_battle_setup(p_room_id uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_host_id uuid;
  v_phase text;
  v_count int;
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  SELECT battle_rooms.host_id, battle_rooms.phase
    INTO v_host_id, v_phase
    FROM battle_rooms WHERE battle_rooms.id = p_room_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'Room not found'; END IF;
  IF v_host_id <> v_uid THEN RAISE EXCEPTION 'Only host can start'; END IF;
  IF v_phase <> 'lobby' THEN RAISE EXCEPTION 'Not in lobby'; END IF;
  SELECT count(*) INTO v_count FROM battle_players
    WHERE battle_players.room_id = p_room_id AND battle_players.is_left = false;
  IF v_count < 2 THEN RAISE EXCEPTION 'Need at least 2 players'; END IF;
  UPDATE battle_rooms SET phase = 'setup' WHERE battle_rooms.id = p_room_id;
END;
$$;
REVOKE EXECUTE ON FUNCTION start_battle_setup(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION start_battle_setup(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION start_battle_countdown_from_setup(p_room_id uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_host_id uuid;
  v_phase text;
  v_not_ready int;
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  SELECT battle_rooms.host_id, battle_rooms.phase
    INTO v_host_id, v_phase
    FROM battle_rooms WHERE battle_rooms.id = p_room_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'Room not found'; END IF;
  IF v_host_id <> v_uid THEN RAISE EXCEPTION 'Only host can start'; END IF;
  IF v_phase <> 'setup' THEN RAISE EXCEPTION 'Not in setup'; END IF;
  SELECT count(*) INTO v_not_ready FROM battle_players
    WHERE battle_players.room_id = p_room_id
      AND battle_players.is_left = false
      AND battle_players.ready = false;
  IF v_not_ready > 0 THEN RAISE EXCEPTION 'Not all players are ready'; END IF;
  UPDATE battle_rooms SET phase = 'countdown' WHERE battle_rooms.id = p_room_id;
END;
$$;
REVOKE EXECUTE ON FUNCTION start_battle_countdown_from_setup(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION start_battle_countdown_from_setup(uuid) TO authenticated;

-- Allow set_battle_ready to work in setup phase (was unrestricted before, keep it)
-- update_room_cfg should only work in lobby (already constrained)
-- start_battle_countdown is now superseded by start_battle_setup + start_battle_countdown_from_setup
-- but keep it for backward compatibility
