/*
# Fix battle setup phase: reset ready, allow rejoin, cancel setup

## Problem
The `setup` phase was added to the database (lobby → setup → countdown → run)
but the frontend never used it — it jumped straight from lobby to countdown,
skipping the camera-positioning step. This caused:
- "After all players ready, nothing happens" — no mechanism to advance from setup
- "Stop button doesn't work" — stop only marked finished, didn't transition UI
- "Kicked out and can't return" — join_battle_room only allowed lobby phase,
  so disconnecting during setup locked the player out

## Changes

### 1. start_battle_setup — reset ready flags
Now resets all players' ready=false before entering setup phase, so
rematch/re-setup works correctly (was not resetting from previous round).

### 2. join_battle_room — allow joining during 'setup'
Changes `v_phase <> 'lobby'` to `v_phase NOT IN ('lobby', 'setup')` so
players who disconnect during setup can rejoin.

### 3. leave_battle_room — treat 'setup' like 'lobby'
Changes `v_phase = 'lobby'` to `v_phase IN ('lobby', 'setup')` so leaving
during setup deletes the player row (and the room if host leaves) instead of
marking as left, preventing stuck rooms.

### 4. update_room_cfg — allow during 'setup'
Changes `phase = 'lobby'` to `phase IN ('lobby', 'setup')` so host can
still adjust config during setup phase.

### 5. New: cancel_battle_setup
Host-only function to go setup → lobby, resetting ready flags. Lets the
host cancel the setup and return to the lobby.
*/

-- 1. start_battle_setup: reset ready flags before entering setup
CREATE OR REPLACE FUNCTION start_battle_setup(p_room_id uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_host_id uuid;
  v_phase text;
  v_count int;
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  SELECT battle_rooms.host_id, battle_rooms.phase
    INTO v_host_id, v_phase
    FROM battle_rooms WHERE battle_rooms.id = p_room_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'Room not found'; END IF;
  IF v_host_id <> v_uid THEN RAISE EXCEPTION 'Only host can start'; END IF;
  IF v_phase <> 'lobby' THEN RAISE EXCEPTION 'Not in lobby'; END IF;
  SELECT count(*) INTO v_count FROM battle_players
    WHERE battle_players.room_id = p_room_id AND battle_players.is_left = false;
  IF v_count < 2 THEN RAISE EXCEPTION 'Need at least 2 players'; END IF;
  UPDATE battle_players SET ready = false
    WHERE battle_players.room_id = p_room_id AND battle_players.is_left = false;
  UPDATE battle_rooms SET phase = 'setup' WHERE battle_rooms.id = p_room_id;
END;
$$;
REVOKE EXECUTE ON FUNCTION start_battle_setup(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION start_battle_setup(uuid) TO authenticated;

-- 2. join_battle_room: allow joining during 'setup' phase
CREATE OR REPLACE FUNCTION join_battle_room(p_room_id uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_name text;
  v_phase text;
  v_max int;
  v_count int;
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;

  SELECT battle_rooms.phase, battle_rooms.max_players
    INTO v_phase, v_max
    FROM battle_rooms WHERE battle_rooms.id = p_room_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'Room not found'; END IF;
  IF v_phase NOT IN ('lobby', 'setup') THEN RAISE EXCEPTION 'Battle already started'; END IF;

  SELECT count(*) INTO v_count FROM battle_players
    WHERE battle_players.room_id = p_room_id AND battle_players.is_left = false;
  IF v_count >= v_max THEN RAISE EXCEPTION 'Room is full'; END IF;

  SELECT profiles.display_name INTO v_name FROM profiles WHERE profiles.id = v_uid;
  IF NOT FOUND THEN RAISE EXCEPTION 'Profile not found'; END IF;

  INSERT INTO battle_players (room_id, user_id, display_name)
  VALUES (p_room_id, v_uid, v_name)
  ON CONFLICT (room_id, user_id) DO UPDATE
    SET is_left = false, display_name = EXCLUDED.display_name,
        good = 0, bad = 0, hold = 0, ready = false, fin = false, fin_at = null;
END;
$$;
REVOKE EXECUTE ON FUNCTION join_battle_room(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION join_battle_room(uuid) TO authenticated;

-- 3. leave_battle_room: treat 'setup' like 'lobby'
CREATE OR REPLACE FUNCTION leave_battle_room(p_room_id uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_host_id uuid;
  v_phase text;
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  SELECT battle_rooms.host_id, battle_rooms.phase
    INTO v_host_id, v_phase
    FROM battle_rooms WHERE battle_rooms.id = p_room_id;
  IF NOT FOUND THEN RETURN; END IF;

  IF v_phase IN ('lobby', 'setup') THEN
    DELETE FROM battle_players
      WHERE battle_players.room_id = p_room_id AND battle_players.user_id = v_uid;
    IF v_host_id = v_uid THEN
      DELETE FROM battle_rooms WHERE battle_rooms.id = p_room_id;
    END IF;
  ELSE
    UPDATE battle_players SET is_left = true
      WHERE battle_players.room_id = p_room_id AND battle_players.user_id = v_uid;
  END IF;
END;
$$;
REVOKE EXECUTE ON FUNCTION leave_battle_room(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION leave_battle_room(uuid) TO authenticated;

-- 4. update_room_cfg: allow during 'setup' phase
CREATE OR REPLACE FUNCTION update_room_cfg(
  p_room_id uuid, p_kind text, p_kind_name text, p_mode text, p_goal int, p_dur int
) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_uid uuid := auth.uid();
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  IF p_mode NOT IN ('race','timed') THEN RAISE EXCEPTION 'Invalid mode'; END IF;
  UPDATE battle_rooms
    SET kind = p_kind, kind_name = p_kind_name, mode = p_mode, goal = p_goal, dur = p_dur
    WHERE battle_rooms.id = p_room_id
      AND battle_rooms.host_id = v_uid
      AND battle_rooms.phase IN ('lobby', 'setup');
END;
$$;
REVOKE EXECUTE ON FUNCTION update_room_cfg(uuid,text,text,text,int,int) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION update_room_cfg(uuid,text,text,text,int,int) TO authenticated;

-- 5. New: cancel_battle_setup (host-only: setup -> lobby)
CREATE OR REPLACE FUNCTION cancel_battle_setup(p_room_id uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_host_id uuid;
  v_phase text;
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  SELECT battle_rooms.host_id, battle_rooms.phase
    INTO v_host_id, v_phase
    FROM battle_rooms WHERE battle_rooms.id = p_room_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'Room not found'; END IF;
  IF v_host_id <> v_uid THEN RAISE EXCEPTION 'Only host can cancel'; END IF;
  IF v_phase <> 'setup' THEN RAISE EXCEPTION 'Not in setup'; END IF;
  UPDATE battle_players SET ready = false
    WHERE battle_players.room_id = p_room_id AND battle_players.is_left = false;
  UPDATE battle_rooms SET phase = 'lobby' WHERE battle_rooms.id = p_room_id;
END;
$$;
REVOKE EXECUTE ON FUNCTION cancel_battle_setup(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION cancel_battle_setup(uuid) TO authenticated;
