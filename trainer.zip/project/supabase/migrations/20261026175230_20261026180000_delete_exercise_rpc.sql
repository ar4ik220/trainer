/*
# Admin: delete custom exercise

Adds an admin-only RPC to remove a custom (non-builtin) exercise row from
`exercise_settings`. Built-in slugs (squat/pushup/lunge/plank) are rejected
because they are the engines and must always exist.

1. Function
- `delete_exercise_settings(p_kind text)` — SECURITY DEFINER. Checks
  `is_admin` on the caller. Rejects the four built-in slugs. Deletes the row.
2. Security
- EXECUTE granted to `authenticated` only. No direct table DELETE grants to
  anon/authenticated, so this RPC is the only path to remove a row.
3. Data safety
- Only custom exercises can be removed. Existing sessions referencing a
  custom kind are NOT affected (sessions.kind has no FK to exercise_settings).
*/

CREATE OR REPLACE FUNCTION delete_exercise_settings(p_kind text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_is_admin boolean;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;
  IF p_kind IS NULL OR btrim(p_kind) = '' THEN
    RAISE EXCEPTION 'kind must not be empty';
  END IF;
  IF p_kind IN ('squat','pushup','lunge','plank') THEN
    RAISE EXCEPTION 'Built-in exercises cannot be deleted';
  END IF;

  SELECT is_admin INTO v_is_admin FROM profiles WHERE id = v_uid;
  IF NOT FOUND OR v_is_admin IS NOT TRUE THEN
    RAISE EXCEPTION 'Forbidden: admin only';
  END IF;

  DELETE FROM exercise_settings WHERE kind = p_kind;
END;
$$;

REVOKE EXECUTE ON FUNCTION delete_exercise_settings(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION delete_exercise_settings(text) TO authenticated;
