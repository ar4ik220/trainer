/*
# Battle rooms with Supabase realtime sync

Replaces the flaky PeerJS P2P battle system with Supabase-backed rooms.

## 1. New Tables

### `battle_rooms`
A battle lobby/room, visible in the lobby list so players can find open rooms.
- id (uuid PK), code (text unique 5-char), host_id (uuid FK profiles),
  host_name (text), kind (text exercise slug), kind_name (text display),
  mode (text 'race'|'timed'), goal (int), dur (int seconds),
  phase (text lobby|countdown|run|ending|end), rank (jsonb),
  max_players (int default 4), created_at (timestamptz)

### `battle_players`
One row per player in a room. Live stats update here during the battle.
- id (uuid PK), room_id (uuid FK), user_id (uuid FK),
  display_name (text), good (int), bad (int), hold (numeric),
  ready (bool), fin (bool), fin_at (timestamptz),
  is_left (bool), created_at (timestamptz), UNIQUE(room_id, user_id)

## 2. Functions (all SECURITY DEFINER, return void)
All RPCs return void. Clients read room/player data via normal SELECT
(allowed by RLS) and subscribe to realtime changes.

- create_battle_room(code, kind, kind_name, mode, goal, dur) -> uuid room id
  Returns just the room id as a scalar (no table-return ambiguity).
- join_battle_room(room_id) - Adds caller as player if lobby & not full.
- leave_battle_room(room_id) - Marks left, or deletes if lobby.
- start_battle_countdown(room_id) - Host-only: lobby -> countdown (>=2 players).
- set_battle_run(room_id) - Host-only: countdown -> run.
- end_battle(room_id, rank) - Host-only: -> 'end' with ranking.
- reset_battle_for_rematch(room_id) - Host-only: clears stats -> lobby.
- update_battle_stat(room_id, good, bad, hold) - Self: live stats.
- mark_battle_fin(room_id) - Self: marks finished.
- set_battle_ready(room_id) - Self: marks ready.
- update_room_cfg(room_id, kind, kind_name, mode, goal, dur) - Host, lobby only.

## 3. Security
- RLS enabled on both tables. SELECT to authenticated.
- All mutations through SECURITY DEFINER RPCs validating auth.uid() and host ownership.
*/

CREATE TABLE IF NOT EXISTS battle_rooms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  host_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  host_name text NOT NULL DEFAULT '',
  kind text NOT NULL DEFAULT 'squat',
  kind_name text NOT NULL DEFAULT 'Приседания',
  mode text NOT NULL DEFAULT 'race' CHECK (mode IN ('race','timed')),
  goal int NOT NULL DEFAULT 10,
  dur int NOT NULL DEFAULT 60,
  phase text NOT NULL DEFAULT 'lobby' CHECK (phase IN ('lobby','countdown','run','ending','end')),
  rank jsonb NOT NULL DEFAULT '[]'::jsonb,
  max_players int NOT NULL DEFAULT 4,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE battle_rooms ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON battle_rooms TO authenticated;

DROP POLICY IF EXISTS "br_select_all" ON battle_rooms;
CREATE POLICY "br_select_all"
ON battle_rooms FOR SELECT TO authenticated USING (true);

CREATE TABLE IF NOT EXISTS battle_players (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  room_id uuid NOT NULL REFERENCES battle_rooms(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  display_name text NOT NULL DEFAULT '',
  good int NOT NULL DEFAULT 0,
  bad int NOT NULL DEFAULT 0,
  hold numeric NOT NULL DEFAULT 0,
  ready boolean NOT NULL DEFAULT false,
  fin boolean NOT NULL DEFAULT false,
  fin_at timestamptz,
  is_left boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (room_id, user_id)
);

ALTER TABLE battle_players ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON battle_players TO authenticated;

DROP POLICY IF EXISTS "bp_select_all" ON battle_players;
CREATE POLICY "bp_select_all"
ON battle_players FOR SELECT TO authenticated USING (true);

CREATE INDEX IF NOT EXISTS battle_players_room_idx ON battle_players (room_id);
CREATE INDEX IF NOT EXISTS battle_rooms_phase_idx ON battle_rooms (phase, created_at DESC);

CREATE OR REPLACE FUNCTION create_battle_room(
  p_code text, p_kind text, p_kind_name text, p_mode text, p_goal int, p_dur int
) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_name text;
  v_rid uuid;
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  IF p_mode NOT IN ('race','timed') THEN RAISE EXCEPTION 'Invalid mode'; END IF;
  SELECT profiles.display_name INTO v_name FROM profiles WHERE profiles.id = v_uid;
  IF NOT FOUND THEN RAISE EXCEPTION 'Profile not found'; END IF;

  INSERT INTO battle_rooms (code, host_id, host_name, kind, kind_name, mode, goal, dur)
  VALUES (p_code, v_uid, v_name, p_kind, p_kind_name, p_mode, p_goal, p_dur)
  RETURNING battle_rooms.id INTO v_rid;

  INSERT INTO battle_players (room_id, user_id, display_name)
  VALUES (v_rid, v_uid, v_name);

  RETURN v_rid;
END;
$$;
REVOKE EXECUTE ON FUNCTION create_battle_room(text,text,text,text,int,int) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION create_battle_room(text,text,text,text,int,int) TO authenticated;

CREATE OR REPLACE FUNCTION join_battle_room(p_room_id uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_name text;
  v_phase text;
  v_max int;
  v_count int;
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;

  SELECT battle_rooms.phase, battle_rooms.max_players
    INTO v_phase, v_max
    FROM battle_rooms WHERE battle_rooms.id = p_room_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'Room not found'; END IF;
  IF v_phase <> 'lobby' THEN RAISE EXCEPTION 'Battle already started'; END IF;

  SELECT count(*) INTO v_count FROM battle_players
    WHERE battle_players.room_id = p_room_id AND battle_players.is_left = false;
  IF v_count >= v_max THEN RAISE EXCEPTION 'Room is full'; END IF;

  SELECT profiles.display_name INTO v_name FROM profiles WHERE profiles.id = v_uid;
  IF NOT FOUND THEN RAISE EXCEPTION 'Profile not found'; END IF;

  INSERT INTO battle_players (room_id, user_id, display_name)
  VALUES (p_room_id, v_uid, v_name)
  ON CONFLICT (room_id, user_id) DO UPDATE
    SET is_left = false, display_name = EXCLUDED.display_name,
        good = 0, bad = 0, hold = 0, ready = false, fin = false, fin_at = null;
END;
$$;
REVOKE EXECUTE ON FUNCTION join_battle_room(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION join_battle_room(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION leave_battle_room(p_room_id uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_host_id uuid;
  v_phase text;
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  SELECT battle_rooms.host_id, battle_rooms.phase
    INTO v_host_id, v_phase
    FROM battle_rooms WHERE battle_rooms.id = p_room_id;
  IF NOT FOUND THEN RETURN; END IF;

  IF v_phase = 'lobby' THEN
    DELETE FROM battle_players
      WHERE battle_players.room_id = p_room_id AND battle_players.user_id = v_uid;
    IF v_host_id = v_uid THEN
      DELETE FROM battle_rooms WHERE battle_rooms.id = p_room_id;
    END IF;
  ELSE
    UPDATE battle_players SET is_left = true
      WHERE battle_players.room_id = p_room_id AND battle_players.user_id = v_uid;
  END IF;
END;
$$;
REVOKE EXECUTE ON FUNCTION leave_battle_room(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION leave_battle_room(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION start_battle_countdown(p_room_id uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_host_id uuid;
  v_phase text;
  v_count int;
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  SELECT battle_rooms.host_id, battle_rooms.phase
    INTO v_host_id, v_phase
    FROM battle_rooms WHERE battle_rooms.id = p_room_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'Room not found'; END IF;
  IF v_host_id <> v_uid THEN RAISE EXCEPTION 'Only host can start'; END IF;
  IF v_phase <> 'lobby' THEN RAISE EXCEPTION 'Not in lobby'; END IF;
  SELECT count(*) INTO v_count FROM battle_players
    WHERE battle_players.room_id = p_room_id AND battle_players.is_left = false;
  IF v_count < 2 THEN RAISE EXCEPTION 'Need at least 2 players'; END IF;
  UPDATE battle_rooms SET phase = 'countdown' WHERE battle_rooms.id = p_room_id;
END;
$$;
REVOKE EXECUTE ON FUNCTION start_battle_countdown(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION start_battle_countdown(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION set_battle_run(p_room_id uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_uid uuid := auth.uid();
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  UPDATE battle_rooms SET phase = 'run'
    WHERE battle_rooms.id = p_room_id
      AND battle_rooms.host_id = v_uid
      AND battle_rooms.phase = 'countdown';
END;
$$;
REVOKE EXECUTE ON FUNCTION set_battle_run(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION set_battle_run(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION end_battle(p_room_id uuid, p_rank jsonb)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_uid uuid := auth.uid();
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  UPDATE battle_rooms SET phase = 'end', rank = p_rank
    WHERE battle_rooms.id = p_room_id AND battle_rooms.host_id = v_uid;
END;
$$;
REVOKE EXECUTE ON FUNCTION end_battle(uuid, jsonb) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION end_battle(uuid, jsonb) TO authenticated;

CREATE OR REPLACE FUNCTION reset_battle_for_rematch(p_room_id uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_uid uuid := auth.uid();
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  UPDATE battle_rooms SET phase = 'lobby', rank = '[]'::jsonb
    WHERE battle_rooms.id = p_room_id AND battle_rooms.host_id = v_uid;
  DELETE FROM battle_players
    WHERE battle_players.room_id = p_room_id AND battle_players.is_left = true;
  UPDATE battle_players
    SET good = 0, bad = 0, hold = 0, ready = false, fin = false, fin_at = null
    WHERE battle_players.room_id = p_room_id;
END;
$$;
REVOKE EXECUTE ON FUNCTION reset_battle_for_rematch(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION reset_battle_for_rematch(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION update_battle_stat(
  p_room_id uuid, p_good int, p_bad int, p_hold numeric
) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_uid uuid := auth.uid();
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  UPDATE battle_players SET good = p_good, bad = p_bad, hold = p_hold
    WHERE battle_players.room_id = p_room_id
      AND battle_players.user_id = v_uid
      AND battle_players.is_left = false;
END;
$$;
REVOKE EXECUTE ON FUNCTION update_battle_stat(uuid,int,int,numeric) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION update_battle_stat(uuid,int,int,numeric) TO authenticated;

CREATE OR REPLACE FUNCTION mark_battle_fin(p_room_id uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_uid uuid := auth.uid();
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  UPDATE battle_players SET fin = true, fin_at = now()
    WHERE battle_players.room_id = p_room_id
      AND battle_players.user_id = v_uid
      AND battle_players.is_left = false
      AND battle_players.fin = false;
END;
$$;
REVOKE EXECUTE ON FUNCTION mark_battle_fin(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION mark_battle_fin(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION set_battle_ready(p_room_id uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_uid uuid := auth.uid();
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  UPDATE battle_players SET ready = true
    WHERE battle_players.room_id = p_room_id
      AND battle_players.user_id = v_uid
      AND battle_players.is_left = false;
END;
$$;
REVOKE EXECUTE ON FUNCTION set_battle_ready(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION set_battle_ready(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION update_room_cfg(
  p_room_id uuid, p_kind text, p_kind_name text, p_mode text, p_goal int, p_dur int
) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE v_uid uuid := auth.uid();
BEGIN
  IF v_uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  IF p_mode NOT IN ('race','timed') THEN RAISE EXCEPTION 'Invalid mode'; END IF;
  UPDATE battle_rooms
    SET kind = p_kind, kind_name = p_kind_name, mode = p_mode, goal = p_goal, dur = p_dur
    WHERE battle_rooms.id = p_room_id
      AND battle_rooms.host_id = v_uid
      AND battle_rooms.phase = 'lobby';
END;
$$;
REVOKE EXECUTE ON FUNCTION update_room_cfg(uuid,text,text,text,int,int) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION update_room_cfg(uuid,text,text,text,int,int) TO authenticated;
