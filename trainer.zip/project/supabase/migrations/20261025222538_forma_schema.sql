/*
# Forma: profiles, sessions, and dual rating system

This migration sets up the persistence layer for the Forma AI-coach app.

## 1. Tables

### `profiles`
One row per registered user. Stores the two separate ratings the user asked for:
- `solo_rating` (int, default 1000) — changes when a user completes a solo
  workout. Higher when technique quality (% of clean reps) is high.
- `battle_rating` (int, default 1000) — changes when a user finishes a battle.
  Uses ELO-style comparison against the average rating of opponents faced.
- `display_name` (text) — the name shown in battles and on leaderboards.
- `solo_workouts` (int) — count of completed solo sessions.
- `battles_played` (int) — count of battles finished.

### `sessions`
One row per completed workout (solo or battle).
- `user_id` — owner.
- `kind` — exercise: squat / pushup / lunge / plank.
- `mode` — 'solo' | 'battle'.
- `good` / `bad` — clean reps and rejected reps (for plank, `good` = seconds
  of clean hold, `bad` = seconds with form break).
- `pct` — technique percentage (0..100).
- `placement` — rank in the battle (1 = first); NULL for solo.
- `opponents` (int) — number of opponents faced; 0 for solo.
- `rating_delta` — signed change applied to the relevant rating.
- `created_at`.

## 2. Security

- RLS enabled on both tables; only the owner can read/insert/update their own
  rows (sessions are append-only, so UPDATE is allowed only on profiles).
- `profiles` is publicly readable (SELECT to anon + authenticated) so that
  the global leaderboards can show names + ratings. Only the owner can update
  their own profile.
- `record_session` is a SECURITY DEFINER function: the client cannot write
  `rating_delta`, `solo_rating`, or `battle_rating` directly. The function
  recomputes the rating from the session result and updates the profile, so
  ratings can never be inflated from the client.
- EXECUTE on `record_session` is granted to `authenticated` only; revoked
  from PUBLIC + anon.

## 3. Rating logic (inside `record_session`)

Solo: delta = round((pct - 70) * 4)  — clean technique gains rating, sloppy
loses it. Clamped to [-60, +60].

Battle: classic ELO with K=32 vs. the average opponent rating derived from the
placement and the player count. The function receives the player's placement
(rank 1 = best) and the number of opponents; expected score is computed from
the player's current battle_rating against an assumed average opponent of equal
rating (so a 1st place vs N opponents is a strong win, last place a loss).
Delta clamped to [-80, +80]. For solo-style battle tie at 1st with 0 opponents,
delta is 0.

The function is called once per finished session and atomically inserts the
session row and updates the profile's rating + counters.
*/

CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name text NOT NULL DEFAULT '',
  solo_rating int NOT NULL DEFAULT 1000,
  battle_rating int NOT NULL DEFAULT 1000,
  solo_workouts int NOT NULL DEFAULT 0,
  battles_played int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

GRANT SELECT ON profiles TO anon, authenticated;
GRANT UPDATE (display_name) ON profiles TO authenticated;

DROP POLICY IF EXISTS "profiles_select_all" ON profiles;
CREATE POLICY "profiles_select_all"
ON profiles FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "profiles_update_own" ON profiles;
CREATE POLICY "profiles_update_own"
ON profiles FOR UPDATE TO authenticated
USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

CREATE TABLE IF NOT EXISTS sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  kind text NOT NULL CHECK (kind IN ('squat','pushup','lunge','plank')),
  mode text NOT NULL CHECK (mode IN ('solo','battle')),
  good numeric NOT NULL DEFAULT 0,
  bad numeric NOT NULL DEFAULT 0,
  pct int NOT NULL DEFAULT 0 CHECK (pct >= 0 AND pct <= 100),
  placement int CHECK (placement IS NULL OR placement >= 1),
  opponents int NOT NULL DEFAULT 0,
  rating_delta int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE sessions ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, DELETE ON sessions TO authenticated;

DROP POLICY IF EXISTS "sessions_select_own" ON sessions;
CREATE POLICY "sessions_select_own"
ON sessions FOR SELECT TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "sessions_insert_own" ON sessions;
CREATE POLICY "sessions_insert_own"
ON sessions FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "sessions_delete_own" ON sessions;
CREATE POLICY "sessions_delete_own"
ON sessions FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS sessions_user_created_idx
  ON sessions (user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS profiles_solo_rating_idx
  ON profiles (solo_rating DESC);

CREATE INDEX IF NOT EXISTS profiles_battle_rating_idx
  ON profiles (battle_rating DESC);

/* Leaderboard views: top profiles by each rating. */
CREATE OR REPLACE VIEW solo_leaderboard AS
  SELECT id, display_name, solo_rating, solo_workouts
  FROM profiles
  ORDER BY solo_rating DESC, solo_workouts DESC;

CREATE OR REPLACE VIEW battle_leaderboard AS
  SELECT id, display_name, battle_rating, battles_played
  FROM profiles
  ORDER BY battle_rating DESC, battles_played DESC;

GRANT SELECT ON solo_leaderboard TO anon, authenticated;
GRANT SELECT ON battle_leaderboard TO anon, authenticated;

/*
  record_session: atomically insert a session row and update the owner's
  profile rating + counters. SECURITY DEFINER so the client cannot set its
  own rating_delta or rating directly.
*/
CREATE OR REPLACE FUNCTION record_session(
  p_kind text,
  p_mode text,
  p_good numeric,
  p_bad numeric,
  p_pct int,
  p_placement int DEFAULT NULL,
  p_opponents int DEFAULT 0
) RETURNS TABLE (
  session_id uuid,
  rating_delta int,
  new_solo_rating int,
  new_battle_rating int
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_solo int;
  v_battle int;
  v_delta int := 0;
  v_exp numeric;
  v_score numeric;
  v_avg_opp int;
  v_sid uuid;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;
  IF p_kind NOT IN ('squat','pushup','lunge','plank') THEN
    RAISE EXCEPTION 'Invalid kind';
  END IF;
  IF p_mode NOT IN ('solo','battle') THEN
    RAISE EXCEPTION 'Invalid mode';
  END IF;
  IF p_pct < 0 OR p_pct > 100 THEN
    RAISE EXCEPTION 'pct out of range';
  END IF;

  SELECT solo_rating, battle_rating INTO v_solo, v_battle
  FROM profiles WHERE id = v_uid;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Profile not found';
  END IF;

  IF p_mode = 'solo' THEN
    -- Reward clean technique, penalise sloppy. Centred on 70%.
    v_delta := GREATEST(-60, LEAST(60, ROUND((p_pct - 70) * 4)));
    v_solo := v_solo + v_delta;
  ELSE
    -- ELO-style vs. average opponent. Without real opponent ratings in the
    -- call, assume opponents average the player's own rating (zero-sum-ish
    -- expectation). Score from placement: 1st = 1.0, last = 0.0, linear.
    IF p_opponents > 0 AND p_placement IS NOT NULL THEN
      v_score := 1.0 - ((p_placement - 1.0) / GREATEST(1, p_opponents));
      v_avg_opp := v_battle; -- neutral assumption
      v_exp := 1.0 / (1.0 + POWER(10.0, (v_avg_opp - v_battle) / 400.0));
      v_delta := GREATEST(-80, LEAST(80, ROUND(32.0 * (v_score - v_exp))));
      v_battle := v_battle + v_delta;
    END IF;
  END IF;

  INSERT INTO sessions (user_id, kind, mode, good, bad, pct, placement, opponents, rating_delta)
  VALUES (v_uid, p_kind, p_mode, p_good, p_bad, p_pct, p_placement, p_opponents, v_delta)
  RETURNING id INTO v_sid;

  UPDATE profiles
  SET solo_rating = v_solo,
      battle_rating = v_battle,
      solo_workouts = solo_workouts + CASE WHEN p_mode = 'solo' THEN 1 ELSE 0 END,
      battles_played = battles_played + CASE WHEN p_mode = 'battle' THEN 1 ELSE 0 END
  WHERE id = v_uid;

  RETURN QUERY SELECT v_sid, v_delta, v_solo, v_battle;
END;
$$;

REVOKE EXECUTE ON FUNCTION record_session(text, text, numeric, numeric, int, int, int) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION record_session(text, text, numeric, numeric, int, int, int) TO authenticated;

/*
  handle_new_user: create a profile row when a new auth user signs up.
  Triggered on auth.users INSERT.
*/
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_name text;
BEGIN
  v_name := COALESCE(NEW.raw_user_meta_data->>'display_name', NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1));
  INSERT INTO profiles (id, display_name) VALUES (NEW.id, v_name)
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

REVOKE EXECUTE ON FUNCTION handle_new_user() FROM PUBLIC, anon;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();
