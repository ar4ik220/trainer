/*
# Free-form skeleton editor + free detection engine

1. Overview
Adds a "free" detection engine so admins can create exercises for ANY body
position (lying on back, lying on stomach, sitting, etc.). The admin poses a
full-body skeleton in the editor — every joint is draggable — and defines
which angles to measure. A generic detection engine reads the skeleton
configuration and measures those angles from the camera in real time.

2. Schema changes
- `exercise_settings`
  - ADD column `skeleton jsonb NOT NULL DEFAULT '{}'::jsonb` — stores the
    full skeleton configuration for "free" exercises: joint positions
    (with MediaPipe landmark indices), bone links, angle definitions, and
    which angle is the primary rep-counting angle. Empty for built-in
    engines (squat/pushup/lunge/plank) which use their hardcoded skeletons.
  - MODIFY the `exercise_settings_base_kind_check` CHECK constraint to
    also allow 'free'.

3. Function
- `set_exercise_settings` — add `p_skeleton jsonb` param. Writes to the
    new `skeleton` column. Validation of base_kind now accepts 'free'.
- `delete_exercise_settings` — unchanged.

4. Security
- No grant or policy changes. `skeleton` inherits the table's existing
  SELECT-for-all / RPC-only-mutation posture.
*/

-- 1. Add skeleton column
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema='public' AND table_name='exercise_settings' AND column_name='skeleton'
  ) THEN
    ALTER TABLE exercise_settings ADD COLUMN skeleton jsonb NOT NULL DEFAULT '{}'::jsonb;
  END IF;
END $$;

-- 2. Allow 'free' as a base_kind
ALTER TABLE exercise_settings DROP CONSTRAINT IF EXISTS exercise_settings_base_kind_check;
ALTER TABLE exercise_settings ADD CONSTRAINT exercise_settings_base_kind_check
  CHECK (base_kind IN ('squat','pushup','lunge','plank','free'));

-- 3. Updated set_exercise_settings with skeleton param
CREATE OR REPLACE FUNCTION set_exercise_settings(
  p_kind text,
  p_base_kind text,
  p_name text,
  p_short text,
  p_unit text,
  p_goals int[],
  p_goal int,
  p_lede text,
  p_setup text[],
  p_rules text[],
  p_cfg jsonb,
  p_icon text,
  p_skeleton jsonb
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_is_admin boolean;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;
  IF p_kind IS NULL OR btrim(p_kind) = '' THEN
    RAISE EXCEPTION 'kind must not be empty';
  END IF;
  IF p_base_kind NOT IN ('squat','pushup','lunge','plank','free') THEN
    RAISE EXCEPTION 'Invalid base_kind';
  END IF;
  IF p_unit NOT IN ('reps','sec') THEN
    RAISE EXCEPTION 'Invalid unit';
  END IF;

  SELECT is_admin INTO v_is_admin FROM profiles WHERE id = v_uid;
  IF NOT FOUND OR v_is_admin IS NOT TRUE THEN
    RAISE EXCEPTION 'Forbidden: admin only';
  END IF;

  INSERT INTO exercise_settings
    (kind, base_kind, name, short, unit, goals, goal, lede, setup, rules, cfg, icon, skeleton, updated_at, updated_by)
  VALUES
    (p_kind, p_base_kind, p_name, p_short, p_unit, p_goals, p_goal, p_lede, p_setup, p_rules, p_cfg, p_icon, COALESCE(p_skeleton, '{}'::jsonb), now(), v_uid)
  ON CONFLICT (kind) DO UPDATE SET
    base_kind = EXCLUDED.base_kind,
    name = EXCLUDED.name,
    short = EXCLUDED.short,
    unit = EXCLUDED.unit,
    goals = EXCLUDED.goals,
    goal = EXCLUDED.goal,
    lede = EXCLUDED.lede,
    setup = EXCLUDED.setup,
    rules = EXCLUDED.rules,
    cfg = EXCLUDED.cfg,
    icon = EXCLUDED.icon,
    skeleton = EXCLUDED.skeleton,
    updated_at = now(),
    updated_by = v_uid;
END;
$$;

REVOKE EXECUTE ON FUNCTION set_exercise_settings(text, text, text, text, text, int[], int, text, text[], text[], jsonb, text, jsonb) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION set_exercise_settings(text, text, text, text, text, int[], int, text, text[], text[], jsonb, text, jsonb) TO authenticated;
