import { useRef, useState, useCallback, type PointerEvent as RPE } from 'react';
import {
  type SkeletonDef, type SkeletonAngleDef,
  LANDMARKS, LANDMARKS_BY_ID, POSE_PRESETS, presetToSkeleton,
} from '@/lib/formaEngine';
import { Plus, Trash2, RotateCcw } from 'lucide-react';

type Pt = { x: number; y: number; lm: number };

type EditorJoint = Pt;
type EditorAngle = {
  id: string;
  label: string;
  a: string; b: string; c: string;
  primary: boolean;
};

type EditorState = {
  joints: Record<string, EditorJoint>;
  links: [string, string][];
  angles: EditorAngle[];
};

function skeletonToEditor(s: SkeletonDef): EditorState {
  const joints: Record<string, EditorJoint> = {};
  const usedLm = new Set<number>();
  for (const [jid, lm] of Object.entries(s.joints)) {
    usedLm.add(lm);
    joints[jid] = { x: 180, y: 150, lm };
  }
  // Seed positions from a preset if any matches, otherwise default grid.
  let seeded = false;
  for (const p of POSE_PRESETS) {
    if (p.id === 'blank') continue;
    const presetLms = new Set(Object.values(p.joints).map((j) => j.lm));
    if ([...usedLm].every((l) => presetLms.has(l)) && usedLm.size === presetLms.size) {
      for (const [jid, j] of Object.entries(p.joints)) {
        const match = Object.entries(s.joints).find(([, lm]) => lm === j.lm)?.[0];
        if (match) joints[match] = { x: j.x, y: j.y, lm: j.lm };
      }
      seeded = true;
      break;
    }
  }
  if (!seeded) {
    const entries = Object.entries(joints);
    entries.forEach(([, j], i) => {
      const col = i % 4, row = Math.floor(i / 4);
      j.x = 80 + col * 80;
      j.y = 80 + row * 70;
    });
  }
  return {
    joints,
    links: s.links.filter(([a, b]) => joints[a] && joints[b]) as [string, string][],
    angles: s.angles.map((a, i) => {
      const ja = Object.entries(s.joints).find(([, lm]) => lm === a.a)?.[0] ?? '';
      const jb = Object.entries(s.joints).find(([, lm]) => lm === a.b)?.[0] ?? '';
      const jc = Object.entries(s.joints).find(([, lm]) => lm === a.c)?.[0] ?? '';
      return { id: a.cfgKey || ('a' + (i + 1)), label: a.label, a: ja, b: jb, c: jc, primary: !!a.primary };
    }),
  };
}

function editorToSkeleton(st: EditorState): SkeletonDef {
  const joints: Record<string, number> = {};
  for (const [jid, j] of Object.entries(st.joints)) joints[jid] = j.lm;
  return {
    joints,
    links: st.links,
    angles: st.angles.map((a) => ({
      cfgKey: a.id,
      a: st.joints[a.a]?.lm ?? 0,
      b: st.joints[a.b]?.lm ?? 0,
      c: st.joints[a.c]?.lm ?? 0,
      label: a.label,
      primary: a.primary,
    })),
  };
}

let jointCounter = 0;
const newJointId = () => `j${++jointCounter}`;

function angleAt(ax: number, ay: number, bx: number, by: number, cx: number, cy: number): number {
  const v1x = ax - bx, v1y = ay - by, v2x = cx - bx, v2y = cy - by;
  const m = Math.hypot(v1x, v1y) * Math.hypot(v2x, v2y);
  if (!m) return 180;
  const d = (v1x * v2x + v1y * v2y) / m;
  return Math.round((Math.acos(Math.max(-1, Math.min(1, d))) * 180) / Math.PI);
}

type Props = {
  skeleton: SkeletonDef;
  onChange: (s: SkeletonDef) => void;
};

export default function FreeSkeletonEditor({ skeleton, onChange }: Props) {
  const [st, setSt] = useState<EditorState>(() => skeletonToEditor(skeleton));
  const [preset, setPreset] = useState<string>('standing');
  const [selJoint, setSelJoint] = useState<string | null>(null);
  const svgRef = useRef<SVGSVGElement | null>(null);
  const dragRef = useRef<{ id: string } | null>(null);

  const push = useCallback((next: EditorState) => {
    setSt(next);
    onChange(editorToSkeleton(next));
  }, [onChange]);

  const toSvg = useCallback((clientX: number, clientY: number) => {
    const svg = svgRef.current;
    if (!svg) return { x: 0, y: 0 };
    const rect = svg.getBoundingClientRect();
    const x = ((clientX - rect.left) / rect.width) * 360;
    const y = ((clientY - rect.top) / rect.height) * 300;
    return { x: Math.max(15, Math.min(345, x)), y: Math.max(15, Math.min(285, y)) };
  }, []);

  const onPointerDown = (id: string) => (e: RPE) => {
    e.preventDefault();
    (e.target as Element).setPointerCapture?.(e.pointerId);
    dragRef.current = { id };
    setSelJoint(id);
  };

  const onPointerMove = (e: RPE) => {
    if (!dragRef.current) return;
    const p = toSvg(e.clientX, e.clientY);
    const id = dragRef.current.id;
    setSt((prev) => {
      const next = { ...prev, joints: { ...prev.joints, [id]: { ...prev.joints[id], x: p.x, y: p.y } } };
      onChange(editorToSkeleton(next));
      return next;
    });
  };

  const onPointerUp = () => { dragRef.current = null; };

  const applyPreset = (pid: string) => {
    setPreset(pid);
    const p = POSE_PRESETS.find((x) => x.id === pid);
    if (!p) return;
    jointCounter = 0;
    const joints: Record<string, EditorJoint> = {};
    for (const [jid, j] of Object.entries(p.joints)) joints[jid] = { x: j.x, y: j.y, lm: j.lm };
    const angles: EditorAngle[] = p.angles.map((a) => ({ ...a, primary: !!a.primary }));
    push({ joints, links: p.links, angles });
    setSelJoint(null);
  };

  const addJoint = () => {
    const id = newJointId();
    const next = { ...st, joints: { ...st.joints, [id]: { x: 180, y: 150, lm: 0 } } };
    push(next);
    setSelJoint(id);
  };

  const removeJoint = (id: string) => {
    const joints = { ...st.joints };
    delete joints[id];
    const links = st.links.filter(([a, b]) => a !== id && b !== id);
    const angles = st.angles.filter((a) => a.a !== id && a.b !== id && a.c !== id);
    push({ joints, links, angles });
    if (selJoint === id) setSelJoint(null);
  };

  const setJointLm = (id: string, lm: number) => {
    const next = { ...st, joints: { ...st.joints, [id]: { ...st.joints[id], lm } } };
    push(next);
  };

  const addAngle = () => {
    const ids = Object.keys(st.joints);
    if (ids.length < 3) return;
    const id = `a${st.angles.length + 1}`;
    push({ ...st, angles: [...st.angles, { id, label: 'Угол ' + (st.angles.length + 1), a: ids[0], b: ids[1], c: ids[2], primary: st.angles.length === 0 }] });
  };

  const updateAngle = (id: string, patch: Partial<EditorAngle>) => {
    push({ ...st, angles: st.angles.map((a) => (a.id === id ? { ...a, ...patch } : a)) });
  };

  const removeAngle = (id: string) => {
    push({ ...st, angles: st.angles.filter((a) => a.id !== id) });
  };

  const setPrimary = (id: string) => {
    push({ ...st, angles: st.angles.map((a) => ({ ...a, primary: a.id === id })) });
  };

  const jointIds = Object.keys(st.joints);
  const liveAngleVal = (a: EditorAngle): number => {
    const ja = st.joints[a.a], jb = st.joints[a.b], jc = st.joints[a.c];
    if (!ja || !jb || !jc) return 0;
    return angleAt(ja.x, ja.y, jb.x, jb.y, jc.x, jc.y);
  };

  return (
    <div className="bg-bg border border-line rounded-2xl p-4">
      <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
        <span className="eyebrow">Скелет · все точки двигаются</span>
        <div className="flex items-center gap-2">
          <select
            value={preset}
            onChange={(e) => applyPreset(e.target.value)}
            className="admin-input !w-auto !py-1.5 text-xs font-mono"
          >
            {POSE_PRESETS.map((p) => <option key={p.id} value={p.id}>{p.label}</option>)}
          </select>
        </div>
      </div>

      <svg
        ref={svgRef}
        viewBox="0 0 360 300"
        className="w-full h-auto touch-none select-none"
        style={{ maxHeight: 360 }}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerLeave={onPointerUp}
      >
        <line x1="10" y1="295" x2="350" y2="295" stroke="var(--line)" strokeWidth="2" strokeDasharray="4 5" />

        {st.links.map(([a, b], i) => {
          const ja = st.joints[a], jb = st.joints[b];
          if (!ja || !jb) return null;
          return <line key={i} x1={ja.x} y1={ja.y} x2={jb.x} y2={jb.y} stroke="var(--muted)" strokeWidth="4" strokeLinecap="round" />;
        })}

        {st.angles.map((a, i) => {
          const ja = st.joints[a.a], jb = st.joints[a.b], jc = st.joints[a.c];
          if (!ja || !jb || !jc) return null;
          const r = 24;
          const a1 = Math.atan2(ja.y - jb.y, ja.x - jb.x);
          const a2 = Math.atan2(jc.y - jb.y, jc.x - jb.x);
          const sweep = a2 > a1 ? 1 : 0;
          const x1 = jb.x + r * Math.cos(a1), y1 = jb.y + r * Math.sin(a1);
          const x2 = jb.x + r * Math.cos(a2), y2 = jb.y + r * Math.sin(a2);
          const large = Math.abs(a2 - a1) > Math.PI ? 1 : 0;
          const color = a.primary ? 'var(--good)' : 'var(--accent)';
          return (
            <g key={i}>
              <path d={`M ${x1} ${y1} A ${r} ${r} 0 ${large} ${sweep} ${x2} ${y2}`} fill="none" stroke={color} strokeWidth="2.5" opacity="0.75" />
              <text x={jb.x} y={jb.y - r - 4} textAnchor="middle" fontSize="12" fontFamily="'JetBrains Mono', monospace" fill={color} fontWeight="600">
                {liveAngleVal(a)}°
              </text>
            </g>
          );
        })}

        {Object.entries(st.joints).map(([id, p]) => {
          const lm = LANDMARKS_BY_ID[p.lm];
          const sel = selJoint === id;
          return (
            <g key={id}>
              <circle
                cx={p.x} cy={p.y} r={sel ? 10 : 8}
                fill={sel ? 'var(--accent)' : 'var(--accent)'}
                stroke={sel ? 'var(--good)' : 'var(--surface)'}
                strokeWidth={sel ? 3 : 2}
                className="cursor-grab"
                onPointerDown={onPointerDown(id)}
                style={{ cursor: 'grab' }}
              />
              <text x={p.x} y={p.y + 22} textAnchor="middle" fontSize="9" fontFamily="'JetBrains Mono', monospace" fill="var(--muted)">
                {lm?.ru ?? p.lm}
              </text>
            </g>
          );
        })}
      </svg>

      {/* Selected joint controls */}
      {selJoint && st.joints[selJoint] && (
        <div className="mt-3 bg-surface border border-line rounded-xl p-3 flex items-center gap-3 flex-wrap">
          <span className="eyebrow">Точка: {LANDMARKS_BY_ID[st.joints[selJoint].lm]?.ru ?? st.joints[selJoint].lm}</span>
          <select
            value={st.joints[selJoint].lm}
            onChange={(e) => setJointLm(selJoint, parseInt(e.target.value, 10))}
            className="admin-input !w-auto !py-1.5 text-sm font-mono"
          >
            {LANDMARKS.map((l) => <option key={l.id} value={l.id}>{l.ru}</option>)}
          </select>
          <button onClick={() => removeJoint(selJoint)} className="text-bad/70 hover:text-bad transition flex items-center gap-1 text-sm">
            <Trash2 size={14} /> Удалить точку
          </button>
        </div>
      )}

      <div className="flex items-center justify-between mt-3 mb-2">
        <span className="eyebrow">Углы</span>
        <button onClick={addAngle} disabled={jointIds.length < 3} className="text-accent hover:text-ink transition flex items-center gap-1 text-sm disabled:opacity-40">
          <Plus size={14} /> Добавить угол
        </button>
      </div>

      {st.angles.length === 0 ? (
        <p className="text-xs text-muted">Нет углов. Добавьте хотя бы один — он будет основным для подсчёта повторений.</p>
      ) : (
        <div className="space-y-2">
          {st.angles.map((a) => (
            <div key={a.id} className="bg-surface border border-line rounded-xl p-3">
              <div className="flex items-center gap-2 mb-2">
                <input
                  value={a.label}
                  onChange={(e) => updateAngle(a.id, { label: e.target.value })}
                  className="admin-input !py-1.5 flex-1 text-sm"
                  placeholder="Название угла"
                />
                <span className="font-mono font-bold text-accent w-12 text-right">{liveAngleVal(a)}°</span>
                <label className="flex items-center gap-1.5 text-xs text-muted cursor-pointer whitespace-nowrap">
                  <input type="checkbox" checked={a.primary} onChange={() => setPrimary(a.id)} className="w-4 h-4 accent-[var(--accent)]" />
                  основной
                </label>
                <button onClick={() => removeAngle(a.id)} className="text-bad/70 hover:text-bad transition p-1">
                  <Trash2 size={14} />
                </button>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {(['a', 'b', 'c'] as const).map((pos) => (
                  <div key={pos}>
                    <span className="text-[10px] text-muted uppercase tracking-wide">{pos === 'b' ? 'вершина' : pos === 'a' ? 'от' : 'до'}</span>
                    <select
                      value={a[pos]}
                      onChange={(e) => updateAngle(a.id, { [pos]: e.target.value })}
                      className="admin-input !py-1.5 text-xs font-mono mt-0.5"
                    >
                      {jointIds.map((jid) => (
                        <option key={jid} value={jid}>{jid} · {LANDMARKS_BY_ID[st.joints[jid].lm]?.ru ?? st.joints[jid].lm}</option>
                      ))}
                    </select>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="flex items-center justify-between mt-3">
        <button onClick={addJoint} className="text-accent hover:text-ink transition flex items-center gap-1 text-sm">
          <Plus size={14} /> Добавить точку
        </button>
        <button
          onClick={() => applyPreset('standing')}
          className="text-muted hover:text-ink transition flex items-center gap-1 text-sm"
        >
          <RotateCcw size={14} /> Сбросить
        </button>
      </div>
      <p className="text-xs text-muted mt-2">
        Выберите позу сверху для старта. Тяните любую точку, чтобы поставить её как в кадре. Назначьте каждой точке сустав тела, затем задайте углы для контроля. Один угол отметьте как «основной» — по нему считаются повторения.
      </p>
    </div>
  );
}
