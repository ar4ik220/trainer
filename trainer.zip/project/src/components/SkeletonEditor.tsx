import { useRef, useState, useCallback, useEffect, type PointerEvent as RPE } from 'react';
import type { TrainerKind } from '@/lib/formaEngine';

/**
 * Interactive 2D stick-figure editor.
 * The admin drags joints; the angle at the relevant joint updates live and
 * is written back into the matching CFG field. Each exercise defines which
 * joints are draggable and which CFG key each angle maps to.
 *
 * Coordinate space: a 360x300 viewBox. The skeleton is drawn in side view
 * matching how the camera sees the user.
 */

type Pt = { x: number; y: number };

type JointDef = {
  id: string;
  label: string;
  /** CFG keys whose angle is measured at this joint (vertex). */
  angleKeys: { key: string; kind: 'inner' | 'lean' }[];
};

type EditableAngle = {
  /** which joint (vertex) this angle is measured at */
  vertex: string;
  /** the two other joints that form the angle */
  from: string;
  to: string;
  /** CFG key to write the angle value into */
  cfgKey: string;
  /** how the angle is computed: inner = standard 3-point angle; lean = leanDeg */
  mode: 'inner' | 'lean' | 'horiz';
};

type SkeletonConfig = {
  joints: Record<string, Pt>;
  links: [string, string][];
  angles: EditableAngle[];
  draggable: string[];
};

const CFG_LABELS: Record<string, string> = {
  depth: 'Глубина',
  leanMax: 'Наклон',
  bodyMin: 'Линия',
  front: 'Переднее',
  rear: 'Заднее',
  horizMax: 'Горизонт',
  minMs: 'Темп',
  attempt: 'Попытка',
  up: 'Верх',
  start: 'Старт',
};

const CONFIGS: Record<TrainerKind, SkeletonConfig> = {
  squat: {
    joints: {
      head: { x: 200, y: 60 },
      shoulder: { x: 210, y: 120 },
      hip: { x: 220, y: 200 },
      knee: { x: 250, y: 250 },
      ankle: { x: 200, y: 290 },
    },
    links: [['head', 'shoulder'], ['shoulder', 'hip'], ['hip', 'knee'], ['knee', 'ankle']],
    angles: [
      { vertex: 'knee', from: 'hip', to: 'ankle', cfgKey: 'depth', mode: 'inner' },
      { vertex: 'hip', from: 'shoulder', to: 'knee', cfgKey: 'leanMax', mode: 'lean' },
    ],
    draggable: ['knee', 'hip', 'shoulder', 'head', 'ankle'],
  },
  pushup: {
    joints: {
      head: { x: 300, y: 130 },
      shoulder: { x: 250, y: 150 },
      elbow: { x: 220, y: 200 },
      wrist: { x: 200, y: 240 },
      hip: { x: 180, y: 170 },
      ankle: { x: 80, y: 230 },
    },
    links: [['head', 'shoulder'], ['shoulder', 'elbow'], ['elbow', 'wrist'], ['shoulder', 'hip'], ['hip', 'ankle']],
    angles: [
      { vertex: 'elbow', from: 'shoulder', to: 'wrist', cfgKey: 'depth', mode: 'inner' },
      { vertex: 'hip', from: 'shoulder', to: 'ankle', cfgKey: 'bodyMin', mode: 'inner' },
    ],
    draggable: ['elbow', 'hip', 'shoulder', 'ankle', 'head', 'wrist'],
  },
  lunge: {
    joints: {
      head: { x: 200, y: 60 },
      shoulder: { x: 210, y: 120 },
      hip: { x: 220, y: 200 },
      frontKnee: { x: 270, y: 240 },
      frontAnkle: { x: 250, y: 290 },
      rearKnee: { x: 170, y: 270 },
      rearAnkle: { x: 120, y: 295 },
    },
    links: [
      ['head', 'shoulder'], ['shoulder', 'hip'],
      ['hip', 'frontKnee'], ['frontKnee', 'frontAnkle'],
      ['hip', 'rearKnee'], ['rearKnee', 'rearAnkle'],
    ],
    angles: [
      { vertex: 'frontKnee', from: 'hip', to: 'frontAnkle', cfgKey: 'front', mode: 'inner' },
      { vertex: 'rearKnee', from: 'hip', to: 'rearAnkle', cfgKey: 'rear', mode: 'inner' },
      { vertex: 'hip', from: 'shoulder', to: 'frontKnee', cfgKey: 'leanMax', mode: 'lean' },
    ],
    draggable: ['frontKnee', 'frontAnkle', 'rearKnee', 'rearAnkle', 'hip', 'shoulder', 'head'],
  },
  plank: {
    joints: {
      head: { x: 320, y: 140 },
      shoulder: { x: 270, y: 150 },
      elbow: { x: 250, y: 210 },
      wrist: { x: 240, y: 250 },
      hip: { x: 180, y: 160 },
      ankle: { x: 60, y: 200 },
    },
    links: [['head', 'shoulder'], ['shoulder', 'elbow'], ['elbow', 'wrist'], ['shoulder', 'hip'], ['hip', 'ankle']],
    angles: [
      { vertex: 'hip', from: 'shoulder', to: 'ankle', cfgKey: 'bodyMin', mode: 'inner' },
    ],
    draggable: ['hip', 'shoulder', 'ankle', 'head', 'elbow', 'wrist'],
  },
};

function angleAt(a: Pt, b: Pt, c: Pt): number {
  const v1x = a.x - b.x, v1y = a.y - b.y, v2x = c.x - b.x, v2y = c.y - b.y;
  const m = Math.hypot(v1x, v1y) * Math.hypot(v2x, v2y);
  if (!m) return 180;
  const d = (v1x * v2x + v1y * v2y) / m;
  return Math.round((Math.acos(Math.max(-1, Math.min(1, d))) * 180) / Math.PI);
}

function leanDeg(h: Pt, s: Pt): number {
  return Math.round((Math.atan2(Math.abs(s.x - h.x), Math.abs(h.y - s.y)) * 180) / Math.PI);
}

function horizDeg(s: Pt, a: Pt): number {
  return Math.round((Math.atan2(Math.abs(a.y - s.y), Math.abs(a.x - s.x)) * 180) / Math.PI);
}

function computeAngle(joints: Record<string, Pt>, a: EditableAngle): number {
  const v = joints[a.vertex], f = joints[a.from], t = joints[a.to];
  if (!v || !f || !t) return 0;
  if (a.mode === 'inner') return angleAt(f, v, t);
  if (a.mode === 'lean') return leanDeg(v, f);
  return horizDeg(v, t);
}

type Props = {
  kind: TrainerKind;
  cfg: Record<string, number>;
  onChange: (key: string, value: number) => void;
};

export default function SkeletonEditor({ kind, cfg, onChange }: Props) {
  const cfg_def = CONFIGS[kind];
  const [joints, setJoints] = useState<Record<string, Pt>>(() => {
    // Seed joint positions from current cfg angles, starting from the default
    // pose and bending the relevant joints to match the stored thresholds.
    const base = { ...cfg_def.joints };
    // For simplicity, start from defaults; the visual angle readout updates live.
    return base;
  });
  const svgRef = useRef<SVGSVGElement | null>(null);
  const dragRef = useRef<{ id: string } | null>(null);
  const [, force] = useState(0);

  const toSvg = useCallback((clientX: number, clientY: number): Pt => {
    const svg = svgRef.current;
    if (!svg) return { x: 0, y: 0 };
    const rect = svg.getBoundingClientRect();
    const x = ((clientX - rect.left) / rect.width) * 360;
    const y = ((clientY - rect.top) / rect.height) * 300;
    return { x: Math.max(20, Math.min(340, x)), y: Math.max(20, Math.min(280, y)) };
  }, []);

  const onPointerDown = (id: string) => (e: RPE) => {
    e.preventDefault();
    (e.target as Element).setPointerCapture?.(e.pointerId);
    dragRef.current = { id };
  };

  const onPointerMove = (e: RPE) => {
    if (!dragRef.current) return;
    const p = toSvg(e.clientX, e.clientY);
    const id = dragRef.current.id;
    setJoints((prev) => {
      const next = { ...prev, [id]: p };
      // recompute angles and write back
      for (const a of cfg_def.angles) {
        if (a.vertex === id || a.from === id || a.to === id) {
          const val = computeAngle(next, a);
          onChange(a.cfgKey, val);
        }
      }
      return next;
    });
  };

  const onPointerUp = () => { dragRef.current = null; };

  // re-render on external cfg changes (e.g. reset)
  useEffect(() => { force((n) => n + 1); }, [cfg]);

  const liveAngles = cfg_def.angles.map((a) => ({ ...a, value: computeAngle(joints, a) }));

  return (
    <div className="bg-bg border border-line rounded-2xl p-4">
      <div className="flex items-center justify-between mb-3">
        <span className="eyebrow">Скелет · тяните за точки</span>
        <button
          onClick={() => setJoints({ ...cfg_def.joints })}
          className="text-xs text-muted hover:text-ink transition"
        >
          Сброс позы
        </button>
      </div>
      <svg
        ref={svgRef}
        viewBox="0 0 360 300"
        className="w-full h-auto touch-none select-none"
        style={{ maxHeight: 360 }}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerLeave={onPointerUp}
      >
        {/* ground line */}
        <line x1="10" y1="295" x2="350" y2="295" stroke="var(--line)" strokeWidth="2" strokeDasharray="4 5" />

        {/* links */}
        {cfg_def.links.map(([a, b], i) => (
          <line
            key={i}
            x1={joints[a].x} y1={joints[a].y}
            x2={joints[b].x} y2={joints[b].y}
            stroke="var(--muted)"
            strokeWidth="4"
            strokeLinecap="round"
          />
        ))}

        {/* angle arcs */}
        {liveAngles.map((a, i) => {
          const v = joints[a.vertex], f = joints[a.from], t = joints[a.to];
          if (!v || !f || !t) return null;
          const r = 26;
          // draw a small arc at the vertex between the two segments
          const a1 = Math.atan2(f.y - v.y, f.x - v.x);
          const a2 = Math.atan2(t.y - v.y, t.x - v.x);
          const sweep = a2 > a1 ? 1 : 0;
          const x1 = v.x + r * Math.cos(a1);
          const y1 = v.y + r * Math.sin(a1);
          const x2 = v.x + r * Math.cos(a2);
          const y2 = v.y + r * Math.sin(a2);
          const large = Math.abs(a2 - a1) > Math.PI ? 1 : 0;
          return (
            <g key={i}>
              <path
                d={`M ${x1} ${y1} A ${r} ${r} 0 ${large} ${sweep} ${x2} ${y2}`}
                fill="none"
                stroke="var(--accent)"
                strokeWidth="2"
                opacity="0.7"
              />
              <text
                x={v.x}
                y={v.y - r - 4}
                textAnchor="middle"
                fontSize="13"
                fontFamily="'JetBrains Mono', monospace"
                fill="var(--accent)"
                fontWeight="600"
              >
                {a.value}°
              </text>
            </g>
          );
        })}

        {/* joints */}
        {Object.entries(joints).map(([id, p]) => {
          const draggable = cfg_def.draggable.includes(id);
          const angle = liveAngles.find((a) => a.vertex === id);
          return (
            <g key={id}>
              <circle
                cx={p.x}
                cy={p.y}
                r={draggable ? 9 : 6}
                fill={draggable ? 'var(--accent)' : 'var(--muted)'}
                stroke="var(--surface)"
                strokeWidth="2"
                className={draggable ? 'cursor-grab' : ''}
                onPointerDown={draggable ? onPointerDown(id) : undefined}
                style={{ cursor: draggable ? 'grab' : 'default' }}
              />
              {draggable && angle && (
                <text
                  x={p.x}
                  y={p.y + 22}
                  textAnchor="middle"
                  fontSize="10"
                  fontFamily="'JetBrains Mono', monospace"
                  fill="var(--muted)"
                >
                  {CFG_LABELS[angle.cfgKey] ?? angle.cfgKey}
                </text>
              )}
            </g>
          );
        })}
      </svg>

      <div className="grid grid-cols-2 gap-2 mt-3">
        {liveAngles.map((a) => (
          <div key={a.cfgKey} className="flex items-center justify-between bg-surface rounded-lg px-3 py-2 border border-line">
            <span className="text-xs text-muted font-mono">{CFG_LABELS[a.cfgKey] ?? a.cfgKey}</span>
            <span className="font-mono font-bold text-accent">{a.value}°</span>
          </div>
        ))}
      </div>
    </div>
  );
}
