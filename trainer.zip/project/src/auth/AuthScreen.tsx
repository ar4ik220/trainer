import { useState, type FormEvent } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/auth/AuthContext';

export default function AuthScreen() {
  const { refreshProfile } = useAuth();
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      if (mode === 'signup') {
        const { error: err } = await supabase.auth.signUp({
          email,
          password,
          options: { data: { display_name: displayName || email.split('@')[0] } },
        });
        if (err) throw err;
      } else {
        const { error: err } = await supabase.auth.signInWithPassword({ email, password });
        if (err) throw err;
      }
      await refreshProfile();
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Что-то пошло не так';
      setError(translateError(msg));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center screen-pad">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="eyebrow mb-3">ИИ-тренер · поза в реальном времени</div>
          <h1 className="font-display text-5xl sm:text-6xl tracking-tight">Форма</h1>
          <p className="text-muted mt-3 text-base max-w-xs mx-auto">
            Камера следит за суставами. Считаются только чистые повторения.
          </p>
        </div>

        <div className="bg-surface border border-line rounded-2xl p-6">
          <div className="flex gap-2 mb-6 p-1 bg-bg rounded-xl">
            <button
              type="button"
              onClick={() => setMode('signin')}
              className={`flex-1 py-2.5 rounded-lg font-display font-bold text-sm transition ${
                mode === 'signin' ? 'bg-accent text-white' : 'text-muted'
              }`}
            >
              Вход
            </button>
            <button
              type="button"
              onClick={() => setMode('signup')}
              className={`flex-1 py-2.5 rounded-lg font-display font-bold text-sm transition ${
                mode === 'signup' ? 'bg-accent text-white' : 'text-muted'
              }`}
            >
              Регистрация
            </button>
          </div>

          <form onSubmit={submit} className="space-y-4">
            {mode === 'signup' && (
              <div>
                <label className="eyebrow block mb-1.5" htmlFor="dn">Имя</label>
                <input
                  id="dn"
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  maxLength={16}
                  placeholder="Как тебя называть"
                  className="w-full bg-bg border border-line rounded-xl px-4 py-3.5 text-ink outline-none focus:border-accent"
                />
              </div>
            )}
            <div>
              <label className="eyebrow block mb-1.5" htmlFor="em">Email</label>
              <input
                id="em"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-bg border border-line rounded-xl px-4 py-3.5 text-ink outline-none focus:border-accent"
              />
            </div>
            <div>
              <label className="eyebrow block mb-1.5" htmlFor="pw">Пароль</label>
              <input
                id="pw"
                type="password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-bg border border-line rounded-xl px-4 py-3.5 text-ink outline-none focus:border-accent"
              />
            </div>

            {error && <p className="text-bad text-sm" role="alert">{error}</p>}

            <button
              type="submit"
              disabled={busy}
              className="w-full bg-accent text-white font-display font-bold py-4 rounded-xl disabled:opacity-60 transition hover:brightness-110"
            >
              {busy ? 'Подождите…' : mode === 'signup' ? 'Создать аккаунт' : 'Войти'}
            </button>
          </form>

          <p className="text-xs text-muted mt-4 text-center">
            {mode === 'signup' ? 'Уже есть аккаунт? ' : 'Нет аккаунта? '}
            <button
              type="button"
              className="text-accent underline"
              onClick={() => { setMode(mode === 'signup' ? 'signin' : 'signup'); setError(''); }}
            >
              {mode === 'signup' ? 'Войти' : 'Зарегистрироваться'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}

function translateError(msg: string): string {
  const m = msg.toLowerCase();
  if (m.includes('invalid login')) return 'Неверный email или пароль';
  if (m.includes('already registered') || m.includes('already been registered')) return 'Этот email уже зарегистрирован. Войдите.';
  if (m.includes('password')) return 'Пароль слишком короткий (минимум 6 символов)';
  if (m.includes('email')) return 'Проверьте email';
  if (m.includes('rate limit')) return 'Слишком много попыток. Подождите немного.';
  return msg;
}
