let actx: AudioContext | null = null;
let soundOn = true;

export function setSoundOn(v: boolean) {
  soundOn = v;
  if (!v) try { speechSynthesis.cancel(); } catch { /* ignore */ }
}

export function isSoundOn() {
  return soundOn;
}

export function beep(freq: number, ms: number) {
  if (!soundOn) return;
  try {
    actx = actx || new (window.AudioContext || (window as any).webkitAudioContext)();
    const o = actx.createOscillator();
    const g = actx.createGain();
    o.frequency.value = freq;
    o.type = 'sine';
    g.gain.value = 0.12;
    o.connect(g);
    g.connect(actx.destination);
    o.start();
    o.stop(actx.currentTime + ms / 1000);
  } catch { /* ignore */ }
}

export function say(t: string) {
  if (!soundOn || !('speechSynthesis' in window)) return;
  try {
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(t);
    u.lang = 'ru-RU';
    u.rate = 1.05;
    speechSynthesis.speak(u);
  } catch { /* ignore */ }
}

export function cancelSpeech() {
  try { speechSynthesis.cancel(); } catch { /* ignore */ }
}
