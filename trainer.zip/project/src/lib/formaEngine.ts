// Forma pose-detection engine — TypeScript port of the original forma_(1).html logic.
// Works on 33 MediaPipe Pose landmarks. Landmarks arrive in pixels: {x, y, v}.

export type Pt = { x: number; y: number; v: number };
export type Metric = { k: string; v: number; u: string; ok: boolean | null };
export type OutEvent =
  | { type: 'rep'; ok: boolean; reasons: string[]; n: number; bad: number }
  | { type: 'mark'; ok: true; seconds: number };

export type FrameOut = {
  ready: boolean;
  hint: string;
  cue: string;
  cueKind: 'info' | 'ok' | 'fault';
  flagged: Set<number>;
  metrics: Metric[];
  events: OutEvent[];
  pts: Pt[] | null;
  side: 'L' | 'R' | null;
};

export type Stats = {
  good: number;
  bad: number;
  reasons: Record<string, number>;
  log: { ok: boolean; reasons: string[] }[];
  holdGood: number;
  holdBad: number;
};

export type TrainerKind = 'squat' | 'pushup' | 'lunge' | 'plank';

/** Detection engine — the four hand-tuned ones plus 'free' (config-driven). */
export type EngineKind = TrainerKind | 'free';

/** Arbitrary exercise slug. Built-ins match an engine; custom ones are free text. */
export type ExerciseKey = string;

const VIS = 0.45;

const SIDES: Record<'L' | 'R', Record<string, number>> = {
  L: { S: 11, E: 13, W: 15, H: 23, K: 25, A: 27 },
  R: { S: 12, E: 14, W: 16, H: 24, K: 26, A: 28 },
};

export const LINKS: [number, number][] = [
  [11, 12], [11, 13], [13, 15], [12, 14], [14, 16],
  [11, 23], [12, 24], [23, 24], [23, 25], [25, 27], [24, 26], [26, 28],
  [27, 31], [28, 32],
];

export const CFG_DEFAULT = {
  squat: { depth: 105, leanMax: 65, minMs: 900, attempt: 135, up: 160, start: 150 },
  pushup: { depth: 95, bodyMin: 160, minMs: 600, attempt: 135, up: 155, start: 145, horizMax: 45 },
  lunge: { front: 105, rear: 130, leanMax: 35, minMs: 1000, attempt: 135, up: 160, start: 145 },
  plank: { bodyMin: 165, horizMax: 40 },
  free: { depth: 90, up: 160, start: 150, attempt: 135, minMs: 800, bodyMin: 160 },
} as const;

export let CFG: typeof CFG_DEFAULT = CFG_DEFAULT;

export function applyCfgOverrides(overrides: Record<string, Record<string, number>>) {
  CFG = {
    squat: { ...CFG_DEFAULT.squat, ...(overrides.squat || {}) },
    pushup: { ...CFG_DEFAULT.pushup, ...(overrides.pushup || {}) },
    lunge: { ...CFG_DEFAULT.lunge, ...(overrides.lunge || {}) },
    plank: { ...CFG_DEFAULT.plank, ...(overrides.plank || {}) },
  } as typeof CFG_DEFAULT;
}

/**
 * Apply per-engine cfg overrides. `perEngine` is keyed by engine name and is
 * the union of all custom + built-in exercises' cfg overrides merged by engine.
 */
export function applyEngineCfg(perEngine: Partial<Record<EngineKind, Record<string, number>>>) {
  CFG = {
    squat: { ...CFG_DEFAULT.squat, ...(perEngine.squat || {}) },
    pushup: { ...CFG_DEFAULT.pushup, ...(perEngine.pushup || {}) },
    lunge: { ...CFG_DEFAULT.lunge, ...(perEngine.lunge || {}) },
    plank: { ...CFG_DEFAULT.plank, ...(perEngine.plank || {}) },
  } as typeof CFG_DEFAULT;
}

type SideKey = 'L' | 'R';

function ang(a: Pt, b: Pt, c: Pt): number {
  const v1x = a.x - b.x, v1y = a.y - b.y, v2x = c.x - b.x, v2y = c.y - b.y;
  const m = Math.hypot(v1x, v1y) * Math.hypot(v2x, v2y);
  if (!m) return 180;
  const d = (v1x * v2x + v1y * v2y) / m;
  return (Math.acos(Math.max(-1, Math.min(1, d))) * 180) / Math.PI;
}

function leanDeg(h: Pt, s: Pt): number {
  return (Math.atan2(Math.abs(s.x - h.x), h.y - s.y) * 180) / Math.PI;
}

function horizDeg(s: Pt, a: Pt): number {
  return (Math.atan2(Math.abs(a.y - s.y), Math.abs(a.x - s.x)) * 180) / Math.PI;
}

function hipSag(s: Pt, h: Pt, a: Pt): boolean {
  const dx = a.x - s.x;
  if (Math.abs(dx) < 1) return false;
  const lineY = s.y + ((h.x - s.x) / dx) * (a.y - s.y);
  return h.y > lineY;
}

function hasVis(p: Pt[], idx: number[]): boolean {
  for (const i of idx) if (!p[i] || p[i].v < VIS) return false;
  return true;
}

function pickSide(st: TrainerState, p: Pt[], need: string[]): SideKey {
  const score = (k: SideKey) => {
    let t = 0;
    for (const n of need) {
      const q = p[SIDES[k][n]];
      t += q ? q.v : 0;
    }
    return t;
  };
  const l = score('L'), r = score('R');
  if (!st.side) st.side = l >= r ? 'L' : 'R';
  else if (st.side === 'L' && r > l * 1.25 + 0.2) st.side = 'R';
  else if (st.side === 'R' && l > r * 1.25 + 0.2) st.side = 'L';
  return st.side;
}

function smooth(st: TrainerState, raw: Pt[], now: number): Pt[] {
  const a = 0.6;
  if (!st.sm || now - st.smT > 600) {
    st.sm = raw.map((p) => ({ x: p.x, y: p.y, v: p.v }));
  } else {
    for (let i = 0; i < raw.length; i++) {
      const s = st.sm[i], q = raw[i];
      s.x += (q.x - s.x) * a;
      s.y += (q.y - s.y) * a;
      s.v = q.v;
    }
  }
  st.smT = now;
  return st.sm;
}

function lost(st: TrainerState, now: number) {
  if (!st.lostSince) st.lostSince = now;
  if (now - st.lostSince > 1500) {
    st.phase = 'up';
    st.rep = null;
  }
}

function finishRep(st: TrainerState, f: FrameIn, reasons: string[]) {
  const ev: OutEvent = { type: 'rep', ok: reasons.length === 0, reasons, n: st.stats.good, bad: st.stats.bad };
  if (st.counting) {
    if (ev.ok) st.stats.good++;
    else {
      st.stats.bad++;
      for (const r of reasons) st.stats.reasons[r] = (st.stats.reasons[r] || 0) + 1;
    }
    st.stats.log.push({ ok: ev.ok, reasons });
    ev.n = st.stats.good;
    ev.bad = st.stats.bad;
    f.out.events.push(ev);
  }
  st.phase = 'up';
  st.rep = null;
}

function setCue(out: FrameOut, text: string, kind: 'info' | 'ok' | 'fault' = 'info') {
  out.cue = text;
  out.cueKind = kind;
}

type Rep = { t0: number; min: number; maxLean: number; minBody: number; sag: boolean; pike: boolean; sum: number; a: number; b: number } | null;

type TrainerState = {
  kind: EngineKind;
  counting: boolean;
  phase: 'up' | 'down';
  rep: Rep;
  side: SideKey | null;
  lostSince: number;
  lastT: number;
  nextMark: number;
  sm: Pt[];
  smT: number;
  stats: Stats;
  /** Free-engine only: skeleton definition from DB. */
  skeleton: SkeletonDef | null;
  /** Free-engine only: runtime cfg (free-form key/value). */
  cfgFree: Record<string, number> | null;
  /** Free-engine only: 'reps' | 'sec'. */
  unit: 'reps' | 'sec';
};

type FrameIn = { p: Pt[]; now: number; dt: number; out: FrameOut };

function stepSquat(st: TrainerState, f: FrameIn) {
  const { p, now, out } = f;
  const C = CFG.squat;
  const s = SIDES[pickSide(st, p, ['S', 'H', 'K', 'A'])];
  out.side = st.side;
  if (!hasVis(p, [s.S, s.H, s.K, s.A])) {
    lost(st, now);
    out.hint = 'Встань боком к камере: в кадре должны быть плечо, бедро, колено и стопа';
    return;
  }
  st.lostSince = 0;
  out.ready = true;
  const knee = ang(p[s.H], p[s.K], p[s.A]);
  const lean = leanDeg(p[s.H], p[s.S]);
  let kneeOk: boolean | null = null;

  if (st.phase === 'up') {
    setCue(out, knee >= C.up ? 'Приседай' : '', 'info');
    if (knee < C.start) {
      st.phase = 'down';
      st.rep = { t0: now, min: knee, maxLean: lean, minBody: 0, sag: false, pike: false, sum: 0, a: 0, b: 0 };
    }
  } else {
    const r = st.rep!;
    if (knee < r.min) r.min = knee;
    if (knee < 135 && lean > r.maxLean) r.maxLean = lean;
    kneeOk = r.min <= C.depth;
    if (knee < 135 && lean > C.leanMax) {
      out.flagged.add(s.S); out.flagged.add(s.H);
      setCue(out, 'Выпрями спину', 'fault');
    } else if (r.min <= C.depth) setCue(out, 'Глубина есть, вставай', 'ok');
    else setCue(out, 'Ниже', 'info');
    if (knee >= C.up) {
      if (r.min > C.attempt) { st.phase = 'up'; st.rep = null; }
      else {
        const reasons: string[] = [];
        if (r.min > C.depth) reasons.push('Недостаточная глубина');
        if (r.maxLean > C.leanMax) reasons.push('Спина наклонена вперёд');
        if (now - r.t0 < C.minMs) reasons.push('Слишком быстро');
        finishRep(st, f, reasons);
      }
    }
  }
  out.metrics = [
    { k: 'Колено', v: Math.round(knee), u: '°', ok: kneeOk },
    { k: 'Наклон спины', v: Math.round(lean), u: '°', ok: lean <= C.leanMax },
  ];
}

function stepPushup(st: TrainerState, f: FrameIn) {
  const { p, now, out } = f;
  const C = CFG.pushup;
  const s = SIDES[pickSide(st, p, ['S', 'E', 'W', 'H', 'A'])];
  out.side = st.side;
  if (!hasVis(p, [s.S, s.E, s.W, s.H, s.A])) {
    lost(st, now);
    out.hint = 'Прими упор лёжа боком к камере: в кадре должны быть плечо, локоть, кисть, таз и стопа';
    return;
  }
  if (horizDeg(p[s.S], p[s.A]) > C.horizMax) {
    lost(st, now);
    out.hint = 'Прими упор лёжа боком к камере';
    return;
  }
  st.lostSince = 0;
  out.ready = true;
  const elbow = ang(p[s.S], p[s.E], p[s.W]);
  const body = ang(p[s.S], p[s.H], p[s.A]);
  const sag = hipSag(p[s.S], p[s.H], p[s.A]);
  let elbowOk: boolean | null = null;
  const bodyBad = body < C.bodyMin;

  if (bodyBad) {
    out.flagged.add(s.H);
    setCue(out, sag ? 'Таз провисает, подтяни живот' : 'Таз слишком высоко, опусти', 'fault');
  }
  if (st.phase === 'up') {
    if (!bodyBad) setCue(out, elbow >= C.up ? 'Опускайся' : '', 'info');
    if (elbow < C.start) {
      st.phase = 'down';
      st.rep = { t0: now, min: elbow, minBody: body, sag: false, pike: false, maxLean: 0, sum: 0, a: 0, b: 0 };
    }
  } else {
    const r = st.rep!;
    if (elbow < r.min) r.min = elbow;
    if (body < r.minBody) r.minBody = body;
    if (bodyBad) { if (sag) r.sag = true; else r.pike = true; }
    elbowOk = r.min <= C.depth;
    if (!bodyBad) setCue(out, r.min <= C.depth ? 'Глубина есть, выжимай' : 'Ниже', r.min <= C.depth ? 'ok' : 'info');
    if (elbow >= C.up) {
      if (r.min > C.attempt) { st.phase = 'up'; st.rep = null; }
      else {
        const reasons: string[] = [];
        if (r.min > C.depth) reasons.push('Недостаточно низко');
        if (r.sag) reasons.push('Таз провисает');
        if (r.pike) reasons.push('Таз поднят слишком высоко');
        if (now - r.t0 < C.minMs) reasons.push('Слишком быстро');
        finishRep(st, f, reasons);
      }
    }
  }
  out.metrics = [
    { k: 'Локоть', v: Math.round(elbow), u: '°', ok: elbowOk },
    { k: 'Линия корпуса', v: Math.round(body), u: '°', ok: !bodyBad },
  ];
}

function stepLunge(st: TrainerState, f: FrameIn) {
  const { p, now, out } = f;
  const C = CFG.lunge;
  const s = SIDES[pickSide(st, p, ['S', 'H'])];
  out.side = st.side;
  const legs = [23, 25, 27, 24, 26, 28];
  if (!hasVis(p, legs.concat([s.S]))) {
    lost(st, now);
    out.hint = 'Встань боком к камере: обе ноги и плечо должны быть в кадре';
    return;
  }
  st.lostSince = 0;
  out.ready = true;
  const kl = ang(p[23], p[25], p[27]);
  const kr = ang(p[24], p[26], p[28]);
  const front = Math.min(kl, kr);
  const rear = Math.max(kl, kr);
  const lean = leanDeg(p[s.H], p[s.S]);
  let depthOk: boolean | null = null;

  if (st.phase === 'up') {
    setCue(out, front >= C.up ? 'Шагни и опустись' : '', 'info');
    if (front < C.start) {
      st.phase = 'down';
      st.rep = { t0: now, sum: kl + kr, a: front, b: rear, maxLean: lean, min: 0, minBody: 0, sag: false, pike: false };
    }
  } else {
    const r = st.rep!;
    if (kl + kr < r.sum) { r.sum = kl + kr; r.a = front; r.b = rear; }
    if (front < 140 && lean > r.maxLean) r.maxLean = lean;
    depthOk = r.a <= C.front && r.b <= C.rear;
    if (front < 140 && lean > C.leanMax) {
      out.flagged.add(s.S); out.flagged.add(s.H);
      setCue(out, 'Держи корпус прямо', 'fault');
    } else if (depthOk) setCue(out, 'Глубина есть, вставай', 'ok');
    else if (r.b > C.rear) setCue(out, 'Опусти заднее колено', 'info');
    else setCue(out, 'Ниже', 'info');
    if (kl >= C.up && kr >= C.up) {
      if (r.a > C.attempt) { st.phase = 'up'; st.rep = null; }
      else {
        const reasons: string[] = [];
        if (r.a > C.front) reasons.push('Недостаточная глубина');
        if (r.b > C.rear) reasons.push('Заднее колено не опущено');
        if (r.maxLean > C.leanMax) reasons.push('Корпус наклонён');
        if (now - r.t0 < C.minMs) reasons.push('Слишком быстро');
        finishRep(st, f, reasons);
      }
    }
  }
  out.metrics = [
    { k: 'Переднее колено', v: Math.round(front), u: '°', ok: depthOk === null ? null : front <= C.front },
    { k: 'Наклон корпуса', v: Math.round(lean), u: '°', ok: lean <= C.leanMax },
  ];
}

function stepPlank(st: TrainerState, f: FrameIn) {
  const { p, now, out } = f;
  const C = CFG.plank;
  const s = SIDES[pickSide(st, p, ['S', 'H', 'A'])];
  out.side = st.side;
  if (!hasVis(p, [s.S, s.H, s.A])) {
    lost(st, now);
    out.hint = 'Прими упор на предплечьях боком к камере: всё тело должно быть в кадре';
    return;
  }
  if (horizDeg(p[s.S], p[s.A]) > C.horizMax) {
    lost(st, now);
    out.hint = 'Прими упор на предплечьях боком к камере';
    return;
  }
  st.lostSince = 0;
  out.ready = true;
  const body = ang(p[s.S], p[s.H], p[s.A]);
  const ok = body >= C.bodyMin;
  const sag = hipSag(p[s.S], p[s.H], p[s.A]);
  if (st.counting) {
    if (ok) st.stats.holdGood += f.dt;
    else st.stats.holdBad += f.dt;
    if (st.stats.holdGood >= st.nextMark) {
      out.events.push({ type: 'mark', ok: true, seconds: st.nextMark });
      st.nextMark += 10;
    }
  }
  if (ok) setCue(out, 'Отлично, держи', 'ok');
  else {
    out.flagged.add(s.H);
    setCue(out, sag ? 'Таз провисает, подтяни' : 'Таз высоко, опусти', 'fault');
  }
  out.metrics = [{ k: 'Линия корпуса', v: Math.round(body), u: '°', ok }];
}

/* ---------- Free-form generic engine ---------- */

/** A single angle definition in a free skeleton. */
export type SkeletonAngleDef = {
  /** cfg key this angle is written to and compared against */
  cfgKey: string;
  /** MediaPipe landmark indices for the three points forming the angle */
  a: number; b: number; c: number;
  /** label shown in the UI */
  label: string;
  /** whether this angle is the primary rep-counting angle (only one) */
  primary?: boolean;
};

/** Full skeleton definition for a "free" exercise, stored in DB as JSON. */
export type SkeletonDef = {
  /** abstract joint id -> MediaPipe landmark index */
  joints: Record<string, number>;
  /** bone links as pairs of joint ids */
  links: [string, string][];
  /** angle definitions */
  angles: SkeletonAngleDef[];
  /** optional: cfg keys controlling tempo/threshold (mirrors built-in cfg shape) */
};

/**
 * MediaPipe Pose landmark names -> indices (33-point model). Used by the free
 * skeleton editor so the admin picks human-readable joints instead of numbers.
 */
export const LANDMARKS: { id: number; name: string; ru: string }[] = [
  { id: 0, name: 'nose', ru: 'Нос' },
  { id: 11, name: 'L shoulder', ru: 'Левое плечо' },
  { id: 12, name: 'R shoulder', ru: 'Правое плечо' },
  { id: 13, name: 'L elbow', ru: 'Левый локоть' },
  { id: 14, name: 'R elbow', ru: 'Правый локоть' },
  { id: 15, name: 'L wrist', ru: 'Левое запястье' },
  { id: 16, name: 'R wrist', ru: 'Правое запястье' },
  { id: 23, name: 'L hip', ru: 'Левое бедро' },
  { id: 24, name: 'R hip', ru: 'Правое бедро' },
  { id: 25, name: 'L knee', ru: 'Левое колено' },
  { id: 26, name: 'R knee', ru: 'Правое колено' },
  { id: 27, name: 'L ankle', ru: 'Левая стопа' },
  { id: 28, name: 'R ankle', ru: 'Правая стопа' },
  { id: 31, name: 'L foot', ru: 'Левая пятка' },
  { id: 32, name: 'R foot', ru: 'Правая пятка' },
];

export const LANDMARKS_BY_ID: Record<number, { id: number; name: string; ru: string }> = Object.fromEntries(
  LANDMARKS.map((l) => [l.id, l]),
);

export type PosePreset = {
  id: string;
  label: string;
  /** default joint positions in 360x300 viewBox */
  joints: Record<string, { x: number; y: number; lm: number }>;
  links: [string, string][];
  angles: { id: string; label: string; a: string; b: string; c: string; primary?: boolean }[];
};

/**
 * Pose presets for the free skeleton editor. Each preset is a starting pose
 * + a suggested set of angles. The admin can then drag every joint, add or
 * remove angles, and pick which angle is the primary rep counter.
 */
export const POSE_PRESETS: PosePreset[] = [
  {
    id: 'standing',
    label: 'Стоя (боком)',
    joints: {
      head: { x: 200, y: 50, lm: 0 },
      shoulder: { x: 205, y: 110, lm: 12 },
      hip: { x: 210, y: 190, lm: 24 },
      knee: { x: 215, y: 250, lm: 26 },
      ankle: { x: 200, y: 295, lm: 28 },
    },
    links: [['head', 'shoulder'], ['shoulder', 'hip'], ['hip', 'knee'], ['knee', 'ankle']],
    angles: [{ id: 'a1', label: 'Колено', a: 'hip', b: 'knee', c: 'ankle', primary: true }],
  },
  {
    id: 'prone',
    label: 'Лёжа на животе',
    joints: {
      head: { x: 300, y: 150, lm: 0 },
      shoulder: { x: 240, y: 160, lm: 12 },
      elbow: { x: 200, y: 200, lm: 14 },
      wrist: { x: 180, y: 240, lm: 16 },
      hip: { x: 160, y: 165, lm: 24 },
      knee: { x: 110, y: 165, lm: 26 },
      ankle: { x: 60, y: 165, lm: 28 },
    },
    links: [['head', 'shoulder'], ['shoulder', 'elbow'], ['elbow', 'wrist'], ['shoulder', 'hip'], ['hip', 'knee'], ['knee', 'ankle']],
    angles: [{ id: 'a1', label: 'Локоть', a: 'shoulder', b: 'elbow', c: 'wrist', primary: true }],
  },
  {
    id: 'supine',
    label: 'Лёжа на спине',
    joints: {
      head: { x: 60, y: 150, lm: 0 },
      shoulder: { x: 120, y: 160, lm: 12 },
      hip: { x: 200, y: 165, lm: 24 },
      knee: { x: 250, y: 165, lm: 26 },
      ankle: { x: 300, y: 165, lm: 28 },
    },
    links: [['head', 'shoulder'], ['shoulder', 'hip'], ['hip', 'knee'], ['knee', 'ankle']],
    angles: [{ id: 'a1', label: 'Колено', a: 'hip', b: 'knee', c: 'ankle', primary: true }],
  },
  {
    id: 'side',
    label: 'На боку',
    joints: {
      head: { x: 50, y: 80, lm: 0 },
      shoulder: { x: 110, y: 90, lm: 12 },
      hip: { x: 210, y: 110, lm: 24 },
      knee: { x: 280, y: 140, lm: 26 },
      ankle: { x: 330, y: 175, lm: 28 },
    },
    links: [['head', 'shoulder'], ['shoulder', 'hip'], ['hip', 'knee'], ['knee', 'ankle']],
    angles: [{ id: 'a1', label: 'Колено', a: 'hip', b: 'knee', c: 'ankle', primary: true }],
  },
  {
    id: 'blank',
    label: 'Пустой',
    joints: {},
    links: [],
    angles: [],
  },
];

export function presetToSkeleton(preset: PosePreset): SkeletonDef {
  const joints: Record<string, number> = {};
  for (const [jid, j] of Object.entries(preset.joints)) joints[jid] = j.lm;
  return {
    joints,
    links: preset.links,
    angles: preset.angles.map((a) => ({
      cfgKey: a.id,
      a: preset.joints[a.a]?.lm ?? 0,
      b: preset.joints[a.b]?.lm ?? 0,
      c: preset.joints[a.c]?.lm ?? 0,
      label: a.label,
      primary: a.primary,
    })),
  };
}

function stepFree(st: TrainerState, f: FrameIn) {
  const { p, now, out } = f;
  const skel = st.skeleton;
  const C = st.cfgFree;
  if (!skel || !C) {
    out.hint = 'Конфигурация скелета не задана';
    return;
  }

  // Visibility: every landmark referenced by angle defs must be visible.
  const needIdx: number[] = [];
  for (const a of skel.angles) needIdx.push(a.a, a.b, a.c);
  if (!hasVis(p, needIdx)) {
    lost(st, now);
    out.hint = 'Встань так, чтобы камера видела все отслеживаемые суставы';
    return;
  }
  st.lostSince = 0;
  out.ready = true;

  // Compute all angles.
  const vals: Record<string, number> = {};
  for (const a of skel.angles) {
    vals[a.cfgKey] = Math.round(ang(p[a.a], p[a.b], p[a.c]));
  }

  // Find the primary angle.
  const primary = skel.angles.find((a) => a.primary) ?? skel.angles[0];
  const pk = primary?.cfgKey ?? 'primary';
  const pv = vals[pk] ?? 180;
  const up = C.up ?? 160;
  const start = C.start ?? 150;
  const depth = C.depth ?? 90;
  const attempt = C.attempt ?? 135;
  const minMs = C.minMs ?? 800;

  let primaryOk: boolean | null = null;

  if (st.unit === 'sec') {
    // Hold-based (like plank): good while primary angle satisfies threshold.
    const holdOk = pv >= (C.bodyMin ?? depth);
    if (st.counting) {
      if (holdOk) st.stats.holdGood += f.dt;
      else st.stats.holdBad += f.dt;
      if (st.stats.holdGood >= st.nextMark) {
        out.events.push({ type: 'mark', ok: true, seconds: st.nextMark });
        st.nextMark += 10;
      }
    }
    if (holdOk) setCue(out, 'Держи', 'ok');
    else setCue(out, 'Подправь положение', 'fault');
  } else {
    // Rep-based (like squat/pushup): phase machine on the primary angle.
    if (st.phase === 'up') {
      setCue(out, pv >= up ? 'Начинай' : '', 'info');
      if (pv < start) {
        st.phase = 'down';
        st.rep = { t0: now, min: pv, maxLean: 0, minBody: 0, sag: false, pike: false, sum: 0, a: 0, b: 0 };
      }
    } else {
      const r = st.rep!;
      if (pv < r.min) r.min = pv;
      primaryOk = r.min <= depth;
      if (r.min <= depth) setCue(out, 'Глубина есть, возвращайся', 'ok');
      else setCue(out, 'Ниже', 'info');
      if (pv >= up) {
        if (r.min > attempt) { st.phase = 'up'; st.rep = null; }
        else {
          const reasons: string[] = [];
          if (r.min > depth) reasons.push('Недостаточная глубина');
          // Check secondary angle thresholds (any angle with a min/max cfg value).
          for (const a of skel.angles) {
            if (a.primary) continue;
            const minKey = a.cfgKey + 'Min';
            const maxKey = a.cfgKey + 'Max';
            const v = vals[a.cfgKey];
            if (C[minKey] != null && v < C[minKey]) reasons.push(a.label + ' слишком мало');
            if (C[maxKey] != null && v > C[maxKey]) reasons.push(a.label + ' слишком велико');
          }
          if (now - r.t0 < minMs) reasons.push('Слишком быстро');
          finishRep(st, f, reasons);
        }
      }
    }
  }

  out.metrics = skel.angles.map((a) => ({
    k: a.label,
    v: vals[a.cfgKey],
    u: '°',
    ok: a.primary ? primaryOk : null,
  }));
}

const STEP: Partial<Record<EngineKind, (st: TrainerState, f: FrameIn) => void>> = {
  squat: stepSquat, pushup: stepPushup, lunge: stepLunge, plank: stepPlank, free: stepFree,
};

export type Trainer = {
  kind: EngineKind;
  stats: Stats;
  setCounting: (v: boolean) => void;
  update: (raw: Pt[] | null, now: number) => FrameOut;
};

export function createTrainer(kind: TrainerKind): Trainer {
  const st: TrainerState = {
    kind,
    counting: false,
    phase: 'up',
    rep: null,
    side: null,
    lostSince: 0,
    lastT: 0,
    nextMark: 10,
    sm: [],
    smT: 0,
    stats: { good: 0, bad: 0, reasons: {}, log: [], holdGood: 0, holdBad: 0 },
    skeleton: null,
    cfgFree: null,
    unit: 'reps',
  };
  return {
    kind,
    stats: st.stats,
    setCounting(v: boolean) {
      st.counting = !!v;
      st.lastT = 0;
      if (!v) { st.phase = 'up'; st.rep = null; }
    },
    update(raw: Pt[] | null, now: number): FrameOut {
      const out: FrameOut = {
        ready: false, hint: '', cue: '', cueKind: 'info',
        flagged: new Set<number>(), metrics: [], events: [],
        pts: null, side: st.side,
      };
      if (!raw) {
        lost(st, now);
        out.hint = 'Тебя не видно в кадре';
        return out;
      }
      const p = smooth(st, raw, now);
      out.pts = p;
      const dt = st.lastT ? Math.min(now - st.lastT, 250) / 1000 : 0;
      st.lastT = now;
      STEP[kind](st, { p, now, dt, out });
      return out;
    },
  };
}

/**
 * Create a trainer for a custom exercise that reuses one of the four detection
 * engines. The `engine` selects the detector (STEP[engine]); the cfg is read
 * from the global CFG keyed by engine.
 */
export function createTrainerForEngine(engine: EngineKind): Trainer {
  return createTrainer(engine as TrainerKind);
}

/**
 * Create a trainer for a "free" exercise. The skeleton definition and cfg are
 * passed in from the loaded settings.
 */
export function createFreeTrainer(
  skeleton: SkeletonDef,
  cfgFree: Record<string, number>,
  unit: 'reps' | 'sec',
): Trainer {
  const st: TrainerState = {
    kind: 'free',
    counting: false,
    phase: 'up',
    rep: null,
    side: null,
    lostSince: 0,
    lastT: 0,
    nextMark: 10,
    sm: [],
    smT: 0,
    stats: { good: 0, bad: 0, reasons: {}, log: [], holdGood: 0, holdBad: 0 },
    skeleton,
    cfgFree,
    unit,
  };
  return {
    kind: 'free',
    stats: st.stats,
    setCounting(v: boolean) {
      st.counting = !!v;
      st.lastT = 0;
      if (!v) { st.phase = 'up'; st.rep = null; }
    },
    update(raw: Pt[] | null, now: number): FrameOut {
      const out: FrameOut = {
        ready: false, hint: '', cue: '', cueKind: 'info',
        flagged: new Set<number>(), metrics: [], events: [],
        pts: null, side: st.side,
      };
      if (!raw) {
        lost(st, now);
        out.hint = 'Тебя не видно в кадре';
        return out;
      }
      const p = smooth(st, raw, now);
      out.pts = p;
      const dt = st.lastT ? Math.min(now - st.lastT, 250) / 1000 : 0;
      st.lastT = now;
      STEP.free!(st, { p, now, dt, out });
      return out;
    },
  };
}
