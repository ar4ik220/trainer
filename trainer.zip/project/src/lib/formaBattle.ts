// FormaBattle: pure battle state logic, host-authoritative. TypeScript port.

export type BattleMode = 'race' | 'timed';
export type BattleKind = string;

export type BattleCfg = {
  kind: BattleKind;
  mode: BattleMode;
  goal: number;
  dur: number;
};

export type BattlePlayer = {
  name: string;
  good: number;
  bad: number;
  hold: number;
  ready: boolean;
  fin: boolean;
  finAt: number;
  left: boolean;
};

export type BattlePhase = 'lobby' | 'setup' | 'countdown' | 'run' | 'ending' | 'end';

export type BattleState = {
  code: string;
  cfg: BattleCfg;
  phase: BattlePhase;
  order: string[];
  players: Record<string, BattlePlayer>;
  rank: string[] | null;
};

export const MAX_PLAYERS = 4;

export function cleanName(s: unknown): string {
  return String(s == null ? '' : s)
    .replace(/[\u0000-\u001f<>&"']/g, '')
    .trim()
    .slice(0, 16) || 'Игрок';
}

function clampNum(v: unknown, max: number): number {
  const n = Number(v);
  return Math.max(0, Math.min(max, isFinite(n) ? n : 0));
}

function mkPlayer(name: string): BattlePlayer {
  return {
    name: cleanName(name),
    good: 0,
    bad: 0,
    hold: 0,
    ready: false,
    fin: false,
    finAt: 0,
    left: false,
  };
}

export function newRoom(code: string, cfg: BattleCfg, hostName: string): BattleState {
  return {
    code,
    cfg,
    phase: 'lobby',
    order: ['host'],
    players: { host: mkPlayer(hostName) },
    rank: null,
  };
}

export function activePlayers(B: BattleState): string[] {
  return B.order.filter((id) => B.players[id] && !B.players[id].left);
}

export function addPlayer(B: BattleState, id: string, name: string): string | null {
  if (B.players[id]) return null;
  if (B.phase !== 'lobby') return 'Бой уже идёт';
  if (activePlayers(B).length >= MAX_PLAYERS) return `Комната заполнена (до ${MAX_PLAYERS} игроков)`;
  B.players[id] = mkPlayer(name);
  B.order.push(id);
  return null;
}

export function removePlayer(B: BattleState, id: string): void {
  const p = B.players[id];
  if (!p) return;
  if (B.phase === 'lobby') {
    delete B.players[id];
    B.order = B.order.filter((x) => x !== id);
  } else {
    p.left = true;
  }
}

export function setReady(B: BattleState, id: string): void {
  const p = B.players[id];
  if (p && B.phase === 'setup') p.ready = true;
}

export function applyStat(B: BattleState, id: string, m: { good: number; bad: number; hold: number }): void {
  const p = B.players[id];
  if (!p || p.left || (B.phase !== 'run' && B.phase !== 'ending')) return;
  p.good = Math.floor(clampNum(m.good, 999));
  p.bad = Math.floor(clampNum(m.bad, 999));
  p.hold = clampNum(m.hold, 3600);
}

export function markFin(B: BattleState, id: string, now: number): void {
  const p = B.players[id];
  if (!p || p.left || (B.phase !== 'run' && B.phase !== 'ending') || p.fin) return;
  p.fin = true;
  p.finAt = now;
}

export function nextPhase(B: BattleState): BattlePhase | null {
  const act = activePlayers(B);
  if (B.phase === 'setup') {
    if (act.length < 2) return 'end';
    if (act.every((id) => B.players[id].ready)) return 'countdown';
  } else if (B.phase === 'countdown') {
    if (act.length < 2) return 'end';
  } else if (B.phase === 'run') {
    if (act.length < 2) return 'ending';
    if (B.cfg.mode === 'race') {
      if (act.some((id) => B.players[id].fin)) return 'ending';
    } else if (act.every((id) => B.players[id].fin)) {
      return 'ending';
    }
  }
  return null;
}

function progress(B: BattleState, p: BattlePlayer): number {
  return p.hold;
}

export function computeRank(B: BattleState): string[] {
  const ids = B.order.filter((id) => B.players[id]);
  ids.sort((a, b) => {
    const pa = B.players[a], pb = B.players[b];
    if (pa.left !== pb.left) return pa.left ? 1 : -1;
    if (B.cfg.mode === 'race' && (pa.fin || pb.fin)) {
      if (pa.fin !== pb.fin) return pa.fin ? -1 : 1;
      if (pa.finAt !== pb.finAt) return pa.finAt - pb.finAt;
    }
    const d = progress(B, pb) - progress(B, pa);
    if (d) return d;
    return pa.bad - pb.bad;
  });
  return ids;
}

export function resetForRematch(B: BattleState): void {
  B.order = B.order.filter((id) => B.players[id] && !B.players[id].left);
  for (const id of Object.keys(B.players)) {
    if (!B.order.includes(id)) delete B.players[id];
  }
  for (const id of B.order) {
    const n = B.players[id].name;
    B.players[id] = mkPlayer(n);
  }
  B.phase = 'lobby';
  B.rank = null;
}
