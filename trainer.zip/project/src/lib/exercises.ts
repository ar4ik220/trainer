import { CFG, type EngineKind, type TrainerKind } from '@/lib/formaEngine';

export type Exercise = {
  name: string;
  short: string;
  unit: 'reps' | 'sec';
  goals: number[];
  goal: number;
  lede: string;
  setup: string[];
  rules: string[];
  /** Which of the four detection engines drives this exercise. */
  baseKind: EngineKind;
  /** Custom SVG icon; empty/undefined means "use the built-in icon for baseKind". */
  icon?: string;
};

/** Built-in exercises keyed by slug. Slugs match the four engines. */
export const EXERCISES: Record<TrainerKind, Exercise> = {
  squat: {
    name: 'Приседания',
    short: 'Колено, глубина и наклон спины',
    unit: 'reps',
    goals: [5, 10, 15, 20],
    goal: 10,
    lede: 'Тренер смотрит на сустав колена и линию спины сбоку.',
    setup: [
      'Поставь телефон на пол или стол на высоте пояса, в 2–3 метрах от себя.',
      'Встань боком к камере. В кадре всё тело от головы до стоп.',
      'Руки вытяни перед собой или скрести на груди.',
    ],
    rules: [
      `Глубина: колено сгибается до <b>${CFG.squat.depth}°</b> или глубже`,
      `Спина: наклон не больше <b>${CFG.squat.leanMax}°</b> от вертикали`,
      `Темп: одно повторение не быстрее <b>${CFG.squat.minMs / 1000} с</b>`,
      'Полный выход в стойку наверху',
    ],
    baseKind: 'squat',
  },
  pushup: {
    name: 'Отжимания',
    short: 'Локоть, глубина и прямая линия корпуса',
    unit: 'reps',
    goals: [5, 10, 15, 20],
    goal: 10,
    lede: 'Тренер смотрит на сгиб локтя и прямую линию плечо, таз, стопа.',
    setup: [
      'Поставь телефон на пол в 2–3 метрах от себя на уровне корпуса.',
      'Прими упор лёжа боком к камере. Видно плечо, локоть, кисть, таз и стопы.',
      'Освободи вокруг место: тело займёт в кадре около двух метров.',
    ],
    rules: [
      `Глубина: локоть сгибается до <b>${CFG.pushup.depth}°</b> или глубже`,
      `Корпус: линия плечо-таз-стопа не меньше <b>${CFG.pushup.bodyMin}°</b>, без провисшего или поднятого таза`,
      `Темп: повторение не быстрее <b>${CFG.pushup.minMs / 1000} с</b>`,
      'Полное выпрямление рук наверху',
    ],
    baseKind: 'pushup',
  },
  lunge: {
    name: 'Выпады',
    short: 'Оба колена и прямой корпус',
    unit: 'reps',
    goals: [6, 10, 16, 20],
    goal: 10,
    lede: 'Каждый выпад считается отдельно, ногу можно менять.',
    setup: [
      'Поставь телефон на пол или стол на высоте пояса, в 2–3 метрах от себя.',
      'Встань боком к камере, обе ноги и плечо в кадре.',
      'Шаг делай вдоль линии, а не на камеру.',
    ],
    rules: [
      `Переднее колено сгибается до <b>${CFG.lunge.front}°</b> или глубже`,
      `Заднее колено опускается до <b>${CFG.lunge.rear}°</b> или глубже`,
      `Корпус: наклон не больше <b>${CFG.lunge.leanMax}°</b>`,
      `Темп: повторение не быстрее <b>${CFG.lunge.minMs / 1000} с</b>`,
    ],
    baseKind: 'lunge',
  },
  plank: {
    name: 'Планка',
    short: 'Секунды, пока корпус ровный',
    unit: 'sec',
    goals: [20, 30, 45, 60],
    goal: 30,
    lede: 'Время идёт только пока тело держит прямую линию. Провис или подъём таза останавливают отсчёт.',
    setup: [
      'Поставь телефон на пол в 2 метрах от себя на уровне корпуса.',
      'Прими упор на предплечьях боком к камере.',
      'Плечи над локтями, взгляд в пол.',
    ],
    rules: [
      `Линия плечо-таз-стопа не меньше <b>${CFG.plank.bodyMin}°</b>`,
      'В зачёт идут только секунды с ровным корпусом',
      'Каждые 10 чистых секунд тренер подтверждает голосом',
    ],
    baseKind: 'plank',
  },
};

export const EXERCISE_ICONS: Record<TrainerKind, string> = {
  squat: `<svg viewBox="0 0 72 54" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><circle cx="30" cy="8" r="4.5"/><path d="M30 14 26 28 38 34 32 48M26 28 44 21M4 50h64" /></svg>`,
  pushup: `<svg viewBox="0 0 72 54" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><circle cx="60" cy="22" r="4.5"/><path d="M8 38 52 28M52 28 50 44M4 48h64"/></svg>`,
  lunge: `<svg viewBox="0 0 72 54" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><circle cx="34" cy="7" r="4.5"/><path d="M34 13v18l12 6v10M34 31 22 44l-14 2M4 50h64"/></svg>`,
  plank: `<svg viewBox="0 0 72 54" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><circle cx="62" cy="26" r="4.5"/><path d="M6 40 52 31M52 31v13h12M4 48h64"/></svg>`,
};

/** Default SVG icon for an engine (fallback for custom exercises with no icon). */
export const DEFAULT_ICON_SVG = EXERCISE_ICONS.squat;

export const BATTLE_ICONS_SVG = `<svg viewBox="0 0 72 54" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="12" r="4.5"/><path d="M18 18v14l-8 14M18 32l8 14M10 24l8-4 8 4"/><circle cx="54" cy="12" r="4.5"/><path d="M54 18v14l-8 14M54 32l8 14M46 24l8-4 8 4"/></svg>`;

export const MODES: Record<'race' | 'timed', string> = {
  race: 'Гонка',
  timed: 'На время · 60 с',
};

/**
 * Resolve the SVG markup for an exercise. Custom icon wins; otherwise the
 * built-in icon for the exercise's base engine is used.
 */
export function iconFor(ex: Exercise): string {
  if (ex.icon && ex.icon.trim()) return ex.icon;
  return EXERCISE_ICONS[ex.baseKind];
}
