import { supabase, type ExerciseSettingsRow } from '@/lib/supabase';
import { EXERCISES, iconFor, type Exercise } from '@/lib/exercises';
import { CFG, CFG_DEFAULT, type EngineKind, type TrainerKind, type SkeletonDef } from '@/lib/formaEngine';

export type ExerciseWithSkeleton = Exercise & {
  /** Skeleton def for free-engine exercises; null for built-in engines. */
  skeleton: SkeletonDef | null;
  /** Per-exercise cfg (own copy, not the merged global). */
  cfg: Record<string, number>;
};

export type MergedSettings = {
  /** All exercises (built-in + custom) keyed by slug. */
  exercises: Record<string, ExerciseWithSkeleton>;
  /** Order of exercise keys for display. */
  order: string[];
  /** Per-engine cfg overrides (merged from all exercises sharing that engine). */
  cfg: Record<EngineKind, Record<string, number>>;
  loaded: boolean;
};

const BUILTIN_KEYS = Object.keys(EXERCISES) as TrainerKind[];

function builtinWithSkeleton(k: TrainerKind): ExerciseWithSkeleton {
  return { ...EXERCISES[k], skeleton: null, cfg: { ...(CFG_DEFAULT as unknown as Record<string, Record<string, number>>)[k] } };
}

const FALLBACK: MergedSettings = {
  exercises: Object.fromEntries(BUILTIN_KEYS.map((k) => [k, builtinWithSkeleton(k)])) as Record<string, ExerciseWithSkeleton>,
  order: [...BUILTIN_KEYS],
  cfg: CFG as unknown as Record<EngineKind, Record<string, number>>,
  loaded: false,
};

let cache: MergedSettings = FALLBACK;
let inflight: Promise<MergedSettings> | null = null;

function mergeOne(row: ExerciseSettingsRow): { ex: ExerciseWithSkeleton; cfg: Record<string, number> } {
  const base = EXERCISES[row.kind as TrainerKind];
  const isBuiltin = !!base;
  const baseKind = (row.base_kind || (isBuiltin ? row.kind : 'squat')) as EngineKind;
  const baseForCfg = (CFG_DEFAULT as unknown as Record<string, Record<string, number>>)[baseKind];
  const cfg: Record<string, number> = { ...baseForCfg, ...(row.cfg || {}) };

  const skel = row.skeleton && 'joints' in row.skeleton ? (row.skeleton as SkeletonDef) : null;
  const skeleton = baseKind === 'free' ? skel : null;

  const ex: ExerciseWithSkeleton = {
    name: row.name || base?.name || row.kind,
    short: row.short || base?.short || '',
    unit: (row.unit as 'reps' | 'sec') || base?.unit || 'reps',
    goals: row.goals?.length ? row.goals : (base?.goals ?? [10]),
    goal: row.goal || base?.goal || 10,
    lede: row.lede || base?.lede || '',
    setup: row.setup?.length ? row.setup : (base?.setup ?? []),
    rules: row.rules?.length ? row.rules : (base?.rules ?? []),
    baseKind,
    icon: row.icon || undefined,
    skeleton,
    cfg,
  };
  return { ex, cfg };
}

export async function loadSettings(): Promise<MergedSettings> {
  if (cache.loaded) return cache;
  if (inflight) return inflight;
  inflight = (async () => {
    const { data, error } = await supabase
      .from('exercise_settings')
      .select('kind, base_kind, name, short, unit, goals, goal, lede, setup, rules, cfg, icon, skeleton, updated_at')
      .returns<ExerciseSettingsRow[]>();
    if (error || !data || data.length === 0) {
      cache = { ...FALLBACK, loaded: true };
      return cache;
    }
    const exercises: Record<string, ExerciseWithSkeleton> = {};
    const cfgAcc: Record<EngineKind, Record<string, number>> = {
      squat: { ...CFG_DEFAULT.squat },
      pushup: { ...CFG_DEFAULT.pushup },
      lunge: { ...CFG_DEFAULT.lunge },
      plank: { ...CFG_DEFAULT.plank },
      free: { ...CFG_DEFAULT.free },
    };
    // Keep built-in order first, then custom rows in updated_at order.
    const byKey = new Map<string, ExerciseSettingsRow>();
    for (const row of data) byKey.set(row.kind, row);
    const order: string[] = [];
    for (const k of BUILTIN_KEYS) {
      const row = byKey.get(k) ?? null;
      if (row) {
        const { ex, cfg } = mergeOne(row);
        exercises[k] = ex;
        Object.assign(cfgAcc[ex.baseKind], cfg);
      } else {
        exercises[k] = builtinWithSkeleton(k);
      }
      order.push(k);
    }
    for (const row of data) {
      if (BUILTIN_KEYS.includes(row.kind as TrainerKind)) continue;
      const { ex, cfg } = mergeOne(row);
      exercises[row.kind] = ex;
      Object.assign(cfgAcc[ex.baseKind], cfg);
      order.push(row.kind);
    }
    cache = { exercises, order, cfg: cfgAcc, loaded: true };
    return cache;
  })();
  return inflight;
}

export function getSettings(): MergedSettings {
  return cache;
}

export function resetSettings() {
  cache = FALLBACK;
  inflight = null;
}

export { iconFor };
