import { createClient } from '@supabase/supabase-js';
import type { SkeletonDef } from '@/lib/formaEngine';

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

if (!url || !anonKey) {
  throw new Error('Supabase env vars missing');
}

export const supabase = createClient(url, anonKey, {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
});

export type Profile = {
  id: string;
  display_name: string;
  solo_rating: number;
  battle_rating: number;
  solo_workouts: number;
  battles_played: number;
  is_admin: boolean;
};

export type ExerciseSettingsRow = {
  kind: string;
  base_kind: string;
  name: string;
  short: string;
  unit: 'reps' | 'sec';
  goals: number[];
  goal: number;
  lede: string;
  setup: string[];
  rules: string[];
  cfg: Record<string, number>;
  icon: string;
  skeleton: SkeletonDef | Record<string, never>;
  updated_at: string;
};

export type SessionRow = {
  id: string;
  user_id: string;
  kind: string;
  mode: 'solo' | 'battle';
  good: number;
  bad: number;
  pct: number;
  placement: number | null;
  opponents: number;
  rating_delta: number;
  created_at: string;
};

export type RecordSessionResult = {
  session_id: string;
  rating_delta: number;
  new_solo_rating: number;
  new_battle_rating: number;
};
