import { useEffect, useState } from 'react';
import { AuthProvider, useAuth } from '@/auth/AuthContext';
import AuthScreen from '@/auth/AuthScreen';
import HomeScreen from '@/screens/HomeScreen';
import PrepScreen from '@/screens/PrepScreen';
import TrainingScreen, { type SoloResult } from '@/screens/TrainingScreen';
import ResultScreen from '@/screens/ResultScreen';
import LeaderboardScreen from '@/screens/LeaderboardScreen';
import ProfileScreen from '@/screens/ProfileScreen';
import BattleScreen from '@/screens/BattleScreen';
import AdminPanelScreen from '@/screens/AdminPanelScreen';
import type { EngineKind } from '@/lib/formaEngine';
import { supabase, type SessionRow, type RecordSessionResult } from '@/lib/supabase';
import { beep, say } from '@/lib/sound';
import { loadSettings } from '@/lib/settings';
import { applyEngineCfg } from '@/lib/formaEngine';

type Route =
  | { name: 'home' }
  | { name: 'prep'; kind: string }
  | { name: 'train'; kind: string; goal: number; facing: 'user' | 'environment'; sound: boolean }
  | { name: 'result'; result: SoloResult; recorded: RecordSessionResult | null }
  | { name: 'leaderboard'; tab: 'solo' | 'battle' }
  | { name: 'profile' }
  | { name: 'battle' }
  | { name: 'admin' };

function Shell() {
  const { session, profile, loading, refreshProfile } = useAuth();
  const [route, setRoute] = useState<Route>({ name: 'home' });
  const [sessions, setSessions] = useState<SessionRow[]>([]);

  useEffect(() => {
    if (!session?.user.id) return;
    supabase
      .from('sessions')
      .select('id, user_id, kind, mode, good, bad, pct, placement, opponents, rating_delta, created_at')
      .eq('user_id', session.user.id)
      .order('created_at', { ascending: false })
      .limit(30)
      .then(({ data }) => { setSessions((data as SessionRow[]) ?? []); });
  }, [session, route]);

  useEffect(() => {
    loadSettings().then((s) => applyEngineCfg(s.cfg as unknown as Partial<Record<EngineKind, Record<string, number>>>));
  }, [session]);

  if (loading) {
    return (
      <div className="min-h-screen grid place-items-center bg-bg">
        <div className="spin w-10 h-10 rounded-full border-[3px] border-line border-t-[var(--accent)]" />
      </div>
    );
  }

  if (!session || !profile) {
    return <AuthScreen />;
  }

  const goHome = () => setRoute({ name: 'home' });

  switch (route.name) {
    case 'home':
      return (
        <HomeScreen
          sessions={sessions}
          onPickExercise={(k) => setRoute({ name: 'prep', kind: k })}
          onOpenBattle={() => setRoute({ name: 'battle' })}
          onOpenLeaderboard={(tab) => setRoute({ name: 'leaderboard', tab })}
          onOpenProfile={() => setRoute({ name: 'profile' })}
          onOpenAdmin={() => setRoute({ name: 'admin' })}
        />
      );

    case 'prep':
      return (
        <PrepScreen
          kind={route.kind}
          onBack={goHome}
          onStart={(goal, facing, sound) => setRoute({ name: 'train', kind: route.kind, goal, facing, sound })}
        />
      );

    case 'train':
      return (
        <TrainingScreen
          kind={route.kind}
          goal={route.goal}
          facing={route.facing}
          sound={route.sound}
          onExit={() => setRoute({ name: 'prep', kind: route.kind })}
          onFinish={async (result) => {
            // Record solo session to Supabase via the security-definer RPC.
            let recorded: RecordSessionResult | null = null;
            try {
              const { data } = await supabase.rpc('record_session', {
                p_kind: result.kind,
                p_mode: 'solo',
                p_good: result.good,
                p_bad: result.bad,
                p_pct: result.pct,
                p_placement: null,
                p_opponents: 0,
              });
              recorded = (data as RecordSessionResult) ?? null;
            } catch {
              recorded = null;
            }
            await refreshProfile();
            beep(880, 150);
            say('Подход выполнен. Чистая техника ' + result.pct + ' процентов');
            setRoute({ name: 'result', result, recorded });
          }}
        />
      );

    case 'result':
      return (
        <ResultScreen
          kind={route.result.kind}
          good={route.result.good}
          bad={route.result.bad}
          holdGood={route.result.holdGood}
          holdBad={route.result.holdBad}
          pct={route.result.pct}
          result={route.recorded}
          onAgain={() => setRoute({ name: 'prep', kind: route.result.kind })}
          onHome={goHome}
        />
      );

    case 'leaderboard':
      return <LeaderboardScreen initialTab={route.tab} onBack={goHome} />;

    case 'profile':
      return <ProfileScreen onBack={goHome} />;

    case 'battle':
      return <BattleScreen onExit={goHome} />;

    case 'admin':
      return <AdminPanelScreen onBack={goHome} />;
  }
}

export default function App() {
  return (
    <AuthProvider>
      <Shell />
    </AuthProvider>
  );
}
