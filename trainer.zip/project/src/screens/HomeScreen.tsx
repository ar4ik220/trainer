import { useMemo } from 'react';
import type { SessionRow } from '@/lib/supabase';
import { BATTLE_ICONS_SVG } from '@/lib/exercises';
import { getSettings, iconFor } from '@/lib/settings';
import { useAuth } from '@/auth/AuthContext';
import { Trophy, User, LogOut, Activity, Swords, Shield } from 'lucide-react';

type Props = {
  sessions: SessionRow[];
  onPickExercise: (k: string) => void;
  onOpenBattle: () => void;
  onOpenLeaderboard: (tab: 'solo' | 'battle') => void;
  onOpenProfile: () => void;
  onOpenAdmin: () => void;
};

export default function HomeScreen({
  sessions,
  onPickExercise,
  onOpenBattle,
  onOpenLeaderboard,
  onOpenProfile,
  onOpenAdmin,
}: Props) {
  const { profile, signOut } = useAuth();
  const recent = useMemo(() => sessions.slice(0, 6), [sessions]);
  const fmt = new Intl.DateTimeFormat('ru', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });

  return (
    <div className="min-h-screen screen-pad">
      <div className="max-w-3xl mx-auto">
        <header className="flex items-center justify-between gap-4 mb-6">
          <div>
            <div className="eyebrow">ИИ-тренер · поза в реальном времени</div>
            <h1 className="font-display text-5xl sm:text-6xl tracking-tight mt-2">Форма</h1>
          </div>
          <div className="flex items-center gap-2">
            {profile?.is_admin && (
              <button
                onClick={onOpenAdmin}
                className="bg-surface border border-line rounded-xl p-2.5 hover:border-accent transition"
                title="Админ-панель"
              >
                <Shield size={16} className="text-accent" />
              </button>
            )}
            <button
              onClick={onOpenProfile}
              className="flex items-center gap-2 bg-surface border border-line rounded-xl px-3 py-2 text-sm hover:border-accent transition"
            >
              <User size={16} className="text-accent" />
              <span className="font-display font-bold max-w-[120px] truncate">{profile?.display_name || 'Профиль'}</span>
            </button>
            <button
              onClick={signOut}
              className="bg-surface border border-line rounded-xl p-2.5 hover:border-bad transition"
              title="Выйти"
            >
              <LogOut size={16} className="text-muted" />
            </button>
          </div>
        </header>

        {/* Rating cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
          <RatingCard
            label="Рейтинг за баттлы"
            rating={profile?.battle_rating ?? 1000}
            count={profile?.battles_played ?? 0}
            countLabel="баттлов сыграно"
            icon={<Swords size={18} className="text-accent" />}
            onClick={() => onOpenLeaderboard('battle')}
          />
          <RatingCard
            label="Рейтинг за одиночные"
            rating={profile?.solo_rating ?? 1000}
            count={profile?.solo_workouts ?? 0}
            countLabel="тренировок выполнено"
            icon={<Activity size={18} className="text-good" />}
            onClick={() => onOpenLeaderboard('solo')}
          />
        </div>

        <p className="text-muted mb-5 max-w-xl">
          Камера следит за суставами. В счёт идут только повторения с правильной техникой, остальные тренер отклоняет и называет причину.
        </p>

        <h3 className="eyebrow mb-3">Упражнения</h3>
        <div className="grid gap-3 mb-8">
          {getSettings().order.map((k) => {
            const ex = getSettings().exercises[k];
            if (!ex) return null;
            return (
              <button
                key={k}
                onClick={() => onPickExercise(k)}
                className="group flex items-center gap-4 bg-surface border border-line rounded-2xl p-4 text-left hover:border-accent transition"
              >
                <div
                  className="w-16 h-12 text-accent shrink-0"
                  dangerouslySetInnerHTML={{ __html: iconFor(ex) }}
                />
                <div className="min-w-0 flex-1">
                  <div className="font-display font-bold text-lg">{ex.name}</div>
                  <div className="text-muted text-sm">{ex.short}</div>
                </div>
                <span className="font-mono text-xl text-muted group-hover:text-accent transition">→</span>
              </button>
            );
          })}
        </div>

        <h3 className="eyebrow mb-3">С друзьями</h3>
        <button
          onClick={onOpenBattle}
          className="w-full flex items-center gap-4 bg-surface border border-line rounded-2xl p-4 text-left hover:border-accent transition mb-8"
        >
          <div className="w-16 h-12 text-accent shrink-0" dangerouslySetInnerHTML={{ __html: BATTLE_ICONS_SVG }} />
          <div className="min-w-0 flex-1">
            <div className="font-display font-bold text-lg">Баттл</div>
            <div className="text-muted text-sm">Соревнование в реальном времени, до 4 игроков по коду комнаты</div>
          </div>
          <span className="font-mono text-xl text-muted">→</span>
        </button>

        <h3 className="eyebrow mb-3">Последние тренировки</h3>
        {recent.length === 0 ? (
          <p className="text-muted">Пока пусто. Выбери упражнение выше.</p>
        ) : (
          <div className="border-t border-line">
            {recent.map((r) => {
              const ex = getSettings().exercises[r.kind];
              const label = ex?.name || r.kind;
              const subtitle = r.mode === 'battle' ? 'баттл' : 'соло';
              const value = (ex?.unit === 'sec') ? `${Math.round(r.good)} с чисто` : `${r.good} из ${r.good + r.bad}`;
              const delta = r.rating_delta;
              return (
                <div
                  key={r.id}
                  className="flex items-baseline justify-between gap-3 py-3 border-b border-line"
                >
                  <div className="min-w-0">
                    <div className="font-medium truncate">{label} · {subtitle}</div>
                    <div className="eyebrow mt-0.5">{fmt.format(new Date(r.created_at))}</div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="font-mono text-sm tabular-nums">{value}</div>
                    <div className={`font-mono text-xs tabular-nums ${delta > 0 ? 'text-good' : delta < 0 ? 'text-bad' : 'text-muted'}`}>
                      {delta > 0 ? '+' : ''}{delta} рейтинг
                    </div>
                  </div>
                  <div className="font-mono text-sm text-muted tabular-nums w-12 text-right">{r.pct}%</div>
                </div>
              );
            })}
          </div>
        )}

        <p className="text-xs text-muted mt-6">Видео не покидает устройство: поза распознаётся прямо в браузере.</p>
      </div>
    </div>
  );
}

function RatingCard({
  label,
  rating,
  count,
  countLabel,
  icon,
  onClick,
}: {
  label: string;
  rating: number;
  count: number;
  countLabel: string;
  icon: React.ReactNode;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="text-left bg-surface border border-line rounded-2xl p-5 hover:border-accent transition group"
    >
      <div className="flex items-center justify-between mb-2">
        <span className="eyebrow">{label}</span>
        {icon}
      </div>
      <div className="font-display font-bold text-4xl tabular-nums tracking-tight">{rating}</div>
      <div className="text-muted text-sm mt-1">
        <span className="font-mono">{count}</span> {countLabel}
      </div>
      <div className="flex items-center gap-1.5 mt-3 text-accent text-sm font-display font-bold opacity-0 group-hover:opacity-100 transition">
        <Trophy size={14} /> Таблица лидеров
      </div>
    </button>
  );
}
