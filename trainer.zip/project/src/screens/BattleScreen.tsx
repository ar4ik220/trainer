import { useCallback, useEffect, useRef, useState } from 'react';
import { supabase, type RecordSessionResult } from '@/lib/supabase';
import { getSettings } from '@/lib/settings';
import { MODES } from '@/lib/exercises';
import { useAuth } from '@/auth/AuthContext';
import { beep, say, cancelSpeech } from '@/lib/sound';
import { ArrowLeft, Copy, Swords, LogOut, Play, Users, RefreshCw, DoorOpen, Check, Crown, Medal, TrendingUp, TrendingDown, Minus, Trophy } from 'lucide-react';
import TrainingScreen from '@/screens/TrainingScreen';

const ALPHA = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
const genCode = () => Array.from({ length: 5 }, () => ALPHA[Math.floor(Math.random() * ALPHA.length)]).join('');

type BattleMode = 'race' | 'timed';
type Phase = 'lobby' | 'setup' | 'countdown' | 'run' | 'ending' | 'end';

type RoomRow = {
  id: string;
  code: string;
  host_id: string;
  host_name: string;
  kind: string;
  kind_name: string;
  mode: BattleMode;
  goal: number;
  dur: number;
  phase: Phase;
  rank: string[] | null;
  max_players: number;
  created_at: string;
};

type PlayerRow = {
  id: string;
  room_id: string;
  user_id: string;
  display_name: string;
  good: number;
  bad: number;
  hold: number;
  ready: boolean;
  fin: boolean;
  fin_at: string | null;
  is_left: boolean;
};

type View = 'entry' | 'room' | 'train' | 'result';

type Props = { onExit: () => void };

export default function BattleScreen({ onExit }: Props) {
  const { profile } = useAuth();
  const [view, setView] = useState<View>('entry');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [code, setCode] = useState('');
  const [room, setRoom] = useState<RoomRow | null>(null);
  const [players, setPlayers] = useState<PlayerRow[]>([]);
  const [externalPhase, setExternalPhase] = useState<'position' | 'countdown' | 'run' | 'wait' | 'idle'>('idle');
  const [battleResult, setBattleResult] = useState<{ rank: string[]; players: PlayerRow[]; room: RoomRow; recorded?: RecordSessionResult | null } | null>(null);

  const roomRef = useRef<RoomRow | null>(null);
  roomRef.current = room;
  const playersRef = useRef<PlayerRow[]>([]);
  playersRef.current = players;
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);
  const leftRef = useRef(false);
  const recordedRef = useRef(false);
  const sentReadyRef = useRef(false);

  const uid = profile?.id ?? '';
  const isHost = room?.host_id === uid;

  /* ---------- load room + players ---------- */
  const loadRoom = useCallback(async (roomId: string) => {
    const { data: rd } = await supabase.from('battle_rooms').select('*').eq('id', roomId).maybeSingle();
    if (rd) setRoom(rd as RoomRow);
    const { data: ps } = await supabase.from('battle_players').select('*').eq('room_id', roomId).order('created_at');
    if (ps) setPlayers(ps as PlayerRow[]);
  }, []);

  /* ---------- subscribe to realtime ---------- */
  const subscribe = useCallback((roomId: string) => {
    if (channelRef.current) { try { channelRef.current.unsubscribe(); } catch { /* ignore */ } }
    const ch = supabase.channel(`battle-${roomId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'battle_rooms', filter: `id=eq.${roomId}` }, (payload) => {
        if (payload.eventType === 'DELETE') { roomClosed('Комната закрыта.'); return; }
        const nr = payload.new as RoomRow;
        setRoom(nr);
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'battle_players', filter: `room_id=eq.${roomId}` }, () => {
        void supabase.from('battle_players').select('*').eq('room_id', roomId).order('created_at')
          .then(({ data: ps }) => { if (ps) setPlayers(ps as PlayerRow[]); });
      })
      .subscribe();
    channelRef.current = ch;
  }, []);

  const roomClosed = useCallback((msg: string) => {
    if (channelRef.current) { try { channelRef.current.unsubscribe(); } catch { /* ignore */ } channelRef.current = null; }
    setRoom(null);
    setPlayers([]);
    setView('entry');
    setErr(msg);
  }, []);

  /* ---------- phase reaction ---------- */
  useEffect(() => {
    const r = roomRef.current;
    if (!r) return;

    if (r.phase === 'lobby') {
      setExternalPhase('idle');
      if (view === 'train' || view === 'result') {
        recordedRef.current = false;
        sentReadyRef.current = false;
        setView('room');
      }
    } else if (r.phase === 'setup') {
      if (view !== 'train') {
        recordedRef.current = false;
        sentReadyRef.current = false;
        setExternalPhase('idle');
        setView('train');
      }
    } else if (r.phase === 'countdown') {
      setExternalPhase('countdown');
    } else if (r.phase === 'run') {
      setExternalPhase('run');
    } else if (r.phase === 'ending') {
      setExternalPhase('wait');
    } else if (r.phase === 'end') {
      if (!recordedRef.current) {
        recordedRef.current = true;
        recordAndShowResult();
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [room?.phase]);

  /* ---------- host: auto-advance setup -> countdown when all ready ---------- */
  useEffect(() => {
    if (!isHost || !room || room.phase !== 'setup') return;
    const active = players.filter((p) => !p.is_left);
    if (active.length < 2) return;
    if (active.every((p) => p.ready)) {
      void supabase.rpc('start_battle_countdown_from_setup', { p_room_id: room.id })
        .then(({ error }) => { if (error) setErr(error.message); });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isHost, room?.phase, players]);

  /* ---------- host: countdown -> run timer ---------- */
  useEffect(() => {
    if (!isHost || !room || room.phase !== 'countdown') return;
    const t = window.setTimeout(() => {
      void supabase.rpc('set_battle_run', { p_room_id: room.id });
    }, 3500);
    return () => clearTimeout(t);
  }, [isHost, room?.phase, room?.id]);

  /* ---------- host: timed mode timeout ---------- */
  useEffect(() => {
    if (!isHost || !room || room.phase !== 'run' || room.mode !== 'timed') return;
    const t = window.setTimeout(() => { void endBattle(room.id); }, (room.dur + 5) * 1000);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isHost, room?.phase, room?.mode, room?.dur, room?.id]);

  /* ---------- host: check if all players finished (race mode) ---------- */
  useEffect(() => {
    if (!isHost || !room || room.phase !== 'run') return;
    const active = players.filter((p) => !p.is_left);
    if (active.length < 2) return;
    if (room.mode === 'race' && active.every((p) => p.fin)) { void endBattle(room.id); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isHost, room?.phase, players]);

  /* ---------- host: ending -> end with short delay ---------- */
  useEffect(() => {
    if (!isHost || !room || room.phase !== 'ending') return;
    const t = window.setTimeout(() => { void endBattle(room.id); }, 800);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isHost, room?.phase, room?.id]);

  /* ---------- end battle (host computes rank) ---------- */
  const endBattle = useCallback(async (roomId: string) => {
    const ps = playersRef.current;
    const r = roomRef.current;
    if (!r) return;
    const active = ps.filter((p) => !p.is_left);
    active.sort((a, b) => {
      if (a.fin !== b.fin) return a.fin ? -1 : 1;
      if (a.fin && b.fin && a.fin_at && b.fin_at) return new Date(a.fin_at).getTime() - new Date(b.fin_at).getTime();
      const e = getSettings().exercises[r.kind] ?? getSettings().exercises['squat'];
      const pa = e.unit === 'sec' ? a.hold : a.good;
      const pb = e.unit === 'sec' ? b.hold : b.good;
      if (pb !== pa) return pb - pa;
      return a.bad - b.bad;
    });
    const left = ps.filter((p) => p.is_left).sort((a, b) => b.good - a.good);
    const rank = [...active, ...left].map((p) => p.user_id);
    void supabase.rpc('end_battle', { p_room_id: roomId, p_rank: rank });
  }, []);

  /* ---------- record session + show result ---------- */
  const recordAndShowResult = useCallback(async () => {
    const r = roomRef.current;
    const ps = playersRef.current;
    if (!r) return;
    const rank = (r.rank && r.rank.length) ? r.rank : ps.filter((p) => !p.is_left).map((p) => p.user_id);
    const me = ps.find((p) => p.user_id === uid);
    if (!me) return;
    const e = getSettings().exercises[r.kind] ?? getSettings().exercises['squat'];
    const plank = e.unit === 'sec';
    const opponents = Math.max(0, ps.filter((p) => !p.is_left && p.user_id !== uid).length);
    const good = plank ? +me.hold.toFixed(1) : me.good;
    const bad = plank ? 0 : me.bad;
    const total = good + bad;
    const pct = plank ? 100 : Math.round(good / Math.max(1, total) * 100);
    const placement = rank.indexOf(uid) + 1;

    let recorded: RecordSessionResult | null = null;
    if (opponents > 0) {
      const { data } = await supabase.rpc('record_session', {
        p_kind: r.kind, p_mode: 'battle',
        p_good: good, p_bad: bad, p_pct: pct,
        p_placement: placement, p_opponents: opponents,
      });
      recorded = (data as RecordSessionResult) ?? null;
    }
    setBattleResult({ rank, players: ps, room: r, recorded });
    setView('result');
  }, [uid]);

  /* ---------- create room ---------- */
  const createRoom = useCallback(async () => {
    setErr(''); setBusy(true);
    const s = getSettings();
    const ex = s.exercises['squat']!;
    const c = genCode();
    const { data, error: e1 } = await supabase.rpc('create_battle_room', {
      p_code: c, p_kind: 'squat', p_kind_name: ex.name, p_mode: 'race', p_goal: ex.goal, p_dur: 60,
    });
    if (e1 || !data) { setErr('Не удалось создать комнату. Попробуй ещё раз.'); setBusy(false); return; }
    const roomId = data as string;
    await loadRoom(roomId);
    subscribe(roomId);
    setBusy(false);
    setView('room');
  }, [loadRoom, subscribe]);

  /* ---------- join room ---------- */
  const joinRoom = useCallback(async (roomId: string) => {
    setErr(''); setBusy(true);
    const { error: e1 } = await supabase.rpc('join_battle_room', { p_room_id: roomId });
    if (e1) { setErr(e1.message || 'Не удалось войти в комнату.'); setBusy(false); return; }
    await loadRoom(roomId);
    subscribe(roomId);
    setBusy(false);
    setView('room');
  }, [loadRoom, subscribe]);

  const joinByCode = useCallback(async () => {
    const c = code.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (c.length !== 5) { setErr('Код состоит из пяти символов.'); return; }
    setBusy(true);
    const { data, error: e1 } = await supabase.from('battle_rooms').select('id').eq('code', c).maybeSingle();
    if (e1 || !data) { setErr('Комната с таким кодом не найдена.'); setBusy(false); return; }
    void joinRoom(data.id);
  }, [code, joinRoom]);

  /* ---------- leave room ---------- */
  const leaveBattle = useCallback(() => {
    const r = roomRef.current;
    leftRef.current = true;
    if (r) void supabase.rpc('leave_battle_room', { p_room_id: r.id });
    if (channelRef.current) { try { channelRef.current.unsubscribe(); } catch { /* ignore */ } channelRef.current = null; }
    cancelSpeech();
    setRoom(null);
    setPlayers([]);
    onExit();
  }, [onExit]);

  /* ---------- cleanup on unmount ---------- */
  useEffect(() => {
    return () => {
      const r = roomRef.current;
      if (r && !leftRef.current) { void supabase.rpc('leave_battle_room', { p_room_id: r.id }); }
      if (channelRef.current) { try { channelRef.current.unsubscribe(); } catch { /* ignore */ } }
      cancelSpeech();
    };
  }, []);

  /* ---------- battle callbacks from TrainingScreen ---------- */
  const handleReady = useCallback(() => {
    const r = roomRef.current;
    if (!r || sentReadyRef.current) return;
    sentReadyRef.current = true;
    void supabase.rpc('set_battle_ready', { p_room_id: r.id });
    say('Готов');
  }, []);

  const handleStat = useCallback((s: { good: number; bad: number; hold: number }) => {
    const r = roomRef.current;
    if (!r) return;
    void supabase.rpc('update_battle_stat', { p_room_id: r.id, p_good: s.good, p_bad: s.bad, p_hold: s.hold });
  }, []);

  const handleBattleFinish = useCallback(() => {
    const r = roomRef.current;
    if (!r) return;
    void supabase.rpc('mark_battle_fin', { p_room_id: r.id });
  }, []);

  /* ---------- host: update config ---------- */
  const hostCfg = useCallback((patch: Partial<{ kind: string; mode: BattleMode; goal: number; dur: number }>) => {
    const r = roomRef.current;
    if (!r || r.host_id !== uid || (r.phase !== 'lobby' && r.phase !== 'setup')) return;
    const s = getSettings();
    let kind = patch.kind ?? r.kind;
    let mode = patch.mode ?? r.mode;
    let goal = patch.goal ?? r.goal;
    let dur = patch.dur ?? r.dur;
    const ex = s.exercises[kind] ?? s.exercises['squat']!;
    if (ex.unit === 'sec') mode = 'race';
    if (!ex.goals.includes(goal)) goal = ex.goal;
    const updated: RoomRow = { ...r, kind, kind_name: ex.name, mode, goal, dur };
    setRoom(updated);
    roomRef.current = updated;
    supabase.rpc('update_room_cfg', {
      p_room_id: r.id, p_kind: kind, p_kind_name: ex.name, p_mode: mode, p_goal: goal, p_dur: dur,
    }).then(({ error }) => {
      if (error) { setErr(error.message); setRoom(r); roomRef.current = r; }
    });
  }, [uid]);

  /* ---------- host: start battle (lobby -> setup) ---------- */
  const startBattle = useCallback(() => {
    const r = roomRef.current;
    if (!r || r.host_id !== uid) return;
    beep(1, 10);
    void supabase.rpc('start_battle_setup', { p_room_id: r.id }).then(({ error }) => {
      if (error) setErr(error.message);
    });
  }, [uid]);

  /* ---------- toggle own ready flag ---------- */
  const toggleReady = useCallback(() => {
    const r = roomRef.current;
    if (!r) return;
    const me = playersRef.current.find((p) => p.user_id === uid);
    if (me?.ready) return;
    void supabase.rpc('set_battle_ready', { p_room_id: r.id });
  }, [uid]);

  /* ---------- host: cancel setup (setup -> lobby) ---------- */
  const cancelSetup = useCallback(() => {
    const r = roomRef.current;
    if (!r || r.host_id !== uid) return;
    void supabase.rpc('cancel_battle_setup', { p_room_id: r.id });
  }, [uid]);

  /* ---------- host: rematch ---------- */
  const rematch = useCallback(() => {
    const r = roomRef.current;
    if (!r || r.host_id !== uid) return;
    recordedRef.current = false;
    void supabase.rpc('reset_battle_for_rematch', { p_room_id: r.id });
  }, [uid]);

  const copyLink = useCallback(async () => {
    const r = roomRef.current;
    if (!r) return;
    try { await navigator.clipboard.writeText(r.code); } catch { /* ignore */ }
  }, []);

  /* ---------- render: train ---------- */
  if (view === 'train' && room) {
    const active = players.filter((p) => !p.is_left);
    const me = active.find((p) => p.user_id === uid);
    const battlePlayers = active.map((p) => ({
      id: p.user_id, name: p.display_name, good: p.good, bad: p.bad, hold: +p.hold, fin: p.fin,
    }));
    const showReadyButton = room.phase === 'setup' && !me?.ready;
    return (
      <TrainingScreen
        kind={room.kind}
        goal={room.goal}
        facing="user"
        sound
        onExit={room.phase === 'setup' ? cancelSetup : leaveBattle}
        onFinish={() => leaveBattle()}
        battle={{
          mode: room.mode,
          dur: room.dur,
          onReady: handleReady,
          onStat: handleStat,
          onFinish: handleBattleFinish,
          externalPhase,
          players: battlePlayers,
          myId: uid,
          showReadyButton,
          onManualReady: toggleReady,
          allReady: active.length >= 2 && active.every((p) => p.ready),
        }}
      />
    );
  }

  /* ---------- render: result ---------- */
  if (view === 'result' && battleResult && room) {
    return (
      <BattleResult
        rank={battleResult.rank}
        players={battleResult.players}
        room={battleResult.room}
        uid={uid}
        recorded={battleResult.recorded}
        onRematch={rematch}
        onLeave={leaveBattle}
        canRematch={isHost}
      />
    );
  }

  /* ---------- render: room ---------- */
  if (view === 'room' && room) {
    return (
      <RoomView
        room={room}
        players={players}
        uid={uid}
        isHost={isHost}
        onCfg={hostCfg}
        onStart={startBattle}
        onLeave={leaveBattle}
        onCopy={copyLink}
        onToggleReady={toggleReady}
      />
    );
  }

  /* ---------- render: entry ---------- */
  return (
    <EntryView
      code={code}
      setCode={setCode}
      err={err}
      busy={busy}
      onCreate={createRoom}
      onJoin={joinByCode}
      onJoinRoom={joinRoom}
      onBack={onExit}
    />
  );
}

/* ---------- entry + lobby ---------- */
function EntryView({ code, setCode, err, busy, onCreate, onJoin, onJoinRoom, onBack }: {
  code: string; setCode: (v: string) => void;
  err: string; busy: boolean;
  onCreate: () => void; onJoin: () => void; onJoinRoom: (id: string) => void; onBack: () => void;
}) {
  const [lobby, setLobby] = useState<RoomRow[]>([]);
  const [lobbyBusy, setLobbyBusy] = useState<Record<string, boolean>>({});

  useEffect(() => {
    const load = async () => {
      const { data } = await supabase
        .from('battle_rooms')
        .select('*')
        .eq('phase', 'lobby')
        .order('created_at', { ascending: false })
        .limit(20);
      if (data) setLobby(data as RoomRow[]);
    };
    void load();
    const ch = supabase.channel('battle-lobby')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'battle_rooms' }, () => { void load(); })
      .subscribe();
    return () => { try { ch.unsubscribe(); } catch { /* ignore */ } };
  }, []);

  const s = getSettings();

  return (
    <div className="min-h-screen screen-pad">
      <div className="max-w-xl mx-auto">
        <button onClick={onBack} className="eyebrow text-muted hover:text-ink transition mb-4 flex items-center gap-1">
          <ArrowLeft size={14} /> Назад
        </button>
        <div className="eyebrow">до 4 игроков · каждый со своей камеры</div>
        <h1 className="font-display text-4xl sm:text-5xl tracking-tight mt-3 mb-4">Баттл</h1>
        <p className="text-muted mb-6 max-w-xl">
          Создай комнату или присоединись к открытой. Побеждает тот, у кого больше чистых повторений: брак не считается.
        </p>

        <button
          onClick={onCreate} disabled={busy}
          className="w-full bg-accent text-white font-display font-bold py-4 rounded-xl disabled:opacity-60 hover:brightness-110 transition flex items-center justify-center gap-2"
        >
          <Swords size={18} /> Создать комнату
        </button>

        <h3 className="eyebrow mt-8 mb-3">Войти по коду</h3>
        <div className="flex gap-2.5">
          <input
            value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} maxLength={5}
            placeholder="КОД" autoCapitalize="characters" autoComplete="off" spellCheck={false}
            aria-label="Код комнаты"
            onKeyDown={(e) => { if (e.key === 'Enter') onJoin(); }}
            className="flex-1 max-w-[220px] bg-surface border border-line rounded-xl px-4 py-3.5 text-center font-mono font-bold text-2xl tracking-[0.3em] outline-none focus:border-accent"
          />
          <button onClick={onJoin} disabled={busy} className="bg-surface border border-line font-display font-bold px-6 py-3.5 rounded-xl hover:border-accent transition disabled:opacity-60">
            Войти
          </button>
        </div>
        {err && <p className="text-bad text-sm mt-3" role="alert">{err}</p>}

        <h3 className="eyebrow mt-8 mb-3 flex items-center gap-1.5">
          <Users size={14} /> Открытые комнаты
        </h3>
        {lobby.length === 0 ? (
          <div className="bg-surface border border-line rounded-xl px-4 py-6 text-center text-muted">
            <p className="text-sm">Пока нет открытых комнат. Создай свою!</p>
          </div>
        ) : (
          <div className="space-y-2.5">
            {lobby.map((r) => {
              const ex = s.exercises[r.kind] ?? s.exercises['squat']!;
              return (
                <div key={r.id} className="bg-surface border border-line rounded-xl px-4 py-3.5 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="font-display font-bold flex items-center gap-2">
                      {ex.name}
                      <span className="eyebrow not-italic text-muted">· {r.mode === 'race' ? MODES.race : MODES.timed}</span>
                    </div>
                    <div className="eyebrow text-muted mt-0.5">
                      Хост: {r.host_name}
                      <span className="ml-2 font-mono">{r.code}</span>
                    </div>
                  </div>
                  <button
                    onClick={() => { setLobbyBusy((b) => ({ ...b, [r.id]: true })); onJoinRoom(r.id); }}
                    disabled={busy || lobbyBusy[r.id]}
                    className="bg-accent text-white font-display font-bold px-4 py-2.5 rounded-lg disabled:opacity-50 hover:brightness-110 transition whitespace-nowrap flex items-center gap-1.5 text-sm"
                  >
                    <DoorOpen size={15} /> Войти
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

/* ---------- room ---------- */
function RoomView({ room, players, uid, isHost, onCfg, onStart, onLeave, onCopy, onToggleReady }: {
  room: RoomRow; players: PlayerRow[]; uid: string; isHost: boolean;
  onCfg: (p: Partial<{ kind: string; mode: BattleMode; goal: number; dur: number }>) => void;
  onStart: () => void; onLeave: () => void; onCopy: () => void; onToggleReady: () => void;
}) {
  const s = getSettings();
  const active = players.filter((p) => !p.is_left);
  const n = active.length;
  const canShare = /^https?:/.test(location.protocol);

  return (
    <div className="min-h-screen screen-pad">
      <div className="max-w-xl mx-auto">
        <button onClick={onLeave} className="eyebrow text-muted hover:text-ink transition mb-4 flex items-center gap-1">
          <ArrowLeft size={14} /> Выйти
        </button>

        <div className="eyebrow mt-2">Код комнаты</div>
        <div className="font-mono font-bold tracking-[0.18em] pl-[0.18em] my-1" style={{ fontSize: 'clamp(44px, 14vw, 72px)' }}>
          {room.code}
        </div>
        {canShare && (
          <button onClick={onCopy} className="bg-surface border border-line font-display font-bold px-5 py-2.5 rounded-xl hover:border-accent transition flex items-center gap-2 mb-5">
            <Copy size={16} /> Копировать код
          </button>
        )}

        <h3 className="eyebrow mt-6 mb-3">Игроки</h3>
        <div className="border-t border-line">
          {active.map((p) => (
            <div key={p.id} className="flex justify-between items-center gap-3 py-3 border-b border-line">
              <span className="font-display font-bold flex items-center gap-2">
                {p.display_name}
                {p.user_id === room.host_id && <em className="eyebrow not-italic text-muted">хост</em>}
                {p.user_id === uid && <em className="eyebrow not-italic text-accent">ты</em>}
              </span>
              {p.ready
                ? <span className="eyebrow text-good flex items-center gap-1"><Check size={12} /> готов</span>
                : <span className="eyebrow text-muted">в комнате</span>}
            </div>
          ))}
        </div>

        {room.phase === 'setup' && (
          <div className="mt-4">
            <p className="text-sm text-muted mb-3">Встань в кадр и отметься готовым. Когда все готовы — начнётся отсчёт.</p>
            {(() => { const me = active.find((p) => p.user_id === uid); return (
              <button onClick={onToggleReady} disabled={me?.ready}
                className="bg-accent text-white font-display font-bold px-6 py-3.5 rounded-xl flex items-center gap-2 disabled:opacity-50 hover:brightness-110 transition">
                <Check size={16} /> {me?.ready ? 'Готов' : 'Я готов'}
              </button>
            ); })()}
          </div>
        )}

        <h3 className="eyebrow mt-6 mb-3">Задание</h3>
        {isHost ? (
          <div className="space-y-3.5 mb-2">
            <Seg items={s.order.map((k) => { const ex = s.exercises[k]!; return [k, ex.name] as [string, string]; })} cur={room.kind} onPick={(v) => onCfg({ kind: v })} />
            <Seg items={(s.exercises[room.kind]?.unit ?? 'reps') === 'sec' ? [['race', MODES.race]] : (Object.entries(MODES) as [string, string][])} cur={room.mode} onPick={(v) => onCfg({ mode: v as BattleMode })} />
            {room.mode !== 'timed' && (
              <Seg items={(s.exercises[room.kind] ?? s.exercises['squat']).goals.map((g) => [String(g), (s.exercises[room.kind]?.unit ?? 'reps') === 'sec' ? `${g} с` : String(g)] as [string, string])} cur={String(room.goal)} onPick={(v) => onCfg({ goal: +v })} />
            )}
          </div>
        ) : (
          <p className="text-muted">{cfgText(room)}</p>
        )}

        <div className="flex flex-wrap gap-3 mt-7">
          {isHost && (
            <button onClick={onStart} disabled={n < 2} className="bg-accent text-white font-display font-bold px-6 py-3.5 rounded-xl flex items-center gap-2 disabled:opacity-50 hover:brightness-110 transition">
              <Play size={16} /> Начать баттл
            </button>
          )}
          <button onClick={onLeave} className="bg-surface border border-line font-display font-bold px-6 py-3.5 rounded-xl hover:border-bad hover:text-bad transition flex items-center gap-2">
            <LogOut size={16} /> Выйти
          </button>
        </div>
        <p className="text-xs text-muted mt-4">
          {isHost
            ? (n < 2 ? 'Отправь код друзьям. Начать можно, когда в комнате минимум двое.' : 'После старта у каждого включится камера. Бой начнётся, когда все встанут в кадр.')
            : 'Ждём, когда хост начнёт баттл.'}
        </p>
      </div>
    </div>
  );
}

function Seg({ items, cur, onPick }: { items: [string, string][]; cur: string; onPick: (v: string) => void }) {
  return (
    <div className="flex flex-wrap gap-2">
      {items.map(([v, l]) => (
        <button
          key={v}
          onClick={() => onPick(v)}
          aria-pressed={String(v) === String(cur)}
          className={`px-3.5 py-2 rounded-lg border font-mono text-sm transition ${String(v) === String(cur) ? 'bg-accent text-white border-accent' : 'bg-surface border-line'}`}
        >
          {l}
        </button>
      ))}
    </div>
  );
}

function cfgText(r: RoomRow): string {
  const e = getSettings().exercises[r.kind] ?? getSettings().exercises['squat'];
  if (r.mode === 'timed') return `${e.name}. На время: ${r.dur} секунд, побеждает тот, у кого больше чистых повторений.`;
  return e.unit === 'sec'
    ? `${e.name}. Гонка: первый, кто продержит ${r.goal} секунд с ровным корпусом.`
    : `${e.name}. Гонка: первый, кто сделает ${r.goal} чистых повторений.`;
}

/* ---------- battle result ---------- */
function BattleResult({ rank, players, room, uid, recorded, onRematch, onLeave, canRematch }: {
  rank: string[]; players: PlayerRow[]; room: RoomRow; uid: string;
  recorded?: RecordSessionResult | null;
  onRematch: () => void; onLeave: () => void; canRematch: boolean;
}) {
  const e = getSettings().exercises[room.kind] ?? getSettings().exercises['squat'];
  const plank = e.unit === 'sec';
  const winnerId = rank[0];
  const winner = players.find((p) => p.user_id === winnerId);
  const meWon = winnerId === uid;
  const delta = recorded?.rating_delta ?? 0;
  const newRating = recorded?.new_battle_rating;
  const active = players.filter((p) => !p.is_left);
  const solo = active.length < 2;
  const byUid = (id: string) => players.find((p) => p.user_id === id);

  const podium = rank.slice(0, 3).map((id) => byUid(id)).filter(Boolean) as PlayerRow[];
  const rest = rank.slice(3).map((id) => byUid(id)).filter(Boolean) as PlayerRow[];

  const rankMeta = [
    { icon: Crown, color: 'text-[#fbbf24]', bg: 'from-[#fbbf24]/20 to-[#f59e0b]/5', border: 'border-[#fbbf24]/40', label: '1-е место' },
    { icon: Medal, color: 'text-[#cbd5e1]', bg: 'from-[#cbd5e1]/15 to-[#94a3b8]/5', border: 'border-[#cbd5e1]/30', label: '2-е место' },
    { icon: Medal, color: 'text-[#cd7f32]', bg: 'from-[#cd7f32]/15 to-[#b45309]/5', border: 'border-[#cd7f32]/30', label: '3-е место' },
  ];

  const scoreOf = (p: PlayerRow) => plank ? Math.floor(p.hold) : p.good;
  const scoreLabel = (p: PlayerRow) => plank ? `${Math.floor(p.hold)} с` : `${p.good}`;
  const accuracyOf = (p: PlayerRow) => {
    if (plank) return null;
    const tot = p.good + p.bad;
    return tot > 0 ? Math.round(p.good / tot * 100) : null;
  };

  return (
    <div className="min-h-screen screen-pad">
      <div className="max-w-xl mx-auto">

        {/* ---- winner hero ---- */}
        <div className="scale-in text-center pt-2 pb-6">
          <div className={`inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-mono font-medium mb-4 ${meWon ? 'bg-good/10 text-good' : 'bg-surface text-muted border border-line'}`}>
            {meWon ? <Crown size={13} /> : <Swords size={13} />}
            {room.mode === 'timed' ? 'Баттл на время' : 'Гонка'} · {e.name}
          </div>

          {meWon ? (
            <div className="relative">
              <Trophy size={56} className="text-[#fbbf24] mx-auto mb-3" strokeWidth={1.5} />
              <h1 className="font-display text-4xl sm:text-5xl tracking-tight shine-text text-[#fbbf24]">
                Победа!
              </h1>
              <p className="text-muted mt-2 text-sm">Ты обошёл всех соперников</p>
            </div>
          ) : (
            <div className="relative">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#fbbf24]/30 to-[#f59e0b]/10 border border-[#fbbf24]/40 grid place-items-center mx-auto mb-3">
                <Crown size={28} className="text-[#fbbf24]" />
              </div>
              <h1 className="font-display text-3xl sm:text-4xl tracking-tight">
                {winner?.display_name ?? '?'}
              </h1>
              <p className="text-muted mt-2 text-sm">Победитель баттла</p>
            </div>
          )}

          {recorded && (
            <div className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl font-mono font-medium mt-5 slide-up ${
              delta > 0 ? 'bg-good/10 text-good' : delta < 0 ? 'bg-bad/10 text-bad' : 'bg-surface text-muted border border-line'
            }`}>
              {delta > 0 ? <TrendingUp size={15} /> : delta < 0 ? <TrendingDown size={15} /> : <Minus size={15} />}
              Баттл-рейтинг
              <b className="tabular-nums">{delta > 0 ? '+' : ''}{delta}</b>
              <span className="text-muted">→</span>
              <b className="tabular-nums">{newRating}</b>
            </div>
          )}
        </div>

        {/* ---- podium top 3 ---- */}
        {podium.length > 0 && (
          <div className="flex items-end justify-center gap-2.5 sm:gap-4 mb-6">
            {/* 2nd */}
            {podium[1] && (
              <PodiumCard player={podium[1]} place={2} icon={Medal} color="#cbd5e1" height="h-24" delay="0.1s" score={scoreLabel(podium[1])} isMe={podium[1].user_id === uid} />
            )}
            {/* 1st */}
            {podium[0] && (
              <PodiumCard player={podium[0]} place={1} icon={Crown} color="#fbbf24" height="h-32" delay="0s" score={scoreLabel(podium[0])} isMe={podium[0].user_id === uid} big />
            )}
            {/* 3rd */}
            {podium[2] && (
              <PodiumCard player={podium[2]} place={3} icon={Medal} color="#cd7f32" height="h-20" delay="0.2s" score={scoreLabel(podium[2])} isMe={podium[2].user_id === uid} />
            )}
          </div>
        )}

        {/* ---- full ranking table ---- */}
        <div className="space-y-2.5">
          <h3 className="eyebrow mb-1">Итоговая таблица</h3>
          {rank.map((id, i) => {
            const p = byUid(id);
            if (!p) return null;
            const acc = accuracyOf(p);
            const me = id === uid;
            const meta = rankMeta[Math.min(i, 2)];
            const RankIcon = meta.icon;
            const maxScore = Math.max(...rank.map((rid) => scoreOf(byUid(rid) ?? players[0])).filter((v) => v > 0), 1);
            const barPct = Math.min(100, (scoreOf(p) / maxScore) * 100);
            return (
              <div
                key={id}
                className={`slide-up bg-surface border rounded-xl px-4 py-3.5 ${me ? 'border-accent' : i === 0 ? 'border-[#fbbf24]/40' : 'border-line'}`}
                style={{ animationDelay: `${0.3 + i * 0.08}s` }}
              >
                <div className="flex items-center gap-3">
                  <span className={`flex items-center justify-center w-8 h-8 rounded-lg font-display font-bold text-sm shrink-0 ${i < 3 ? `${meta.color} bg-gradient-to-b ${meta.bg} border ${meta.border}` : 'text-muted bg-white/5'}`}>
                    {i < 3 ? <RankIcon size={15} /> : i + 1}
                  </span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-baseline justify-between gap-2">
                      <span className="font-display font-bold truncate flex items-center gap-1.5">
                        {p.display_name}
                        {p.is_left && <em className="eyebrow not-italic text-muted text-xs">вышел</em>}
                        {me && <em className="eyebrow not-italic text-accent text-xs">ты</em>}
                      </span>
                      <span className="font-display font-bold text-xl tabular-nums shrink-0">
                        {scoreLabel(p)}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 mt-1.5">
                      <div className="flex-1 h-1.5 rounded-full bg-white/8 overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-700 ${i === 0 ? 'bg-[#fbbf24]' : me ? 'bg-accent' : 'bg-white/40'}`}
                          style={{ width: `${barPct}%` }}
                        />
                      </div>
                      {!plank && p.bad > 0 && (
                        <span className="font-mono text-xs text-bad tabular-nums shrink-0">✕{p.bad}</span>
                      )}
                      {acc !== null && (
                        <span className="font-mono text-xs text-muted tabular-nums shrink-0">{acc}%</span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* ---- actions ---- */}
        <div className="flex flex-wrap gap-3 mt-7 fade-in" style={{ animationDelay: '0.6s' }}>
          {canRematch && (
            <button onClick={onRematch} className="bg-accent text-white font-display font-bold px-6 py-3.5 rounded-xl flex items-center gap-2 hover:brightness-110 transition">
              <RefreshCw size={16} /> Реванш
            </button>
          )}
          <button onClick={onLeave} className="bg-surface border border-line font-display font-bold px-6 py-3.5 rounded-xl hover:border-accent transition">
            Выйти из комнаты
          </button>
        </div>
        <p className="text-xs text-muted mt-4 fade-in" style={{ animationDelay: '0.7s' }}>
          {solo ? 'Остальные игроки вышли.' : (canRematch ? 'Реванш вернёт всех в комнату с теми же настройками.' : 'Реванш запускает хост: жди возвращения в комнату.')}
        </p>
      </div>
    </div>
  );
}

function PodiumCard({ player, place, icon: Icon, color, height, delay, score, isMe, big }: {
  player: PlayerRow; place: number; icon: typeof Crown; color: string; height: string; delay: string; score: string; isMe: boolean; big?: boolean;
}) {
  return (
    <div className="slide-up flex flex-col items-center" style={{ animationDelay: delay }}>
      <div
        className={`relative rounded-2xl border bg-gradient-to-b px-3 pt-3 pb-2 flex flex-col items-center justify-end ${height} ${big ? 'w-24 border-2' : 'w-20'} ${place === 1 ? 'from-[#fbbf24]/15 to-[#f59e0b]/5 border-[#fbbf24]/50' : place === 2 ? 'from-[#cbd5e1]/12 to-[#94a3b8]/5 border-[#cbd5e1]/30' : 'from-[#cd7f32]/12 to-[#b45309]/5 border-[#cd7f32]/30'} ${isMe ? 'ring-2 ring-accent' : ''}`}
      >
        <Icon size={big ? 22 : 18} style={{ color }} className="mb-1" />
        <span className={`font-display font-bold ${big ? 'text-base' : 'text-sm'} truncate max-w-full`}>
          {player.display_name.split(' ')[0]}
        </span>
        <span className="font-display font-bold tabular-nums" style={{ color, fontSize: big ? '1.25rem' : '1rem' }}>
          {score}
        </span>
        {isMe && <span className="eyebrow text-accent text-[10px] mt-0.5">ты</span>}
      </div>
      <div className={`font-mono text-xs mt-1.5 ${place === 1 ? 'text-[#fbbf24]' : 'text-muted'}`}>
        #{place}
      </div>
    </div>
  );
}
