import { useEffect, useRef, useState, useCallback } from 'react';
import type { FrameOut, OutEvent, Trainer } from '@/lib/formaEngine';
import { createTrainerForEngine, createFreeTrainer, LINKS } from '@/lib/formaEngine';
import { getSettings } from '@/lib/settings';
import { useCamera } from '@/training/useCamera';
import { beep, say, cancelSpeech, setSoundOn } from '@/lib/sound';
import { Volume2, VolumeX, Square, Check } from 'lucide-react';

export type SoloResult = {
  kind: string;
  good: number;
  bad: number;
  holdGood: number;
  holdBad: number;
  pct: number;
};

type Props = {
  kind: string;
  goal: number;
  facing: 'user' | 'environment';
  sound: boolean;
  onExit: () => void;
  onFinish: (result: SoloResult) => void;
  /** Battle integration: when set, training is driven by external phase transitions. */
  battle?: {
    mode: 'race' | 'timed';
    dur: number;
    onReady: () => void;
    onStat: (s: { good: number; bad: number; hold: number }) => void;
    onFinish: () => void;
    /** External phase control from host. */
    externalPhase: 'position' | 'countdown' | 'run' | 'wait' | 'idle';
    /** Live opponent data for the battle progress bar. */
    players?: { id: string; name: string; good: number; bad: number; hold: number; fin: boolean }[];
    myId?: string;
  };
};

type Phase = 'position' | 'countdown' | 'run' | 'end' | 'wait';

export default function TrainingScreen({ kind, goal, facing, sound, onExit, onFinish, battle }: Props) {
  const settings = getSettings();
  const ex = settings.exercises[kind];
  const e = ex ?? settings.exercises['squat'];
  const engine = ex?.baseKind ?? 'squat';
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const trainerRef = useRef<Trainer | null>(null);
  const phaseRef = useRef<Phase>('position');
  const [, setPhaseState] = useState<Phase>('position');
  const [count, setCount] = useState('');
  const [cue, setCue] = useState('');
  const [cueKind, setCueKind] = useState<'info' | 'ok' | 'fault'>('info');
  const [flash, setFlash] = useState<{ kind: 'good' | 'bad'; text: string } | null>(null);
  const [strip, setStrip] = useState<boolean[]>([]);
  const [big, setBig] = useState({ good: 0, bad: 0, holdGood: 0 });
  const [mets, setMets] = useState<FrameOut['metrics']>([]);
  const [badText, setBadText] = useState('');
  const [barWidth, setBarWidth] = useState(0);
  const [soundOnState, setSoundOnState] = useState(sound);
  const [overlay, setOverlay] = useState<{ title: string; text: string; err?: boolean } | null>(null);
  const readySinceRef = useRef(0);
  const cdEndRef = useRef(0);
  const runStartRef = useRef(0);
  const lastFaultSayRef = useRef(0);
  const endTimerRef = useRef<number | null>(null);
  const lastStatSendRef = useRef(0);

  const setPhase = useCallback((p: Phase) => { phaseRef.current = p; setPhaseState(p); }, []);

  const onFrame = useCallback((out: FrameOut, video: HTMLVideoElement) => {
    const now = performance.now();
    let curCue = out.ready ? out.cue : out.hint;
    let curKind: 'info' | 'ok' | 'fault' = out.ready ? out.cueKind : 'info';

    const ph = phaseRef.current;

    if (ph === 'position') {
      if (out.ready) {
        if (!readySinceRef.current) readySinceRef.current = now;
        curKind = 'ok';
        if (battle) {
          curCue = 'Готов. Ждём остальных игроков';
          battle.onReady();
        } else {
          curCue = 'Хорошо, замри на секунду';
          if (now - readySinceRef.current > 1200) {
            setPhase('countdown');
            cdEndRef.current = now + 3400;
            say('Приготовься');
          }
        }
      } else {
        readySinceRef.current = 0;
      }
    }

    if (ph === 'countdown') {
      if (!out.ready && !battle) {
        setPhase('position');
        readySinceRef.current = 0;
        setCount('');
      } else {
        const n = Math.ceil((cdEndRef.current - now) / 1000);
        if (n <= 0) {
          setPhase('run');
          runStartRef.current = now;
          setCount('');
          trainerRef.current?.setCounting(true);
          beep(1000, 250);
          say('Поехали');
        } else {
          setCount(String(n));
          if (n !== Number(count)) beep(660, 90);
          curCue = '';
        }
      }
    }

    if (ph === 'run') {
      for (const ev of out.events) onEvent(ev);
      if (out.ready && out.cueKind === 'fault' && now - lastFaultSayRef.current > 4000) {
        lastFaultSayRef.current = now;
        say(out.cue);
      }
      if (battle) {
        const s = trainerRef.current!.stats;
        const key = `${s.good}|${s.bad}|${Math.floor(s.holdGood)}`;
        if (now - lastStatSendRef.current > 250) {
          lastStatSendRef.current = now;
          battle.onStat({ good: s.good, bad: s.bad, hold: +s.holdGood.toFixed(1) });
        }
        void key;
        checkBattleGoal(now);
      } else {
        checkSoloGoal();
      }
    }

    if (ph === 'wait') {
      curCue = 'Готово. Ждём остальных игроков';
      curKind = 'ok';
    }

    setCue(curCue);
    setCueKind(curKind);
    setMets(out.ready ? out.metrics : []);

    const s = trainerRef.current?.stats;
    if (s) {
      setBig({ good: s.good, bad: s.bad, holdGood: s.holdGood });
      setBadText(
        e.unit === 'sec'
          ? s.holdBad >= 1 ? `с провисанием ${Math.round(s.holdBad)} с` : ''
          : s.bad ? `не засчитано ${s.bad}` : ''
      );
      if (battle && battle.mode === 'timed') {
        const left = Math.max(0, battle.dur - (now - runStartRef.current) / 1000);
        setBarWidth(Math.min(100, (battle.dur - left) / battle.dur * 100));
      } else if (e.unit === 'sec') {
        setBarWidth(Math.min(100, s.holdGood / goal * 100));
      } else {
        setBarWidth(Math.min(100, s.good / goal * 100));
      }
    }

    draw(out, video);
  }, [battle, count, e.unit, goal, setPhase]);

  const { videoRef, state, error, stop, setTrainer } = useCamera({ facing, active: true, onFrame });

  // Set up trainer + sound on mount
  useEffect(() => {
    if (engine === 'free' && ex?.skeleton) {
      trainerRef.current = createFreeTrainer(ex.skeleton, ex.cfg, ex.unit);
    } else {
      trainerRef.current = createTrainerForEngine(engine);
    }
    setTrainer(trainerRef.current);
    setSoundOn(sound);
    setSoundOnState(sound);
    setOverlay({ title: 'Запускаю камеру…', text: 'Разреши доступ, когда браузер спросит.' });
    return () => {
      cancelSpeech();
      if (endTimerRef.current) clearTimeout(endTimerRef.current);
    };
  }, [kind, setTrainer, sound]);

  // Update overlay based on camera state
  useEffect(() => {
    if (state === 'loading') {
      setOverlay({ title: error ? 'Не удалось запустить' : 'Запускаю камеру…', text: error?.message ?? 'Разреши доступ, когда браузер спросит.', err: !!error });
    } else if (state === 'error') {
      setOverlay({ title: error?.kind === 'camera' ? 'Нет доступа к камере' : 'Не удалось загрузить модель', text: error?.message ?? '', err: true });
    } else if (state === 'ready') {
      setOverlay(null);
      setPhase('position');
    }
  }, [state, error, setPhase]);

  // Battle external phase sync
  useEffect(() => {
    if (!battle) return;
    const ep = battle.externalPhase;
    if (ep === 'countdown' && phaseRef.current === 'position') {
      setPhase('countdown');
      cdEndRef.current = performance.now() + 3400;
      say('Приготовься');
    } else if (ep === 'run' && phaseRef.current === 'countdown') {
      setPhase('run');
      runStartRef.current = performance.now();
      trainerRef.current?.setCounting(true);
      beep(1000, 250);
      say('Поехали');
    } else if (ep === 'wait' && phaseRef.current === 'run') {
      doBattleFinish();
    } else if (ep === 'idle') {
      setPhase('position');
    }
  }, [battle?.externalPhase, battle, setPhase]);

  const onEvent = (ev: OutEvent) => {
    if (ev.type === 'mark') {
      say(`${ev.seconds} секунд`);
      beep(880, 120);
      return;
    }
    if (ev.ok) {
      setFlash({ kind: 'good', text: `Засчитано · ${ev.n}` });
      beep(880, 130);
      say(String(ev.n));
    } else {
      setFlash({ kind: 'bad', text: 'Не засчитано: ' + ev.reasons.join(', ').toLowerCase() });
      beep(200, 260);
      say('Не засчитано. ' + ev.reasons[0]);
    }
    setStrip((prev) => {
      const next = [...prev, ev.ok];
      return next.length > 40 ? next.slice(-40) : next;
    });
    setTimeout(() => setFlash(null), 1100);
  };

  const checkSoloGoal = () => {
    const s = trainerRef.current?.stats;
    if (!s || phaseRef.current !== 'run') return;
    const done = e.unit === 'sec' ? s.holdGood >= goal : s.good >= goal;
    if (done) {
      setPhase('end');
      trainerRef.current?.setCounting(false);
      endTimerRef.current = window.setTimeout(() => finishSolo(true), 1300);
    }
  };

  const checkBattleGoal = (now: number) => {
    if (phaseRef.current !== 'run' || !battle) return;
    const s = trainerRef.current?.stats;
    if (!s) return;
    if (battle.mode === 'timed') {
      const left = battle.dur - (now - runStartRef.current) / 1000;
      if (left <= 0) doBattleFinish();
    } else if ((e.unit === 'sec' ? s.holdGood : s.good) >= goal) {
      doBattleFinish();
    }
  };

  const finishSolo = (auto: boolean) => {
    const s = trainerRef.current?.stats;
    if (!s) return;
    stop();
    const plank = e.unit === 'sec';
    const total = plank ? s.holdGood + s.holdBad : s.good + s.bad;
    if (total < 1 && !auto) { onExit(); return; }
    const pct = plank
      ? Math.round(s.holdGood / Math.max(0.001, total) * 100)
      : Math.round(s.good / Math.max(1, total) * 100);
    onFinish({ kind, good: s.good, bad: s.bad, holdGood: s.holdGood, holdBad: s.holdBad, pct });
  };

  const doBattleFinish = () => {
    if (phaseRef.current !== 'run' && phaseRef.current !== 'countdown') return;
    setPhase('wait');
    trainerRef.current?.setCounting(false);
    const s = trainerRef.current?.stats;
    if (s && battle) battle.onStat({ good: s.good, bad: s.bad, hold: +s.holdGood.toFixed(1) });
    battle?.onFinish();
    beep(880, 150);
  };

  const handleStop = () => {
    if (battle) { battle.onFinish(); }
    else finishSolo(false);
  };

  const toggleSound = () => {
    const v = !soundOnState;
    setSoundOnState(v);
    setSoundOn(v);
    if (!v) cancelSpeech();
  };

  const bigLabel = e.unit === 'sec' ? 'Чистое время' : 'Чистых повторений';
  const bigValue = e.unit === 'sec'
    ? `${Math.floor(big.holdGood)}`
    : `${big.good}`;
  const bigSuffix = battle && battle.mode === 'timed'
    ? `за ${battle.dur} с`
    : e.unit === 'sec' ? `${goal} с` : `/${goal}`;

  return (
    <div className="train-screen">
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full object-contain bg-[#050908]" />
      <video ref={videoRef} playsInline muted className="absolute w-px h-px opacity-0 pointer-events-none" />

      <div className="absolute top-0 left-0 right-0 flex items-center justify-between gap-2 p-3 bg-gradient-to-b from-black/65 to-transparent z-20">
        <button onClick={handleStop} className="hud border border-white/15 rounded-lg px-3.5 py-2 font-mono text-sm hover:border-white/30 transition">
          <Square size={14} className="inline mr-1" /> Стоп
        </button>
        <div className="font-display font-bold text-sm text-center flex-1 min-w-0 truncate">
          {e.name}{battle ? ' · баттл' : ''}
        </div>
        <button
          onClick={toggleSound}
          aria-pressed={soundOnState}
          className="hud border border-white/15 rounded-lg p-2.5 hover:border-white/30 transition"
          title="Звук"
        >
          {soundOnState ? <Volume2 size={16} /> : <VolumeX size={16} />}
        </button>
      </div>

      {battle && battle.players && battle.players.length > 0 && phaseRef.current !== 'position' && (
        <BattleProgress
          players={battle.players}
          myId={battle.myId}
          unit={e.unit}
          goal={goal}
          mode={battle.mode}
          dur={battle.dur}
          myStats={big}
          runStart={runStartRef.current}
        />
      )}

      {cue && (
        <div
          className={`absolute left-1/2 top-16 -translate-x-1/2 max-w-[calc(100%-32px)] hud border rounded-xl px-4 py-2.5 font-semibold text-lg text-center transition ${
            cueKind === 'ok' ? 'text-[#6be3a4] border-[#6be3a4]/50' : cueKind === 'fault' ? 'text-[#ff8c85] border-[#ff8c85]/60' : 'border-white/12'
          }`}
        >
          {cue}
        </div>
      )}

      {count && (
        <div className="absolute inset-0 grid place-items-center font-display font-bold pointer-events-none" style={{ fontSize: 'clamp(120px, 40vw, 240px)', textShadow: '0 4px 40px rgba(0,0,0,.6)' }}>
          {count}
        </div>
      )}

      {flash && (
        <div
          className={`absolute inset-0 pointer-events-none grid place-items-center flash-anim ${flash.kind === 'good' ? 'shadow-[inset_0_0_0_6px_#4bd18b]' : 'shadow-[inset_0_0_0_6px_#ff6b63]'}`}
        >
          <span className={`hud px-6 py-3.5 rounded-2xl font-display font-bold text-center max-w-[90%] ${flash.kind === 'good' ? 'text-[#6be3a4]' : 'text-[#ff8c85]'}`} style={{ fontSize: 'clamp(20px, 6vw, 30px)' }}>
            {flash.text}
          </span>
        </div>
      )}

      <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/82 via-black/82 to-transparent pb-3.5">
        <div className="max-w-3xl mx-auto flex items-end justify-between gap-4">
          <div>
            <div className="eyebrow text-[#9db0a8] mb-2">{bigLabel}</div>
            <div className="font-display font-bold tabular-nums" style={{ fontSize: 'clamp(64px, 19vw, 104px)', lineHeight: 0.9 }}>
              {bigValue}<small className="text-[#9db0a8] text-[0.32em] ml-1 font-normal">/{bigSuffix}</small>
            </div>
          </div>
          <div className="text-right space-y-2.5 min-w-0">
            {badText && <div className="font-mono text-sm text-[#ff8c85]">{badText}</div>}
            <div className="space-y-1.5">
              {mets.map((m, i) => (
                <div key={i} className="font-mono text-[15px] tabular-nums text-right">
                  <span className="text-[#9db0a8] mr-2 text-xs">{m.k}</span>
                  <b className={m.ok === true ? 'text-[#6be3a4]' : m.ok === false ? 'text-[#ff8c85]' : ''}>{m.v}{m.u}</b>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="max-w-3xl mx-auto h-1.5 bg-white/15 rounded-full mt-3.5 mb-2.5 overflow-hidden">
          <div className="h-full bg-[#6be3a4] transition-all duration-300" style={{ width: `${barWidth}%` }} />
        </div>
        <div className="max-w-3xl mx-auto flex flex-wrap gap-1 min-h-[10px]">
          {strip.map((ok, i) => (
            <span key={i} className={`w-3.5 h-2.5 rounded-sm ${ok ? 'bg-[#6be3a4]' : 'bg-[#ff6b63]'}`} />
          ))}
        </div>
      </div>

      {overlay && (
        <div className="absolute inset-0 grid place-items-center bg-[#050908]/90 p-6 text-center">
          <div className="max-w-md">
            {!overlay.err && <div className="spin w-8 h-8 rounded-full border-[3px] border-white/20 border-t-[#4cc3e0] mx-auto mb-4" />}
            <h2 className="font-display font-bold text-xl mb-2.5">{overlay.title}</h2>
            <p className="text-[#9db0a8] mb-5">{overlay.text}</p>
            {overlay.err && (
              <button onClick={onExit} className="bg-accent text-white font-display font-bold px-6 py-3.5 rounded-xl">Назад</button>
            )}
          </div>
        </div>
      )}
    </div>
  );

  function draw(out: FrameOut, video: HTMLVideoElement) {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const W = video.videoWidth, H = video.videoHeight;
    if (!W || !H) return;
    if (canvas.width !== W || canvas.height !== H) { canvas.width = W; canvas.height = H; }
    ctx.save();
    if (facing === 'user') { ctx.translate(W, 0); ctx.scale(-1, 1); }
    ctx.drawImage(video, 0, 0, W, H);
    ctx.fillStyle = 'rgba(0,0,0,.28)';
    ctx.fillRect(0, 0, W, H);
    if (out.pts) {
      const p = out.pts;
      const lw = Math.max(3, W / 200);
      const ok = out.ready ? '#4bd18b' : '#9aa9a3';
      const bad = '#ff5a52';
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      for (const [a, b] of LINKS) {
        if (p[a].v < 0.4 || p[b].v < 0.4) continue;
        ctx.strokeStyle = out.flagged.has(a) || out.flagged.has(b) ? bad : ok;
        ctx.lineWidth = lw;
        ctx.beginPath();
        ctx.moveTo(p[a].x, p[a].y);
        ctx.lineTo(p[b].x, p[b].y);
        ctx.stroke();
      }
      for (const i of [11, 12, 13, 14, 15, 16, 23, 24, 25, 26, 27, 28]) {
        if (p[i].v < 0.4) continue;
        ctx.fillStyle = out.flagged.has(i) ? bad : '#fff';
        ctx.beginPath();
        ctx.arc(p[i].x, p[i].y, lw * 1.35, 0, 7);
        ctx.fill();
      }
    }
    ctx.restore();
  }
}

type BattlePlayer = { id: string; name: string; good: number; bad: number; hold: number; fin: boolean };

function BattleProgress({ players, myId, unit, goal, mode, dur, myStats, runStart }: {
  players: BattlePlayer[];
  myId: string;
  unit: 'reps' | 'sec';
  goal: number;
  mode: 'race' | 'timed';
  dur: number;
  myStats: { good: number; bad: number; holdGood: number };
  runStart: number;
}) {
  const [, force] = useState(0);
  useEffect(() => {
    if (mode !== 'timed') return;
    let raf = 0;
    const tick = () => { force((n) => n + 1); raf = requestAnimationFrame(tick); };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [mode]);

  const all: BattlePlayer[] = players.map((p) =>
    p.id === myId
      ? { ...p, good: myStats.good, bad: myStats.bad, hold: myStats.holdGood }
      : p
  );

  const isPlank = unit === 'sec';
  const maxVal = mode === 'timed' ? Math.max(dur, 1) : goal;

  const sorted = [...all].sort((a, b) => {
    const va = isPlank ? a.hold : a.good;
    const vb = isPlank ? b.hold : b.good;
    if (a.fin !== b.fin) return a.fin ? -1 : 1;
    return vb - va;
  });

  const elapsed = runStart ? (performance.now() - runStart) / 1000 : 0;
  const timeLeft = mode === 'timed' ? Math.max(0, dur - elapsed) : 0;

  return (
    <div className="absolute top-[52px] left-1/2 -translate-x-1/2 w-[calc(100%-24px)] max-w-md z-20 pointer-events-none">
      {mode === 'timed' && (
        <div className="flex items-center justify-between mb-2 px-1">
          <span className="font-mono text-xs text-[#9db0a8]">Осталось</span>
          <span className="font-display font-bold text-lg tabular-nums text-white">
            {Math.ceil(timeLeft)}<small className="text-[#9db0a8] text-xs ml-1">с</small>
          </span>
        </div>
      )}
      <div className="hud rounded-xl p-3 space-y-2.5 backdrop-blur-md">
        {sorted.map((p) => {
          const val = isPlank ? p.hold : p.good;
          const pct = Math.min(100, (val / maxVal) * 100);
          const isMe = p.id === myId;
          const leader = sorted[0];
          const isLeader = leader.id === p.id;
          return (
            <div key={p.id} className="flex items-center gap-2.5">
              <span className={`font-mono text-xs w-4 text-center ${isLeader ? 'text-[#6be3a4]' : 'text-[#9db0a8]'}`}>
                {p.fin ? <Check size={12} className="inline" /> : ''}
              </span>
              <div className="flex-1 min-w-0">
                <div className="flex items-baseline justify-between gap-2 mb-1">
                  <span className={`font-display font-bold text-sm truncate ${isMe ? 'text-[#4cc3e0]' : 'text-white/90'}`}>
                    {p.name}{isMe && ' (ты)'}
                  </span>
                  <span className="font-display font-bold text-sm tabular-nums text-white whitespace-nowrap">
                    {isPlank ? `${Math.floor(p.hold)}с` : p.good}
                    {!isPlank && p.bad > 0 && <small className="text-[#ff8c85] text-xs ml-1">✕{p.bad}</small>}
                  </span>
                </div>
                <div className="h-2 rounded-full bg-white/10 overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-300 ${isMe ? 'bg-[#4cc3e0]' : isLeader ? 'bg-[#6be3a4]' : 'bg-white/50'}`}
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
