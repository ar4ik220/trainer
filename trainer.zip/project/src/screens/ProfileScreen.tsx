import { useState } from 'react';
import { useAuth } from '@/auth/AuthContext';
import { supabase } from '@/lib/supabase';
import { ArrowLeft, Activity, Swords, Check, Pencil } from 'lucide-react';

type Props = { onBack: () => void };

export default function ProfileScreen({ onBack }: Props) {
  const { profile, refreshProfile, signOut } = useAuth();
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(profile?.display_name ?? '');
  const [saving, setSaving] = useState(false);

  const save = async () => {
    setSaving(true);
    const trimmed = name.trim().slice(0, 16);
    if (trimmed) {
      await supabase.from('profiles').update({ display_name: trimmed }).eq('id', profile!.id);
      await refreshProfile();
    }
    setSaving(false);
    setEditing(false);
  };

  if (!profile) return null;

  return (
    <div className="min-h-screen screen-pad">
      <div className="max-w-xl mx-auto">
        <button onClick={onBack} className="eyebrow text-muted hover:text-ink transition mb-4">← Назад</button>

        <h1 className="font-display text-4xl sm:text-5xl tracking-tight mb-2">Профиль</h1>

        <div className="bg-surface border border-line rounded-2xl p-6 mb-4">
          <div className="eyebrow mb-2">Имя</div>
          {editing ? (
            <div className="flex gap-2">
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                maxLength={16}
                className="flex-1 bg-bg border border-line rounded-xl px-4 py-3 outline-none focus:border-accent"
              />
              <button onClick={save} disabled={saving} className="bg-accent text-white rounded-xl px-4 py-3 font-display font-bold disabled:opacity-60">
                <Check size={18} />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-3">
              <div className="font-display font-bold text-2xl">{profile.display_name}</div>
              <button onClick={() => { setName(profile.display_name); setEditing(true); }} className="text-muted hover:text-accent transition">
                <Pencil size={16} />
              </button>
            </div>
          )}
        </div>

        <div className="grid grid-cols-2 gap-3 mb-4">
          <StatCard
            icon={<Swords size={18} className="text-accent" />}
            label="Рейтинг за баттлы"
            value={profile.battle_rating}
            sub={`${profile.battles_played} баттлов`}
          />
          <StatCard
            icon={<Activity size={18} className="text-good" />}
            label="Рейтинг за одиночные"
            value={profile.solo_rating}
            sub={`${profile.solo_workouts} тренировок`}
          />
        </div>

        <button
          onClick={signOut}
          className="w-full bg-surface border border-line rounded-xl py-3.5 font-display font-bold text-bad hover:border-bad transition"
        >
          Выйти из аккаунта
        </button>
      </div>
    </div>
  );
}

function StatCard({ icon, label, value, sub }: { icon: React.ReactNode; label: string; value: number; sub: string }) {
  return (
    <div className="bg-surface border border-line rounded-2xl p-5">
      <div className="flex items-center justify-between mb-2">
        <span className="eyebrow">{label}</span>
        {icon}
      </div>
      <div className="font-display font-bold text-3xl tabular-nums">{value}</div>
      <div className="text-muted text-sm mt-1 font-mono">{sub}</div>
    </div>
  );
}
