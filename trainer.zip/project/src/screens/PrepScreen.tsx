import { useState } from 'react';
import { isSoundOn, setSoundOn } from '@/lib/sound';
import { getSettings, iconFor } from '@/lib/settings';
import { ArrowLeft } from 'lucide-react';

type Props = {
  kind: string;
  onStart: (goal: number, facing: 'user' | 'environment', sound: boolean) => void;
  onBack: () => void;
  titleExtra?: string;
};

export default function PrepScreen({ kind, onStart, onBack, titleExtra }: Props) {
  const s = getSettings();
  const e = s.exercises[kind] ?? s.exercises['squat'];
  const [goal, setGoal] = useState(e.goal);
  const [facing, setFacing] = useState<'user' | 'environment'>('user');
  const [sound, setSound] = useState(isSoundOn());

  return (
    <div className="min-h-screen screen-pad">
      <div className="max-w-2xl mx-auto">
        <button onClick={onBack} className="eyebrow text-muted hover:text-ink transition mb-4 flex items-center gap-1">
          <ArrowLeft size={14} /> Назад
        </button>

        <div
          className="w-32 h-24 text-accent mb-2"
          dangerouslySetInnerHTML={{ __html: iconFor(e) }}
        />
        <h1 className="font-display text-4xl sm:text-5xl tracking-tight mb-2">
          {e.name}{titleExtra ? <span className="text-muted"> · {titleExtra}</span> : null}
        </h1>
        <p className="text-muted mb-8 max-w-xl">{e.lede}</p>

        <div className="grid sm:grid-cols-2 gap-8 mb-2">
          <div>
            <h3 className="eyebrow mb-3">Как поставить телефон</h3>
            <ul className="space-y-2.5">
              {e.setup.map((t, i) => (
                <li key={i} className="relative pl-6 text-[15px] leading-relaxed">
                  <span className="absolute left-1 top-2.5 w-2 h-2 rounded-full bg-accent" />
                  {t}
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="eyebrow mb-3">Что считается чистым повторением</h3>
            <ul className="space-y-2.5">
              {e.rules.map((t, i) => (
                <li key={i} className="relative pl-6 text-[15px] leading-relaxed">
                  <span className="absolute left-1 top-2.5 w-2 h-2 rounded-sm bg-good" />
                  <span dangerouslySetInnerHTML={{ __html: t }} />
                </li>
              ))}
            </ul>
          </div>
        </div>

        <h3 className="eyebrow mt-8 mb-3">
          {e.unit === 'sec' ? 'Цель: секунд с ровным корпусом' : 'Цель: чистых повторений'}
        </h3>
        <div className="flex flex-wrap gap-2 mb-6">
          {e.goals.map((g) => (
            <button
              key={g}
              onClick={() => setGoal(g)}
              aria-pressed={g === goal}
              className={`min-w-[58px] px-4 py-2.5 rounded-xl border font-mono font-medium transition ${
                g === goal ? 'bg-accent text-white border-accent' : 'bg-surface border-line'
              }`}
            >
              {e.unit === 'sec' ? `${g} с` : g}
            </button>
          ))}
        </div>

        <h3 className="eyebrow mb-3">Камера</h3>
        <div className="flex flex-wrap gap-2 mb-6">
          {(['user', 'environment'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFacing(f)}
              aria-pressed={facing === f}
              className={`px-4 py-2.5 rounded-xl border font-mono font-medium transition ${
                facing === f ? 'bg-accent text-white border-accent' : 'bg-surface border-line'
              }`}
            >
              {f === 'user' ? 'Фронтальная' : 'Основная'}
            </button>
          ))}
        </div>

        <label className="flex items-center gap-3 text-[15px] mb-6 cursor-pointer">
          <input
            type="checkbox"
            checked={sound}
            onChange={(ev) => setSound(ev.target.checked)}
            className="w-5 h-5 accent-[var(--accent)]"
          />
          Голосовые подсказки и звук
        </label>

        <button
          onClick={() => { setSoundOn(sound); onStart(goal, facing, sound); }}
          className="w-full bg-accent text-white font-display font-bold py-4 rounded-xl hover:brightness-110 transition"
        >
          Начать
        </button>
        <p className="text-xs text-muted mt-4">
          Браузер спросит разрешение на камеру. Когда ты встанешь в кадр правильно, начнётся обратный отсчёт.
        </p>
      </div>
    </div>
  );
}
