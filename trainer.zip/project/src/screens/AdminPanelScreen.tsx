import { useEffect, useState } from 'react';
import type { EngineKind, TrainerKind, SkeletonDef } from '@/lib/formaEngine';
import { CFG_DEFAULT, POSE_PRESETS, presetToSkeleton } from '@/lib/formaEngine';
import { supabase, type ExerciseSettingsRow } from '@/lib/supabase';
import { EXERCISES, EXERCISE_ICONS, type Exercise } from '@/lib/exercises';
import { ArrowLeft, Check, Save, RotateCcw, Plus, X, Trash2 } from 'lucide-react';
import SkeletonEditor from '@/components/SkeletonEditor';
import FreeSkeletonEditor from '@/components/FreeSkeletonEditor';

const FREE_ICON = EXERCISE_ICONS.squat;

type Props = { onBack: () => void };

const ENGINES: { id: EngineKind; label: string }[] = [
  { id: 'squat', label: 'Приседания (колено/спина)' },
  { id: 'pushup', label: 'Отжимания (локоть/корпус)' },
  { id: 'lunge', label: 'Выпады (оба колена)' },
  { id: 'plank', label: 'Планка (линия корпуса)' },
  { id: 'free', label: 'Свободный скелет (любая поза)' },
];

const ENGINE_OF_BUILTIN: Record<TrainerKind, EngineKind> = {
  squat: 'squat', pushup: 'pushup', lunge: 'lunge', plank: 'plank',
};

const CFG_FIELDS: Record<EngineKind, { key: string; label: string; hint: string }[]> = {
  squat: [
    { key: 'depth', label: 'Глубина колена (°)', hint: 'Считается чистым, если колено согнулось до этого угла или глубже' },
    { key: 'leanMax', label: 'Макс. наклон спины (°)', hint: 'Больше — спина наклонена вперёд, повторение бракуется' },
    { key: 'minMs', label: 'Мин. темп (мс)', hint: 'Повторение быстрее этого времени бракуется' },
    { key: 'attempt', label: 'Порог попытки (°)', hint: 'Ниже этого угла — попытка засчитывается' },
    { key: 'up', label: 'Верхняя точка (°)', hint: 'Выше этого угла — повторение завершается' },
    { key: 'start', label: 'Старт опускания (°)', hint: 'Ниже этого угла начинается фиксация повторения' },
  ],
  pushup: [
    { key: 'depth', label: 'Глубина локтя (°)', hint: 'Считается чистым, если локоть согнулся до этого угла или глубже' },
    { key: 'bodyMin', label: 'Мин. линия корпуса (°)', hint: 'Линия плечо-таз-стопа не меньше этого угла' },
    { key: 'minMs', label: 'Мин. темп (мс)', hint: 'Повторение быстрее этого времени бракуется' },
    { key: 'attempt', label: 'Порог попытки (°)', hint: 'Ниже этого угла — попытка засчитывается' },
    { key: 'up', label: 'Верхняя точка (°)', hint: 'Выше этого угла — повторение завершается' },
    { key: 'start', label: 'Старт опускания (°)', hint: 'Ниже этого угла начинается фиксация повторения' },
    { key: 'horizMax', label: 'Макс. наклон к горизонту (°)', hint: 'Больше — камера не боком, повторение не считается' },
  ],
  lunge: [
    { key: 'front', label: 'Глубина переднего колена (°)', hint: 'Переднее колено должно согнуться до этого угла или глубже' },
    { key: 'rear', label: 'Глубина заднего колена (°)', hint: 'Заднее колено должно опуститься до этого угла или глубже' },
    { key: 'leanMax', label: 'Макс. наклон корпуса (°)', hint: 'Больше — корпус наклонён, повторение бракуется' },
    { key: 'minMs', label: 'Мин. темп (мс)', hint: 'Повторение быстрее этого времени бракуется' },
    { key: 'attempt', label: 'Порог попытки (°)', hint: 'Ниже этого угла — попытка засчитывается' },
    { key: 'up', label: 'Верхняя точка (°)', hint: 'Выше этого угла — повторение завершается' },
    { key: 'start', label: 'Старт опускания (°)', hint: 'Ниже этого угла начинается фиксация повторения' },
  ],
  plank: [
    { key: 'bodyMin', label: 'Мин. линия корпуса (°)', hint: 'Линия плечо-таз-стопа не меньше этого угла' },
    { key: 'horizMax', label: 'Макс. наклон к горизонту (°)', hint: 'Больше — камера не боком, фиксация не идёт' },
  ],
  free: [
    { key: 'depth', label: 'Глубина (°)', hint: 'Основной угол должен достичь этого значения или ниже для чистого повторения' },
    { key: 'up', label: 'Верхняя точка (°)', hint: 'Выше этого угла — повторение завершается' },
    { key: 'start', label: 'Старт (°)', hint: 'Ниже этого угла начинается фиксация повторения' },
    { key: 'attempt', label: 'Порог попытки (°)', hint: 'Ниже этого угла — попытка засчитывается' },
    { key: 'minMs', label: 'Мин. темп (мс)', hint: 'Повторение быстрее этого времени бракуется' },
    { key: 'bodyMin', label: 'Порог удержания (°)', hint: 'Для упражнений на время: основной угол должен быть не меньше этого значения' },
  ],
};

const slugify = (s: string) =>
  s.toLowerCase().trim()
    .replace(/[^a-z0-9а-яё]+/gi, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40) || ('ex-' + Date.now().toString(36));

type EditState = {
  kind: string;
  isNew: boolean;
  baseKind: EngineKind;
  name: string;
  short: string;
  lede: string;
  goals: number[];
  goal: number;
  unit: 'reps' | 'sec';
  setup: string[];
  rules: string[];
  cfg: Record<string, number>;
  icon: string;
  skeleton: SkeletonDef;
};

const blankEdit = (baseKind: EngineKind): EditState => {
  const def = (CFG_DEFAULT as unknown as Record<string, Record<string, number>>)[baseKind];
  const base = EXERCISES[baseKind as TrainerKind];
  const isFree = baseKind === 'free';
  return {
    kind: '',
    isNew: true,
    baseKind,
    name: '',
    short: '',
    lede: '',
    goals: base ? [...base.goals] : [10],
    goal: base ? base.goal : 10,
    unit: base ? base.unit : 'reps',
    setup: [''],
    rules: [''],
    cfg: { ...def },
    icon: isFree ? FREE_ICON : (EXERCISE_ICONS[baseKind as TrainerKind] ?? FREE_ICON),
    skeleton: isFree ? presetToSkeleton(POSE_PRESETS[0]) : { joints: {}, links: [], angles: [] },
  };
};

export default function AdminPanelScreen({ onBack }: Props) {
  const [rows, setRows] = useState<ExerciseSettingsRow[] | null>(null);
  const [active, setActive] = useState<string | null>(null);
  const [edit, setEdit] = useState<EditState | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    supabase
      .from('exercise_settings')
      .select('kind, base_kind, name, short, unit, goals, goal, lede, setup, rules, cfg, icon, skeleton, updated_at')
      .returns<ExerciseSettingsRow[]>()
      .then(({ data, error }) => {
        if (error || !data) { setError('Не удалось загрузить настройки'); return; }
        setRows(data);
      });
  }, []);

  const startEdit = (k: string) => {
    const row = rows?.find((r) => r.kind === k);
    const fallback = EXERCISES[k as TrainerKind];
    const baseKind = (row?.base_kind || ENGINE_OF_BUILTIN[k as TrainerKind] || k) as EngineKind;
    const skel = row?.skeleton && 'joints' in row.skeleton ? (row.skeleton as SkeletonDef) : null;
    setEdit({
      kind: k,
      isNew: false,
      baseKind,
      name: row?.name ?? fallback?.name ?? k,
      short: row?.short ?? fallback?.short ?? '',
      lede: row?.lede ?? fallback?.lede ?? '',
      goals: row?.goals?.length ? row.goals : (fallback?.goals ?? [10]),
      goal: row?.goal ?? fallback?.goal ?? 10,
      unit: (row?.unit as 'reps' | 'sec') ?? fallback?.unit ?? 'reps',
      setup: row?.setup?.length ? row.setup : (fallback?.setup ?? ['']),
      rules: row?.rules?.length ? row.rules : (fallback?.rules ?? ['']),
      cfg: { ...(row?.cfg || (CFG_DEFAULT as unknown as Record<string, Record<string, number>>)[baseKind]) },
      icon: row?.icon ?? '',
      skeleton: (baseKind === 'free' && skel) ? skel : (baseKind === 'free' ? presetToSkeleton(POSE_PRESETS[0]) : { joints: {}, links: [], angles: [] }),
    });
    setActive(k);
    setSaved(false);
    setError(null);
  };

  const startNew = () => {
    setEdit(blankEdit('squat'));
    setActive('__new__');
    setSaved(false);
    setError(null);
  };

  const resetToDefaults = (baseKind: EngineKind) => {
    const fb = EXERCISES[baseKind as TrainerKind];
    const def = (CFG_DEFAULT as unknown as Record<string, Record<string, number>>)[baseKind];
    setEdit((e) => e ? {
      ...e,
      baseKind,
      name: e.isNew ? e.name : (fb?.name ?? e.name),
      short: e.isNew ? e.short : (fb?.short ?? e.short),
      lede: e.isNew ? e.lede : (fb?.lede ?? e.lede),
      goals: fb ? [...fb.goals] : e.goals,
      goal: fb ? fb.goal : e.goal,
      unit: fb ? fb.unit : e.unit,
      setup: e.isNew ? e.setup : (fb?.setup ?? e.setup),
      rules: e.isNew ? e.rules : (fb?.rules ?? e.rules),
      cfg: { ...def },
      icon: e.isNew ? (e.icon || (EXERCISE_ICONS[baseKind as TrainerKind] ?? FREE_ICON)) : (e.icon || ''),
      skeleton: baseKind === 'free' ? presetToSkeleton(POSE_PRESETS[0]) : { joints: {}, links: [], angles: [] },
    } : e);
    setSaved(false);
  };

  const save = async () => {
    if (!edit) return;
    if (!edit.name.trim()) { setError('Введите название упражнения'); return; }
    setSaving(true);
    setError(null);
    const kind = edit.isNew ? slugify(edit.name) : edit.kind;
    const { error: err } = await supabase.rpc('set_exercise_settings', {
      p_kind: kind,
      p_base_kind: edit.baseKind,
      p_name: edit.name,
      p_short: edit.short,
      p_unit: edit.unit,
      p_goals: edit.goals,
      p_goal: edit.goal,
      p_lede: edit.lede,
      p_setup: edit.setup,
      p_rules: edit.rules,
      p_cfg: edit.cfg,
      p_icon: edit.icon,
      p_skeleton: edit.baseKind === 'free' ? edit.skeleton : {},
    });
    setSaving(false);
    if (err) {
      setError(err.message || 'Не удалось сохранить');
      return;
    }
    setSaved(true);
    const { data } = await supabase
      .from('exercise_settings')
      .select('kind, base_kind, name, short, unit, goals, goal, lede, setup, rules, cfg, icon, skeleton, updated_at')
      .returns<ExerciseSettingsRow[]>();
    if (data) setRows(data);
    if (edit.isNew) {
      setEdit({ ...edit, kind, isNew: false });
      setActive(kind);
    }
  };

  const deleteExercise = async (k: string) => {
    if (!k || (Object.keys(EXERCISES) as string[]).includes(k)) {
      setError('Встроенные упражнения нельзя удалить');
      return;
    }
    const { error: err } = await supabase.rpc('delete_exercise_settings', { p_kind: k });
    if (err) { setError(err.message || 'Не удалось удалить'); return; }
    const { data } = await supabase
      .from('exercise_settings')
      .select('kind, base_kind, name, short, unit, goals, goal, lede, setup, rules, cfg, icon, skeleton, updated_at')
      .returns<ExerciseSettingsRow[]>();
    if (data) setRows(data);
    setActive(null);
    setEdit(null);
  };

  if (rows === null && !error) {
    return (
      <div className="min-h-screen grid place-items-center bg-bg">
        <div className="spin w-10 h-10 rounded-full border-[3px] border-line border-t-[var(--accent)]" />
      </div>
    );
  }

  if (active && edit) {
    const fields = CFG_FIELDS[edit.baseKind];
    return (
      <div className="min-h-screen screen-pad">
        <div className="max-w-3xl mx-auto">
          <button onClick={() => { setActive(null); setEdit(null); }} className="eyebrow text-muted hover:text-ink transition mb-4 flex items-center gap-1">
            <ArrowLeft size={14} /> Назад к списку
          </button>

          <div className="flex items-center gap-4 mb-6">
            <div className="w-16 h-12 text-accent shrink-0" dangerouslySetInnerHTML={{ __html: edit.icon || (EXERCISE_ICONS[edit.baseKind as TrainerKind] ?? FREE_ICON) }} />
            <div>
              <div className="eyebrow">{edit.isNew ? 'Новое упражнение' : 'Редактирование упражнения'}</div>
              <h1 className="font-display text-3xl tracking-tight">{edit.name || 'Без названия'}</h1>
            </div>
          </div>

          <div className="bg-surface border border-line rounded-2xl p-5 mb-4">
            <h3 className="eyebrow mb-3">Основное</h3>
            <Label>Название</Label>
            <input className="admin-input" value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} />
            <Label>Краткое описание</Label>
            <input className="admin-input" value={edit.short} onChange={(e) => setEdit({ ...edit, short: e.target.value })} />
            <Label>Вступление (lede)</Label>
            <textarea className="admin-input min-h-[72px] resize-y" value={edit.lede} onChange={(e) => setEdit({ ...edit, lede: e.target.value })} />
            <Label>Единица измерения</Label>
            <select
              className="admin-input font-mono"
              value={edit.unit}
              onChange={(e) => setEdit({ ...edit, unit: e.target.value as 'reps' | 'sec' })}
            >
              <option value="reps">повторения (reps)</option>
              <option value="sec">секунды (sec)</option>
            </select>
            <Label>Движок распознавания</Label>
            <select
              className="admin-input font-mono"
              value={edit.baseKind}
              onChange={(e) => { const nk = e.target.value as EngineKind; resetToDefaults(nk); }}
              disabled={!edit.isNew}
            >
              {ENGINES.map((en) => <option key={en.id} value={en.id}>{en.label}</option>)}
            </select>
            <p className="text-xs text-muted mt-1">
              Движок определяет, какие суставы камера отслеживает. Встроенные упражнения привязаны к своему движку и не могут его сменить.
            </p>
          </div>

          <div className="bg-surface border border-line rounded-2xl p-5 mb-4">
            <h3 className="eyebrow mb-3">Иконка</h3>
            <div className="flex items-start gap-4">
              <div className="w-20 h-16 text-accent shrink-0 bg-bg border border-line rounded-xl grid place-items-center" dangerouslySetInnerHTML={{ __html: edit.icon || (EXERCISE_ICONS[edit.baseKind as TrainerKind] ?? FREE_ICON) }} />
              <div className="flex-1 min-w-0">
                <Label>SVG-код иконки</Label>
                <textarea
                  className="admin-input font-mono min-h-[120px] resize-y"
                  value={edit.icon}
                  placeholder={EXERCISE_ICONS[edit.baseKind as TrainerKind] ?? FREE_ICON}
                  onChange={(e) => setEdit({ ...edit, icon: e.target.value })}
                />
                <p className="text-xs text-muted mt-1">
                  Вставьте SVG-разметку. Оставьте пустым, чтобы использовать стандартную иконку для выбранного движка. Атрибут viewBox обязателен, цвет задавайте через stroke=&quot;currentColor&quot;.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-surface border border-line rounded-2xl p-5 mb-4">
            <h3 className="eyebrow mb-3">Цели</h3>
            <Label>Доступные цели (через запятую)</Label>
            <input
              className="admin-input font-mono"
              value={edit.goals.join(', ')}
              onChange={(e) => setEdit({ ...edit, goals: e.target.value.split(',').map((s) => parseInt(s.trim(), 10)).filter((n) => !isNaN(n)) })}
            />
            <Label>Цель по умолчанию</Label>
            <select
              className="admin-input font-mono"
              value={edit.goal}
              onChange={(e) => setEdit({ ...edit, goal: parseInt(e.target.value, 10) })}
            >
              {edit.goals.map((g) => <option key={g} value={g}>{g}</option>)}
            </select>
          </div>

          <div className="bg-surface border border-line rounded-2xl p-5 mb-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="eyebrow">Как поставить телефон</h3>
              <button onClick={() => setEdit({ ...edit, setup: [...edit.setup, ''] })} className="text-accent hover:text-ink transition flex items-center gap-1 text-sm">
                <Plus size={14} /> Добавить
              </button>
            </div>
            <div className="space-y-2">
              {edit.setup.map((t, i) => (
                <div key={i} className="flex gap-2">
                  <textarea
                    className="admin-input min-h-[44px] resize-y flex-1"
                    value={t}
                    onChange={(e) => setEdit({ ...edit, setup: edit.setup.map((x, j) => (j === i ? e.target.value : x)) })}
                  />
                  <button
                    onClick={() => setEdit({ ...edit, setup: edit.setup.filter((_, j) => j !== i) })}
                    className="text-bad/70 hover:text-bad transition p-2"
                    title="Удалить"
                  >
                    <X size={16} />
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-surface border border-line rounded-2xl p-5 mb-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="eyebrow">Что считается чистым повторением</h3>
              <button onClick={() => setEdit({ ...edit, rules: [...edit.rules, ''] })} className="text-accent hover:text-ink transition flex items-center gap-1 text-sm">
                <Plus size={14} /> Добавить
              </button>
            </div>
            <p className="text-xs text-muted mb-3">Можно использовать теги вроде <code className="font-mono">&lt;b&gt;90°&lt;/b&gt;</code> — они отобразятся жирным шрифтом.</p>
            <div className="space-y-2">
              {edit.rules.map((t, i) => (
                <div key={i} className="flex gap-2">
                  <textarea
                    className="admin-input min-h-[44px] resize-y flex-1"
                    value={t}
                    onChange={(e) => setEdit({ ...edit, rules: edit.rules.map((x, j) => (j === i ? e.target.value : x)) })}
                  />
                  <button
                    onClick={() => setEdit({ ...edit, rules: edit.rules.filter((_, j) => j !== i) })}
                    className="text-bad/70 hover:text-bad transition p-2"
                    title="Удалить"
                  >
                    <X size={16} />
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-surface border border-line rounded-2xl p-5 mb-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="eyebrow">Углы и темп</h3>
              <button onClick={() => resetToDefaults(edit.baseKind)} className="text-muted hover:text-ink transition flex items-center gap-1 text-sm">
                <RotateCcw size={14} /> Сбросить
              </button>
            </div>
            <p className="text-xs text-muted mb-3">
              Тяните точки на скелете, чтобы задать углы. Значения ниже обновятся автоматически — и наоборот, числа можно править вручную.
            </p>
            <div className="mb-4">
              {edit.baseKind === 'free' ? (
                <FreeSkeletonEditor
                  skeleton={edit.skeleton}
                  onChange={(s) => setEdit({ ...edit, skeleton: s })}
                />
              ) : (
                <SkeletonEditor
                  kind={edit.baseKind as TrainerKind}
                  cfg={edit.cfg}
                  onChange={(key, val) => setEdit({ ...edit, cfg: { ...edit.cfg, [key]: val } })}
                />
              )}
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              {fields.map((f) => (
                <div key={f.key}>
                  <Label>{f.label}</Label>
                  <input
                    type="number"
                    className="admin-input font-mono"
                    value={edit.cfg[f.key] ?? ''}
                    onChange={(e) => setEdit({ ...edit, cfg: { ...edit.cfg, [f.key]: parseInt(e.target.value, 10) } })}
                  />
                  <p className="text-xs text-muted mt-1">{f.hint}</p>
                </div>
              ))}
            </div>
          </div>

          {error && (
            <div className="bg-bad/10 border border-bad/40 rounded-xl p-3 mb-4 text-sm text-bad">{error}</div>
          )}
          {saved && (
            <div className="bg-good/10 border border-good/40 rounded-xl p-3 mb-4 text-sm text-good flex items-center gap-2">
              <Check size={16} /> Сохранено. Изменения вступят в силу при следующем запуске тренировки.
            </div>
          )}

          <div className="flex gap-3">
            <button
              onClick={save}
              disabled={saving}
              className="flex-1 bg-accent text-white font-display font-bold py-4 rounded-xl hover:brightness-110 transition flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <Save size={18} /> {saving ? 'Сохраняю…' : 'Сохранить'}
            </button>
            {!edit.isNew && !Object.keys(EXERCISES).includes(edit.kind) && (
              <button
                onClick={() => deleteExercise(edit.kind)}
                className="bg-bad/10 border border-bad/40 text-bad rounded-xl px-5 hover:bg-bad/20 transition flex items-center gap-2"
                title="Удалить упражнение"
              >
                <Trash2 size={18} />
              </button>
            )}
            <button
              onClick={() => { setActive(null); setEdit(null); }}
              className="bg-surface border border-line rounded-xl px-6 hover:border-line transition"
            >
              Закрыть
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen screen-pad">
      <div className="max-w-3xl mx-auto">
        <button onClick={onBack} className="eyebrow text-muted hover:text-ink transition mb-4 flex items-center gap-1">
          <ArrowLeft size={14} /> На главную
        </button>

        <div className="mb-6">
          <div className="eyebrow">Конфигурация ИИ-тренера</div>
          <h1 className="font-display text-4xl tracking-tight mt-1">Админ-панель</h1>
          <p className="text-muted mt-2 max-w-xl">
            Здесь можно редактировать встроенные упражнения и создавать новые — на базе одного из четырёх движков или в свободном режиме, где вы сами расставляете все суставы для любой позы (лёжа на спине, на животе, на боку и т. д.). Изменения видны всем пользователям сразу после сохранения.
          </p>
        </div>

        <div className="flex items-center justify-between mb-3">
          <h3 className="eyebrow">Упражнения</h3>
          <button onClick={startNew} className="text-accent hover:text-ink transition flex items-center gap-1 text-sm">
            <Plus size={14} /> Новое упражнение
          </button>
        </div>
        <div className="grid gap-3">
          {(Object.keys(EXERCISES) as TrainerKind[]).map((k) => (
            <ExerciseRow key={k} k={k} row={rows?.find((r) => r.kind === k)} onClick={() => startEdit(k)} />
          ))}
          {rows?.filter((r) => !(Object.keys(EXERCISES) as string[]).includes(r.kind)).map((r) => (
            <ExerciseRow key={r.kind} k={r.kind} row={r} onClick={() => startEdit(r.kind)} />
          ))}
        </div>
      </div>
    </div>
  );
}

function ExerciseRow({ k, row, onClick }: { k: string; row?: ExerciseSettingsRow; onClick: () => void }) {
  const fallback = EXERCISES[k as TrainerKind];
  const icon = row?.icon || (fallback ? EXERCISE_ICONS[fallback.baseKind] : EXERCISE_ICONS.squat);
  const updated = row ? new Intl.DateTimeFormat('ru', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }).format(new Date(row.updated_at)) : '—';
  return (
    <button
      onClick={onClick}
      className="group flex items-center gap-4 bg-surface border border-line rounded-2xl p-4 text-left hover:border-accent transition"
    >
      <div className="w-16 h-12 text-accent shrink-0" dangerouslySetInnerHTML={{ __html: icon }} />
      <div className="min-w-0 flex-1">
        <div className="font-display font-bold text-lg">{row?.name || fallback?.name || k}</div>
        <div className="text-muted text-sm">{row?.short || fallback?.short || ''}</div>
        <div className="eyebrow mt-1">Изменено: {updated}{!fallback ? ' · пользовательское' : ''}</div>
      </div>
      <span className="font-mono text-xl text-muted group-hover:text-accent transition">→</span>
    </button>
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return <label className="block text-sm font-medium text-muted mt-3 mb-1">{children}</label>;
}
