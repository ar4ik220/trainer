import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/auth/AuthContext';
import { ArrowLeft, Trophy, Swords, Activity, Crown } from 'lucide-react';

type LBRow = { id: string; display_name: string; rating: number; count: number };

type Props = {
  initialTab: 'solo' | 'battle';
  onBack: () => void;
};

export default function LeaderboardScreen({ initialTab, onBack }: Props) {
  const [tab, setTab] = useState<'solo' | 'battle'>(initialTab);
  const [rows, setRows] = useState<LBRow[]>([]);
  const [loading, setLoading] = useState(true);
  const { profile } = useAuth();

  useEffect(() => {
    setLoading(true);
    const view = tab === 'solo' ? 'solo_leaderboard' : 'battle_leaderboard';
    const cols = tab === 'solo' ? 'id, display_name, solo_rating, solo_workouts' : 'id, display_name, battle_rating, battles_played';
    supabase
      .from(view)
      .select(cols)
      .limit(100)
      .then(({ data }) => {
        const mapped = (data || []).map((r: any) => ({
          id: r.id,
          display_name: r.display_name,
          rating: tab === 'solo' ? r.solo_rating : r.battle_rating,
          count: tab === 'solo' ? r.solo_workouts : r.battles_played,
        }));
        setRows(mapped);
        setLoading(false);
      });
  }, [tab]);

  return (
    <div className="min-h-screen screen-pad">
      <div className="max-w-2xl mx-auto">
        <button onClick={onBack} className="eyebrow text-muted hover:text-ink transition mb-4">← Назад</button>

        <div className="flex items-center gap-3 mb-1">
          <Trophy size={28} className="text-accent" />
          <h1 className="font-display text-4xl sm:text-5xl tracking-tight">Таблица лидеров</h1>
        </div>
        <p className="text-muted mb-6">Лучшие спортсмены Формы по двум отдельным рейтингам.</p>

        <div className="flex gap-2 mb-6 p-1 bg-surface border border-line rounded-xl">
          <TabBtn active={tab === 'battle'} onClick={() => setTab('battle')} icon={<Swords size={16} />} label="Баттлы" />
          <TabBtn active={tab === 'solo'} onClick={() => setTab('solo')} icon={<Activity size={16} />} label="Одиночные" />
        </div>

        {loading ? (
          <div className="space-y-2">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="h-16 bg-surface border border-line rounded-xl pulse-soft" />
            ))}
          </div>
        ) : rows.length === 0 ? (
          <p className="text-muted">Пока никого. Сыграй первым!</p>
        ) : (
          <div className="grid gap-2">
            {rows.map((r, i) => {
              const me = r.id === profile?.id;
              const medal = i === 0;
              return (
                <div
                  key={r.id}
                  className={`flex items-center gap-4 bg-surface border rounded-xl px-4 py-3.5 ${
                    me ? 'border-accent' : medal ? 'border-good' : 'border-line'
                  }`}
                >
                  <div className={`font-display font-bold text-2xl w-10 text-center ${medal ? 'text-good' : 'text-muted'}`}>
                    {i + 1}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="font-display font-bold truncate flex items-center gap-2">
                      {r.display_name}
                      {medal && <Crown size={14} className="text-good" />}
                      {me && <span className="eyebrow text-accent">ты</span>}
                    </div>
                    <div className="text-muted text-sm font-mono">
                      {r.count} {tab === 'solo' ? 'тренировок' : 'баттлов'}
                    </div>
                  </div>
                  <div className="font-display font-bold text-2xl tabular-nums">{r.rating}</div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

function TabBtn({ active, onClick, icon, label }: { active: boolean; onClick: () => void; icon: React.ReactNode; label: string }) {
  return (
    <button
      onClick={onClick}
      className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg font-display font-bold text-sm transition ${
        active ? 'bg-accent text-white' : 'text-muted'
      }`}
    >
      {icon}
      {label}
    </button>
  );
}
