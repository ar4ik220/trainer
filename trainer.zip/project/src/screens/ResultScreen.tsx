import { useState } from 'react';
import { getSettings } from '@/lib/settings';
import { ArrowRight } from 'lucide-react';
import type { RecordSessionResult } from '@/lib/supabase';

type Props = {
  kind: string;
  good: number;
  bad: number;
  holdGood: number;
  holdBad: number;
  pct: number;
  result?: RecordSessionResult | null;
  onAgain: () => void;
  onHome: () => void;
};

export default function ResultScreen({ kind, good, bad, holdGood, holdBad, pct, result, onAgain, onHome }: Props) {
  const e = getSettings().exercises[kind] ?? getSettings().exercises['squat'];
  const plank = e.unit === 'sec';
  const delta = result?.rating_delta ?? 0;
  const newRating = result?.new_solo_rating;
  const total = plank ? holdGood + holdBad : good + bad;
  const [showReasons] = useState(true);
  void showReasons;

  return (
    <div className="min-h-screen screen-pad">
      <div className="max-w-2xl mx-auto">
        <div className="eyebrow">{e.name}</div>
        <div className="font-display font-bold tracking-tight mt-2" style={{ fontSize: 'clamp(72px, 22vw, 120px)', lineHeight: 0.95 }}>
          {pct}<small className="text-muted text-[0.35em]">%</small>
        </div>
        <div className="eyebrow mt-1">чистая техника</div>

        {result && (
          <div className={`mt-4 inline-flex items-center gap-2 px-4 py-2 rounded-xl font-mono font-medium ${delta > 0 ? 'bg-good/10 text-good' : delta < 0 ? 'bg-bad/10 text-bad' : 'bg-surface text-muted border border-line'}`}>
            Рейтинг {delta > 0 ? '+' : ''}{delta} → {newRating}
          </div>
        )}

        <div className="flex flex-wrap gap-7 mt-5 mb-1">
          <div className="min-w-0">
            <b className="block font-display font-bold text-3xl tabular-nums text-good">{plank ? `${Math.round(holdGood)} с` : good}</b>
            <span className="eyebrow">{plank ? 'чистого времени' : 'засчитано'}</span>
          </div>
          <div className="min-w-0">
            <b className="block font-display font-bold text-3xl tabular-nums text-bad">{plank ? `${Math.round(holdBad)} с` : bad}</b>
            <span className="eyebrow">{plank ? 'с нарушением' : 'отклонено'}</span>
          </div>
        </div>

        {plank && (
          <p className="text-muted mt-4 text-sm">Нарушений корпуса не было или они были короткими.</p>
        )}
        {!plank && total > 0 && (
          <>
            <h3 className="eyebrow mt-8 mb-3">Почему повторения не засчитаны</h3>
            <p className="text-muted text-sm">
              {bad === 0 ? 'Все повторения были чистыми.' : 'Смотри подсказки тренера во время тренировки, чтобы исправить технику.'}
            </p>
          </>
        )}

        <div className="flex flex-wrap gap-3 mt-8">
          <button onClick={onAgain} className="bg-accent text-white font-display font-bold px-6 py-4 rounded-xl flex items-center gap-2 hover:brightness-110 transition">
            Ещё подход <ArrowRight size={16} />
          </button>
          <button onClick={onHome} className="bg-surface border border-line font-display font-bold px-6 py-4 rounded-xl hover:border-accent transition">
            На главную
          </button>
        </div>
      </div>
    </div>
  );
}
