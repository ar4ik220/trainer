import { useEffect, useRef, useState, useCallback } from 'react';
import type { Pt, FrameOut, Trainer, TrainerKind } from '@/lib/formaEngine';
import { createTrainer } from '@/lib/formaEngine';

const MP = 'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14';
const MODEL = 'https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_full/float16/1/pose_landmarker_full.task';

type PoseLandmarkerLike = {
  detectForVideo: (video: HTMLVideoElement, now: number) => {
    landmarks?: Array<Array<{ x: number; y: number; visibility?: number }>>;
  };
};

let landmarkerPromise: Promise<PoseLandmarkerLike> | null = null;

async function ensureModel(): Promise<PoseLandmarkerLike> {
  if (landmarkerPromise) return landmarkerPromise;
  landmarkerPromise = (async () => {
    const mod = await import(/* @vite-ignore */ MP + '/vision_bundle.mjs');
    const { PoseLandmarker, FilesetResolver } = mod;
    const fileset = await FilesetResolver.forVisionTasks(MP + '/wasm');
    const mk = (delegate: 'GPU' | 'CPU') =>
      PoseLandmarker.createFromOptions(fileset, {
        baseOptions: { modelAssetPath: MODEL, delegate },
        runningMode: 'VIDEO',
        numPoses: 1,
        minPoseDetectionConfidence: 0.5,
        minPosePresenceConfidence: 0.5,
        minTrackingConfidence: 0.5,
      });
    try {
      return await mk('GPU');
    } catch {
      return await mk('CPU');
    }
  })();
  return landmarkerPromise;
}

export type CameraState = 'idle' | 'loading' | 'ready' | 'error';
export type CameraError = { kind: 'camera' | 'model'; message: string };

export type UseCameraOptions = {
  facing: 'user' | 'environment';
  active: boolean;
  onFrame: (out: FrameOut, video: HTMLVideoElement) => void;
};

export function useCamera(opts: UseCameraOptions) {
  const { facing, active, onFrame } = opts;
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [state, setState] = useState<CameraState>('idle');
  const [error, setError] = useState<CameraError | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const rafRef = useRef<number>(0);
  const lastVTRef = useRef(-1);
  const onFrameRef = useRef(onFrame);
  onFrameRef.current = onFrame;
  const wakeRef = useRef<{ release: () => void } | null>(null);
  const landmarkerRef = useRef<PoseLandmarkerLike | null>(null);

  const stop = useCallback(() => {
    cancelAnimationFrame(rafRef.current);
    rafRef.current = 0;
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    try { wakeRef.current?.release(); } catch { /* ignore */ }
    wakeRef.current = null;
  }, []);

  useEffect(() => {
    if (!active) {
      stop();
      setState('idle');
      return;
    }
    let cancelled = false;

    (async () => {
      setState('loading');
      setError(null);
      const video = videoRef.current;
      if (!video) return;
      try {
        if (!navigator.mediaDevices?.getUserMedia) throw new Error('nomedia');
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: facing, width: { ideal: 1280 }, height: { ideal: 720 } },
          audio: false,
        });
        if (cancelled) { stream.getTracks().forEach((t) => t.stop()); return; }
        streamRef.current = stream;
        video.srcObject = stream;
        await video.play();
      } catch {
        if (cancelled) return;
        setState('error');
        setError({ kind: 'camera', message: 'Нет доступа к камере. Разреши камеру в настройках браузера.' });
        return;
      }
      try {
        landmarkerRef.current = await ensureModel();
      } catch {
        if (cancelled) return;
        setState('error');
        setError({ kind: 'model', message: 'Не удалось загрузить модель позы. Проверь интернет.' });
        stop();
        return;
      }
      if (cancelled) return;
      setState('ready');
      try { wakeRef.current = await navigator.wakeLock?.request('screen'); } catch { /* ignore */ }
      cancelAnimationFrame(rafRef.current);
      rafRef.current = requestAnimationFrame(loop);
    })();

    function loop() {
      rafRef.current = requestAnimationFrame(loop);
      const v = videoRef.current;
      const lm = landmarkerRef.current;
      if (!v || !lm || v.readyState < 2 || !v.videoWidth) return;
      if (v.currentTime === lastVTRef.current) return;
      lastVTRef.current = v.currentTime;
      const now = performance.now();
      let raw: Pt[] | null = null;
      try {
        const res = lm.detectForVideo(v, now);
        if (res.landmarks && res.landmarks[0]) {
          raw = res.landmarks[0].map((p) => ({
            x: p.x * v.videoWidth,
            y: p.y * v.videoHeight,
            v: p.visibility ?? 1,
          }));
        }
      } catch { /* ignore */ }
      const t = currentTrainerRef.current;
      if (!t) return;
      const out = t.update(raw, now);
      onFrameRef.current(out, v);
    }

    return () => {
      cancelled = true;
      stop();
    };
  }, [active, facing, stop]);

  // Trainer management: caller controls creation/reset via setTrainer.
  const currentTrainerRef = useRef<Trainer | null>(null);
  const setTrainer = useCallback((t: Trainer | null) => {
    currentTrainerRef.current = t;
  }, []);

  return { videoRef, state, error, stop, setTrainer };
}

export type { Trainer, TrainerKind, EngineKind, SkeletonDef };
export { createTrainer, createTrainerForEngine, createFreeTrainer };
